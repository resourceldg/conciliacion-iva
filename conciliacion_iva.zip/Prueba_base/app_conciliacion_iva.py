"""
Conciliación IVA Compras — herramienta de reconciliación mensual de IVA
=======================================================================

Cruza dos fuentes de comprobantes:
  • Listado IVA Compras (Colppy) — libro contable interno
  • Mis Comprobantes Recibidos (ARCA/AFIP) — registro fiscal oficial

Para cada comprobante del Listado determina si existe en ARCA y si los
importes (Neto, IVA y Total) coinciden dentro de una tolerancia configurable.
Produce tres vistas: conciliación completa, solo en Listado y solo en ARCA.
"""

import streamlit as st
import pandas as pd
from io import BytesIO, StringIO
import os, sys, subprocess, tempfile, shutil, json, difflib, copy, re, unicodedata, sqlite3
from datetime import datetime
from pathlib import Path

st.set_page_config(
    page_title="Conciliación IVA Compras",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Constantes ────────────────────────────────────────────────────────────────

TOLERANCIA_DEFAULT = 0.07

DATA_DIR    = Path(__file__).parent / "data"
PERSIST_DIR = DATA_DIR / "persistencia"
DATA_DIR.mkdir(exist_ok=True)
PERSIST_DIR.mkdir(exist_ok=True)

DB_FILE = DATA_DIR / "conciliacion_iva.db"

# Rutas legacy — solo usadas por _migrar_legacy() en la primera ejecución
CSV_CONC    = DATA_DIR / "conciliacion_last.csv"
CSV_LIST    = DATA_DIR / "solo_listado_last.csv"
CSV_ARCA    = DATA_DIR / "solo_arca_last.csv"
CSV_META    = DATA_DIR / "meta_last.csv"
REGLAS_FILE = DATA_DIR / "reglas_cuit.json"

# Columnas booleanas: necesitan conversión explícita al releer desde CSV
BOOL_COLS = {"Existe_en_ARCA", "Match_Neto", "Match_IVA", "Match_Total", "Conciliado", "es_NC"}

# Tipos de comprobante que indican Nota de Crédito
NC_ARCA    = {"nota de crédito", "nota de credito"}   # ARCA (campo "Tipo")
NC_LISTADO = {"ncc-a", "ncc-b", "ncc-c", "nc-a", "nc-b", "nc-c"}  # Colppy

# Tipos de Colppy que corresponden a facturas del exterior (FCC = Factura Compra Exterior)
EXT_PREFIXES = {"fcc-a", "fcc-b", "fcc-c", "fce-a", "fce-b", "fce-c"}

# Mapa Estado → etiqueta con ícono para la UI; ICON_ESTADO es el inverso
ESTADO_ICON = {
    "Conciliado":              "✅ Conciliado",
    "Total OK / Sin desglose": "🟡 Total OK s/desglose",
    "Diferencia detectada":    "🔴 Diferencia",
    "Sin match en ARCA":       "⬜ Sin match",
    "Exterior / No en ARCA":   "🌐 Exterior s/ARCA",
    "Revisado / Aceptado":     "✔️ Revisado / Aceptado",
}
ICON_ESTADO = {v: k for k, v in ESTADO_ICON.items()}

# ── Mapeo de columnas ─────────────────────────────────────────────────────────

MAPEOS_FILE   = DATA_DIR / "mapeos.json"
FEEDBACK_FILE = DATA_DIR / "feedback.jsonl"

MOTIVOS_CORRECCION = [
    "Factura de exterior (no registrada en ARCA)",
    "Neto mal imputado en el sistema contable",
    "Diferencia de tipo de cambio",
    "Percepción no registrada / mal imputada",
    "IVA de alícuota diferente",
    "Error en punto de venta o número de comprobante",
    "Comprobante duplicado",
    "Diferencia de redondeo aceptable",
    "Retención / deducción no contabilizada",
    "Otro (ver nota)",
]

# Campos semánticos → nombre de columna por defecto en cada fuente
CAMPOS_LISTADO = {
    "comprobante":   "Comprobante",
    "fecha":         "Fecha Factura",
    "tipo":          "Tipo",
    "cuit":          "CUIT/DNI",
    "razon_social":  "Razón Social",
    "condicion_iva": "Condición IVA",
    "neto":          "Neto",
    "iva":           "IVA",
    "total":         "Total",
}
CAMPOS_ARCA = {
    "punto_venta":     "Punto de Venta",
    "numero":          "Número Desde",
    "fecha":           "Fecha",
    "tipo":            "Tipo",
    "cuit_emisor":     "Nro. Doc. Emisor",
    "denominacion":    "Denominación Emisor",
    "neto_gravado":    "Neto Gravado Total",
    "neto_no_gravado": "Neto No Gravado",
    "op_exentas":      "Op. Exentas",
    "otros_tributos":  "Otros Tributos",
    "total_iva":       "Total IVA",
    "total":           "Imp. Total",
}

# Etiquetas legibles para la UI de mapeo
LABEL_LISTADO = {
    "comprobante": "Comprobante", "fecha": "Fecha", "tipo": "Tipo",
    "cuit": "CUIT/DNI", "razon_social": "Razón Social",
    "condicion_iva": "Condición IVA", "neto": "Neto", "iva": "IVA", "total": "Total",
}
LABEL_ARCA = {
    "punto_venta": "Punto de Venta", "numero": "Número",
    "fecha": "Fecha", "tipo": "Tipo", "cuit_emisor": "CUIT Emisor",
    "denominacion": "Denominación", "neto_gravado": "Neto Gravado",
    "neto_no_gravado": "Neto No Gravado", "op_exentas": "Op. Exentas",
    "otros_tributos": "Otros Tributos", "total_iva": "Total IVA", "total": "Total",
}

# Sinónimos conocidos por campo semántico — permiten detección determinista cuando
# el proveedor cambia el nombre de una columna (ej: ARCA usa a veces "Código de Comprobante")
ALIASES_LISTADO: dict[str, list[str]] = {
    "comprobante":   ["comprobante", "nro comprobante", "numero comprobante", "comp",
                      "cod comprobante", "codigo comprobante",
                      # Libro IVA Compras: no tiene campo combinado, usar Numero como proxy
                      "numero", "nro"],
    "fecha":         ["fecha", "fecha factura", "fecha emision", "fecha_factura",
                      # Libro IVA Compras
                      "fec factura", "fec. factura", "fecha emision", "fec emision"],
    "tipo":          ["tipo", "tipo comprobante", "tipo doc", "clase", "codigo", "cod",
                      # Libro IVA Compras
                      "tipo comprob", "tipo comprob."],
    "cuit":          ["cuit", "cuit/dni", "cuit dni", "nro doc", "documento",
                      "nro documento", "nrodoc",
                      # Libro IVA Compras
                      "nro.doc.", "nro.doc", "nrodoc."],
    "razon_social":  ["razon social", "razon", "proveedor", "nombre", "denominacion"],
    "condicion_iva": ["condicion iva", "cond iva", "condicion", "condicioniva",
                      # Libro IVA Compras
                      "tipo iva"],
    "neto":          ["neto", "importe neto", "monto neto", "neto gravado",
                      # Libro IVA Compras
                      "gravado"],
    "iva":           ["iva", "importe iva", "monto iva",
                      # Libro IVA Compras (primera columna de IVA encontrada)
                      "iva 21%", "iva 10.5%", "iva 27%"],
    "total":         ["total", "importe total", "monto total", "total factura"],
}

# Columnas del Libro IVA Compras que se mapean automáticamente en _load_libro_iva.
# Se usan para mostrar el panel informativo en el emparejamiento.
_LIBRO_MAPEO_AUTO = {
    "Comprobante":  "Suc. + Letra + Número (construido automáticamente)",
    "Fecha":        "Fec. Factura",
    "Tipo":         "Tipo Comprob. + Letra  →  FAC-A/B/C, NCC-A/B/C",
    "CUIT":         "Nro.Doc.",
    "Razón Social": "Proveedor",
    "Cond. IVA":    "Tipo Iva",
    "Neto":         "Gravado",
    "IVA":          "Iva 21% + Iva 10.5% + Iva 27%  (suma)",
    "Total":        "Total",
}

ALIASES_ARCA: dict[str, list[str]] = {
    "punto_venta":     ["punto de venta", "pto venta", "pto de venta", "punto venta", "ptoventa"],
    "numero":          ["numero desde", "nro desde", "numero", "nro",
                        "num desde", "numero comprobante"],
    "fecha":           ["fecha", "fecha cbte", "fecha comprobante"],
    "tipo":            ["tipo", "tipo comprobante", "codigo de comprobante",
                        "cod comprobante", "codigo", "clase"],
    "cuit_emisor":     ["nro doc emisor", "nro. doc. emisor", "cuit emisor", "cuit",
                        "documento emisor", "cuit/dni emisor"],
    "denominacion":    ["denominacion emisor", "denominación emisor",
                        "razon social emisor", "denominacion", "razon social"],
    "neto_gravado":    ["neto gravado total", "neto gravado", "neto grav total", "neto grav"],
    "neto_no_gravado": ["neto no gravado", "neto no grav"],
    "op_exentas":      ["op exentas", "op. exentas", "operaciones exentas", "exentas"],
    "otros_tributos":  ["otros tributos", "otros trib", "tributos"],
    "total_iva":       ["total iva", "iva", "imp iva", "importe iva"],
    "total":           ["imp total", "imp. total", "total", "importe total", "total importe"],
}

MAPEOS_DEFAULT = {
    "listado": {"Colppy": {"header_keyword": "Comprobante",    "columnas": copy.deepcopy(CAMPOS_LISTADO)}},
    "arca":    {"ARCA":   {"header_keyword": "Punto de Venta", "columnas": copy.deepcopy(CAMPOS_ARCA)}},
}

# Grupos de emparejamiento entre columnas de ambos archivos.
# required=True  → sin este campo la conciliación no puede ejecutarse
# required=False → campo informativo; puede dejarse sin mapear
GRUPOS_PAREJAS = [
    {
        "titulo":  "🔑 Identificación",
        "detalle": "Determinan qué comprobante del Listado corresponde a cuál de ARCA",
        "campos": [
            {
                "label":    "Comprobante *",
                "l_campo":  "comprobante",
                "a_campo":  None,
                "a_fijo":   "Pto. Venta + Número (construido automáticamente)",
                "a_implícitos": ["punto_venta", "numero"],
                "required": True,
            },
            {
                "label":    "CUIT proveedor *",
                "l_campo":  "cuit",
                "a_campo":  "cuit_emisor",
                "required": True,
            },
        ],
    },
    {
        "titulo":  "💰 Importes comparados",
        "detalle": "Requeridos para la conciliación — las diferencias determinan el estado",
        "campos": [
            {"label": "Neto *",  "l_campo": "neto",  "a_campo": "neto_gravado", "required": True},
            {"label": "IVA *",   "l_campo": "iva",   "a_campo": "total_iva",    "required": True},
            {"label": "Total *", "l_campo": "total", "a_campo": "total",        "required": True},
        ],
    },
    {
        "titulo":  "ℹ️ Información adicional",
        "detalle": "Opcional — visible en la tabla, no afecta el cruce",
        "campos": [
            {"label": "Fecha",         "l_campo": "fecha",        "a_campo": "fecha",        "required": False},
            {"label": "Tipo",          "l_campo": "tipo",         "a_campo": "tipo",         "required": False},
            {"label": "Razón Social",  "l_campo": "razon_social", "a_campo": "denominacion", "required": False},
        ],
    },
]

# Campos ARCA que se usan internamente pero no se muestran como parejas
_ARCA_INTERNOS = ["neto_no_gravado", "op_exentas", "otros_tributos"]

_CONF_RANK  = {"exact": 0, "norm": 1, "alias": 2, "fuzzy": 3, "none": 4}
_CONF_BADGE = {
    "exact": ("✅", "#15803d", "Coincidencia exacta"),
    "norm":  ("✅", "#15803d", "Normalizado — coincide"),
    "alias": ("🟡", "#b45309", "Sinónimo conocido — verificá"),
    "fuzzy": ("🟠", "#c2410c", "Coincidencia aproximada — revisá"),
    "none":  ("❌", "#dc2626", "Sin match — seleccioná manualmente"),
}

# ── CSS — VS Code dark theme ──────────────────────────────────────────────────
st.markdown("""
<style>
    /* ── Header ──────────────────────────────────────────────── */
    .header-bar {
        background: #252526;
        border-left: 4px solid #007acc;
        border-bottom: 1px solid #3e3e42;
        padding: 1.1rem 1.8rem;
        border-radius: 4px;
        margin-bottom: 1.1rem;
    }
    .header-bar h1 {
        margin: 0; font-size: 1.55rem; font-weight: 600;
        color: #ffffff; letter-spacing: -0.01em;
    }
    .header-bar p {
        margin: 0.3rem 0 0; font-size: 0.86rem; color: #9cdcfe;
    }

    /* ── KPI cards ───────────────────────────────────────────── */
    .kpi-row { display: flex; gap: 0.6rem; flex-wrap: wrap; margin-bottom: 0.9rem; }
    .kpi {
        flex: 1; min-width: 96px; text-align: center;
        padding: 0.75rem 0.4rem; border-radius: 4px;
        border: 1px solid #3e3e42; background: #252526;
        transition: border-color 0.15s;
    }
    .kpi:hover { border-color: #007acc; }
    .kpi .n { font-size: 1.95rem; font-weight: 700; line-height: 1.1; }
    .kpi .l {
        font-size: 0.72rem; color: #858585;
        text-transform: uppercase; letter-spacing: .05em; margin-top: 0.2rem;
    }
    .kpi.ok .n { color: #4ec9b0; }
    .kpi.bl .n { color: #569cd6; }
    .kpi.or .n { color: #ce9178; }
    .kpi.re .n { color: #f14c4c; }
    .kpi.gr .n { color: #858585; }
    .kpi.pu .n { color: #c586c0; }

    /* ── Saved badge ─────────────────────────────────────────── */
    .saved-badge {
        background: #1e3a2f; color: #4ec9b0;
        font-size: 0.82rem; padding: 0.25rem 0.7rem;
        border-radius: 3px; font-weight: 600;
        border: 1px solid #2d6b50;
    }

    /* ── Dataframe — filas y texto más grandes ───────────────── */
    [data-testid="stDataFrame"] td,
    [data-testid="stDataFrame"] th {
        font-size: 1.0rem !important;
        padding-top: 0.45rem !important;
        padding-bottom: 0.45rem !important;
    }
    /* Emojis de estado en la tabla más legibles */
    [data-testid="stDataFrame"] td:first-child {
        font-size: 1.05rem !important;
    }

    /* ── Sidebar: separadores y subtítulos estilo panel VS Code ─ */
    [data-testid="stSidebar"] h3 {
        color: #9cdcfe !important;
        font-size: 0.78rem !important;
        text-transform: uppercase;
        letter-spacing: .1em;
        border-bottom: 1px solid #3e3e42;
        padding-bottom: 4px;
        margin-bottom: 6px;
    }

    /* ── Botones primarios con acento VS Code blue ───────────── */
    [data-testid="stBaseButton-primary"] > div {
        font-size: 1.0rem !important;
        letter-spacing: 0.01em;
    }

    /* ── Expander headers más grandes ───────────────────────── */
    [data-testid="stExpander"] summary {
        font-size: 1.0rem !important;
    }
    [data-testid="stExpander"] summary span {
        font-size: 1.05rem !important;
    }

    /* ── Ocultar chrome de Streamlit ─────────────────────────── */
    #MainMenu { visibility: hidden; }
    footer     { visibility: hidden; }
</style>
""", unsafe_allow_html=True)


# ── Funciones de mapeo y feedback ────────────────────────────────────────────

# ── SQLite — capa de acceso a datos ───────────────────────────────────────────

def _db_con() -> sqlite3.Connection:
    con = sqlite3.connect(DB_FILE)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA foreign_keys=ON")
    return con


def init_db():
    """Crea las tablas si no existen y migra archivos legacy en la primera ejecución."""
    con = _db_con()
    con.executescript("""
        CREATE TABLE IF NOT EXISTS conciliaciones (
            ts            TEXT PRIMARY KEY,
            periodo       TEXT,
            tolerancia    REAL,
            n_listado     INTEGER,
            n_arca        INTEGER,
            conciliados   INTEGER,
            diferencias   INTEGER,
            fecha_proceso TEXT,
            s1_json       TEXT,
            s2_json       TEXT,
            s3_json       TEXT
        );
        CREATE TABLE IF NOT EXISTS reglas_cuit (
            cuit_norm      TEXT PRIMARY KEY,
            estado         TEXT,
            estado_display TEXT,
            motivo         TEXT,
            razon_social   TEXT,
            creado         TEXT,
            activo         INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS mapeos (
            nombre      TEXT PRIMARY KEY,
            config_json TEXT,
            actualizado TEXT
        );
        CREATE TABLE IF NOT EXISTS feedback (
            id               INTEGER PRIMARY KEY AUTOINCREMENT,
            ts               TEXT,
            periodo          TEXT,
            comprobante      TEXT,
            cuit_dni         TEXT,
            razon_social     TEXT,
            estado_algoritmo TEXT,
            estado_usuario   TEXT,
            motivo           TEXT,
            nota             TEXT,
            data_json        TEXT
        );
    """)
    con.commit()
    con.close()
    # Restringir permisos del archivo DB al propietario del proceso
    try:
        os.chmod(DB_FILE, 0o600)
    except Exception:
        pass
    _migrar_legacy()


def _migrar_legacy():
    """Importa archivos legacy (JSON/CSV/JSONL) a SQLite. Corre solo una vez."""
    marker = DATA_DIR / ".db_migrated"
    if marker.exists():
        return
    con = _db_con()
    try:
        # reglas_cuit.json
        if REGLAS_FILE.exists():
            try:
                reglas = json.loads(REGLAS_FILE.read_text(encoding="utf-8"))
                for cuit, v in reglas.items():
                    con.execute(
                        "INSERT OR IGNORE INTO reglas_cuit "
                        "(cuit_norm,estado,estado_display,motivo,razon_social,creado,activo) "
                        "VALUES (?,?,?,?,?,?,?)",
                        (cuit, v.get("estado",""), v.get("estado_display",""),
                         v.get("motivo",""), v.get("razon_social",""),
                         v.get("creado",""), int(v.get("activo", True)))
                    )
            except Exception:
                pass

        # mapeos.json
        if MAPEOS_FILE.exists():
            try:
                mapeos = json.loads(MAPEOS_FILE.read_text(encoding="utf-8"))
                for nombre, config in mapeos.items():
                    con.execute(
                        "INSERT OR IGNORE INTO mapeos (nombre, config_json, actualizado) VALUES (?,?,?)",
                        (nombre, json.dumps(config, ensure_ascii=False), datetime.now().isoformat())
                    )
            except Exception:
                pass

        # feedback.jsonl
        if FEEDBACK_FILE.exists():
            try:
                for line in FEEDBACK_FILE.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    r = json.loads(line)
                    con.execute(
                        "INSERT INTO feedback "
                        "(ts,periodo,comprobante,cuit_dni,razon_social,"
                        "estado_algoritmo,estado_usuario,motivo,nota,data_json) "
                        "VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (r.get("ts"), r.get("periodo"), r.get("Comprobante"),
                         r.get("CUIT_DNI"), r.get("Razon_Social"),
                         r.get("estado_algoritmo"), r.get("estado_usuario"),
                         r.get("motivo"), r.get("nota"),
                         json.dumps(r, ensure_ascii=False))
                    )
                FEEDBACK_FILE.rename(FEEDBACK_FILE.with_suffix(".jsonl.bak"))
            except Exception:
                pass

        # Snapshots históricos de persistencia/
        if PERSIST_DIR.exists():
            for m in sorted(PERSIST_DIR.glob("*_meta.csv")):
                try:
                    row  = pd.read_csv(m).iloc[0].to_dict()
                    ts   = row.get("ts", m.stem.split("_meta")[0])
                    if con.execute("SELECT 1 FROM conciliaciones WHERE ts=?", (ts,)).fetchone():
                        continue
                    p1 = PERSIST_DIR / f"{ts}_conciliacion.csv"
                    p2 = PERSIST_DIR / f"{ts}_solo_listado.csv"
                    p3 = PERSIST_DIR / f"{ts}_solo_arca.csv"
                    if not all(p.exists() for p in (p1, p2, p3)):
                        continue
                    _s1 = _restore_bools(pd.read_csv(p1, encoding="utf-8-sig"))
                    _s2 = pd.read_csv(p2, encoding="utf-8-sig")
                    _s3 = pd.read_csv(p3, encoding="utf-8-sig")
                    periodo = str(row.get("periodo", "")).strip()
                    con.execute(
                        "INSERT OR IGNORE INTO conciliaciones "
                        "(ts,periodo,tolerancia,n_listado,n_arca,conciliados,diferencias,"
                        "fecha_proceso,s1_json,s2_json,s3_json) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        (ts, periodo, float(row.get("tolerancia", 0)),
                         int(row.get("n_listado", 0)), 0,
                         int(row.get("conciliados", 0)), 0, ts,
                         _s1.to_json(orient="records", force_ascii=False, date_format="iso"),
                         _s2.to_json(orient="records", force_ascii=False, date_format="iso"),
                         _s3.to_json(orient="records", force_ascii=False, date_format="iso"))
                    )
                except Exception:
                    pass

        # Último resultado (CSVs _last)
        if CSV_CONC.exists() and CSV_LIST.exists() and CSV_ARCA.exists():
            try:
                meta = pd.read_csv(CSV_META).iloc[0].to_dict() if CSV_META.exists() else {}
                try:
                    _ts_last = datetime.fromisoformat(
                        str(meta.get("fecha_proceso", ""))
                    ).strftime("%Y%m%d_%H%M%S")
                except Exception:
                    _ts_last = datetime.now().strftime("%Y%m%d_%H%M%S")
                if not con.execute("SELECT 1 FROM conciliaciones WHERE ts=?", (_ts_last,)).fetchone():
                    _s1 = _restore_bools(pd.read_csv(CSV_CONC, encoding="utf-8-sig"))
                    _s2 = pd.read_csv(CSV_LIST, encoding="utf-8-sig")
                    _s3 = pd.read_csv(CSV_ARCA, encoding="utf-8-sig")
                    periodo = _detectar_periodo(_s1)
                    tol = float(meta.get("tolerancia", TOLERANCIA_DEFAULT))
                    con.execute(
                        "INSERT OR IGNORE INTO conciliaciones "
                        "(ts,periodo,tolerancia,n_listado,n_arca,conciliados,diferencias,"
                        "fecha_proceso,s1_json,s2_json,s3_json) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                        (_ts_last, periodo, tol, len(_s1),
                         int(meta.get("n_arca", 0)), int(meta.get("conciliados", 0)),
                         int(meta.get("diferencias", 0)), str(meta.get("fecha_proceso", "")),
                         _s1.to_json(orient="records", force_ascii=False, date_format="iso"),
                         _s2.to_json(orient="records", force_ascii=False, date_format="iso"),
                         _s3.to_json(orient="records", force_ascii=False, date_format="iso"))
                    )
            except Exception:
                pass

        con.commit()
        marker.touch()
    finally:
        con.close()


def cargar_mapeos() -> dict:
    try:
        con = _db_con()
        rows = con.execute("SELECT nombre, config_json FROM mapeos").fetchall()
        con.close()
        mapeos = copy.deepcopy(MAPEOS_DEFAULT)
        for row in rows:
            try:
                mapeos[row["nombre"]] = json.loads(row["config_json"])
            except Exception:
                pass
        return mapeos
    except Exception:
        return copy.deepcopy(MAPEOS_DEFAULT)


def guardar_mapeos(mapeos: dict):
    try:
        con = _db_con()
        for nombre, config in mapeos.items():
            con.execute(
                "INSERT OR REPLACE INTO mapeos (nombre, config_json, actualizado) VALUES (?,?,?)",
                (nombre, json.dumps(config, ensure_ascii=False), datetime.now().isoformat())
            )
        con.commit()
        con.close()
    except Exception:
        pass


def _normalizar_col(s: str) -> str:
    """Minúsculas, sin acentos, sin puntuación, espacios simples."""
    s = unicodedata.normalize("NFD", str(s).strip().lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", s)).strip()


def sugerir_mapeo(cols_archivo: list, campos_esperados: dict,
                  aliases: dict | None = None) -> tuple[dict, dict]:
    """Mapea columnas del archivo a campos semánticos con pipeline de 4 pasos.

    Retorna (sugerencias, confianzas):
      sugerencias: {campo: col_nombre}
      confianzas:  {campo: "exact" | "norm" | "alias" | "fuzzy" | "none"}
    """
    cols_lower = {c.lower().strip(): c for c in cols_archivo}
    cols_norm  = {_normalizar_col(c): c for c in cols_archivo}
    usados: set[str] = set()

    def _claim(col: str) -> str | None:
        if col not in usados:
            usados.add(col)
            return col
        return None

    sugerencias: dict[str, str]  = {}
    confianzas:  dict[str, str]  = {}

    for campo, default_col in campos_esperados.items():
        col_enc = None
        nivel   = "none"

        # 1. Exact (case-insensitive)
        k = default_col.lower().strip()
        if k in cols_lower:
            col_enc = _claim(cols_lower[k])
            if col_enc: nivel = "exact"

        # 2. Normalizado (sin acentos, sin puntuación)
        if not col_enc:
            kn = _normalizar_col(default_col)
            if kn in cols_norm:
                col_enc = _claim(cols_norm[kn])
                if col_enc: nivel = "norm"

        # 3. Alias conocidos
        if not col_enc and aliases and campo in aliases:
            for alias in aliases[campo]:
                an = _normalizar_col(alias)
                if an in cols_norm:
                    col_enc = _claim(cols_norm[an])
                    if col_enc:
                        nivel = "alias"
                        break

        # 4. Fuzzy
        if not col_enc:
            libre = [n for n in cols_norm if cols_norm[n] not in usados]
            matches = difflib.get_close_matches(
                _normalizar_col(default_col), libre, n=1, cutoff=0.45
            )
            if matches:
                col_enc = _claim(cols_norm[matches[0]])
                if col_enc: nivel = "fuzzy"

        sugerencias[campo] = col_enc or (cols_archivo[0] if cols_archivo else "")
        confianzas[campo]  = nivel if col_enc else "none"

    return sugerencias, confianzas


_LISTADO_FALLBACKS = ["CUIT/DNI", "Fecha Factura", "Fecha", "Neto", "Total"]
_ARCA_FALLBACKS    = ["Número Desde", "Fecha", "Neto Gravado"]


def _detectar_columnas(source, header_keyword: str,
                       fallbacks: list[str] | None = None) -> list:
    """Lee solo el encabezado del archivo para devolver la lista de columnas detectadas."""
    try:
        raw   = leer_excel(source)
        sheet = _mejor_hoja(raw)
        hr    = _find_header(sheet, header_keyword, fallbacks)
        if hr is None:
            # Para Libro IVA Compras, el header está en la fila 0 de la hoja de datos
            hr = 0
        cols = [str(c).strip() for c in sheet.iloc[hr] if str(c).strip() and str(c) != "nan"]
        if hasattr(source, "seek"):
            source.seek(0)
        return cols
    except Exception:
        return []


def cargar_reglas() -> dict:
    try:
        con = _db_con()
        rows = con.execute(
            "SELECT cuit_norm,estado,estado_display,motivo,razon_social,creado,activo "
            "FROM reglas_cuit"
        ).fetchall()
        con.close()
        return {
            r["cuit_norm"]: {
                "estado":         r["estado"],
                "estado_display": r["estado_display"],
                "motivo":         r["motivo"],
                "razon_social":   r["razon_social"],
                "creado":         r["creado"],
                "activo":         bool(r["activo"]),
            }
            for r in rows
        }
    except Exception:
        return {}


def guardar_regla(cuit_norm: str, estado: str, motivo: str, razon_social: str) -> bool:
    estado_canon = ICON_ESTADO.get(estado, estado)
    con = None
    try:
        con = _db_con()
        con.execute(
            "INSERT OR REPLACE INTO reglas_cuit "
            "(cuit_norm,estado,estado_display,motivo,razon_social,creado,activo) "
            "VALUES (?,?,?,?,?,?,1)",
            (cuit_norm, estado_canon, estado, motivo, razon_social, datetime.now().isoformat())
        )
        con.commit()
        return True
    except Exception as e:
        print(f"[ERROR guardar_regla] {e}", file=sys.stderr)
        return False
    finally:
        if con:
            con.close()


def eliminar_regla(cuit_norm: str) -> bool:
    con = None
    try:
        con = _db_con()
        con.execute("DELETE FROM reglas_cuit WHERE cuit_norm=?", (cuit_norm,))
        con.commit()
        return True
    except Exception as e:
        print(f"[ERROR eliminar_regla] {e}", file=sys.stderr)
        return False
    finally:
        if con:
            con.close()


def guardar_feedback(fila: pd.Series, estado_usuario: str,
                     motivo: str, nota: str, periodo: str) -> bool:
    campos_num = ["Dif_Neto", "Dif_IVA", "Dif_Total", "Neto", "IVA", "Total"]
    registro: dict = {
        "ts":               datetime.now().isoformat(),
        "periodo":          periodo,
        "Comprobante":      fila.get("Comprobante", ""),
        "CUIT_DNI":         fila.get("CUIT_DNI", ""),
        "Razon_Social":     fila.get("Razon_Social", ""),
        "estado_algoritmo": fila.get("Estado", ""),
        "estado_usuario":   estado_usuario,
        "motivo":           motivo,
        "nota":             nota,
    }
    for c in campos_num:
        if c in fila.index:
            registro[c] = fila[c]
    con = None
    try:
        con = _db_con()
        con.execute(
            "INSERT INTO feedback "
            "(ts,periodo,comprobante,cuit_dni,razon_social,"
            "estado_algoritmo,estado_usuario,motivo,nota,data_json) "
            "VALUES (?,?,?,?,?,?,?,?,?,?)",
            (registro["ts"], periodo, registro["Comprobante"],
             registro["CUIT_DNI"], registro["Razon_Social"],
             registro["estado_algoritmo"], estado_usuario,
             motivo, nota,
             json.dumps(registro, ensure_ascii=False, default=str))
        )
        con.commit()
        return True
    except Exception as e:
        print(f"[ERROR guardar_feedback] {e}", file=sys.stderr)
        return False
    finally:
        if con:
            con.close()


# ── Lectura robusta de Excel ──────────────────────────────────────────────────

def _find_libreoffice() -> str:
    """Devuelve el ejecutable de LibreOffice según el sistema operativo.

    En Windows LibreOffice se llama soffice.exe y frecuentemente no está en PATH,
    por lo que se busca en las rutas de instalación estándar.
    En Linux/Mac el comando es simplemente 'libreoffice'.
    """
    if sys.platform == "win32":
        candidates = [
            r"C:\Program Files\LibreOffice\program\soffice.exe",
            r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
        ]
        for path in candidates:
            if Path(path).exists():
                return path
        # Si está en PATH (instalación custom o portable)
        return shutil.which("soffice") or shutil.which("libreoffice") or "soffice"
    return "libreoffice"


def _libreoffice_xlsx(src_path: str) -> str:
    """Convierte un XLS a XLSX usando LibreOffice en modo headless.

    Colppy exporta XLS con un bug en el compound document que hace que xlrd
    lo rechace con CompDocError. LibreOffice lo repara al reescribirlo como XLSX.
    Retorna la ruta del XLSX generado en un directorio temporal.
    """
    out = tempfile.mkdtemp()
    subprocess.run(
        [_find_libreoffice(), "--headless", "--convert-to", "xlsx", "--outdir", out, src_path],
        capture_output=True, timeout=60,
    )
    return os.path.join(out, Path(src_path).stem + ".xlsx")


def leer_excel(source) -> dict:
    """Lee un archivo XLS/XLSX o CSV y retorna dict {nombre_hoja: DataFrame}.

    Acepta ruta (str) o BytesIO (upload de Streamlit).
    Para CSV: detecta separador y encoding automáticamente.
    Para XLS: cascada de intentos ante archivos corruptos (común en Colppy):
      1. pandas/xlrd  2. python-calamine  3. LibreOffice headless
    """
    # ── CSV ──────────────────────────────────────────────────────────────────
    _name = source if isinstance(source, str) else getattr(source, "name", "")
    if str(_name).lower().endswith(".csv"):
        try:
            if isinstance(source, str):
                raw = open(source, "rb").read()
            else:
                source.seek(0)
                raw = source.read()
                source.seek(0)
            for _enc in ("utf-8-sig", "utf-8", "latin-1", "cp1252"):
                try:
                    df_csv = pd.read_csv(
                        BytesIO(raw), sep=None, engine="python",
                        header=None, encoding=_enc, dtype=str,
                    )
                    if len(df_csv.columns) >= 1:
                        return {"Hoja1": df_csv}
                except Exception:
                    continue
        except Exception as e:
            raise ValueError(f"No se pudo leer el CSV: {e}") from e

    # ── Excel ─────────────────────────────────────────────────────────────────
    tmp_path = tmp_dir = None

    def _read(src_or_bytes, engine=None):
        kwargs = dict(sheet_name=None, header=None)
        if engine:
            kwargs["engine"] = engine
        if isinstance(src_or_bytes, str):
            return pd.read_excel(src_or_bytes, **kwargs)
        src_or_bytes.seek(0)
        return pd.read_excel(src_or_bytes, **kwargs)

    # Intento 1: engine por defecto (xlrd para .xls, openpyxl para .xlsx)
    try:
        return _read(source)
    except Exception:
        pass

    # Intento 2: calamine (Rust — más tolerante con compound-document corruption)
    try:
        return _read(source, engine="calamine")
    except Exception:
        pass

    # Intento 3: LibreOffice headless — convierte a XLSX y relee
    _MSG_LO = (
        "No se pudo leer el archivo XLS.\n"
        "Intentá exportarlo como XLSX desde Colppy, o instalá LibreOffice "
        "para que la conversión automática funcione."
    )
    try:
        if isinstance(source, str):
            src = source
        else:
            source.seek(0)
            fd, src = tempfile.mkstemp(suffix=".xls")
            with os.fdopen(fd, "wb") as f:
                f.write(source.read())
            tmp_path = src

        try:
            xlsx = _libreoffice_xlsx(src)
        except Exception as lo_err:
            raise FileNotFoundError(_MSG_LO) from lo_err

        tmp_dir = os.path.dirname(xlsx)

        if not os.path.exists(xlsx):
            raise FileNotFoundError(_MSG_LO)

        try:
            return pd.read_excel(xlsx, sheet_name=None, header=None, engine="openpyxl")
        except Exception as read_err:
            raise ValueError(
                f"{_MSG_LO}\nDetalle técnico: {read_err}"
            ) from read_err
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.remove(tmp_path)
        if tmp_dir and os.path.isdir(tmp_dir):
            shutil.rmtree(tmp_dir, ignore_errors=True)


def _mejor_hoja(raw: dict) -> pd.DataFrame:
    """Selecciona la hoja de datos más relevante de un dict {nombre: DataFrame}.

    Prioriza hojas nombradas con keywords conocidos de Colppy; en su defecto
    retorna la hoja con más filas (descarta hojas de parámetros/config).
    """
    if len(raw) == 1:
        return next(iter(raw.values()))
    _prio_kw = ["libro iva", "listado iva", "iva compras", "comprobantes", "datos"]
    for name, df in raw.items():
        name_l = str(name).lower()
        if any(kw in name_l for kw in _prio_kw):
            return df
    return max(raw.values(), key=lambda d: d.shape[0])


def _detectar_formato_colppy(source) -> str:
    """Retorna 'libro' si el archivo es Libro IVA Compras, 'listado' en otro caso."""
    try:
        raw = leer_excel(source)
        if hasattr(source, "seek"):
            source.seek(0)
        for name in raw:
            if "libro" in str(name).lower() and "iva" in str(name).lower():
                return "libro"
        sheet = _mejor_hoja(raw)
        header = sheet.iloc[0].astype(str).str.lower()
        if header.str.contains(r"suc\.", na=False).any() and header.str.contains("letra", na=False).any():
            return "libro"
    except Exception:
        pass
    return "listado"


def _find_header(sheet: pd.DataFrame, keyword: str,
                 fallbacks: list[str] | None = None) -> int:
    """Busca la primera fila que contenga `keyword` y retorna su índice.

    Colppy y ARCA insertan filas de metadatos antes del encabezado real,
    por lo que no se puede asumir que la fila 0 es el header.
    Si no se encuentra `keyword`, intenta con `fallbacks` en orden.
    """
    for kw in [keyword] + (fallbacks or []):
        for i, row in sheet.iterrows():
            if row.astype(str).str.contains(kw, case=False, na=False).any():
                return i
    return None


# ── Helpers de carga compartidos ─────────────────────────────────────────────

def _agg_total(x: pd.Series):
    """Para groupby.agg: primer valor no-cero del Total de un grupo."""
    non_zero = x[x != 0]
    return non_zero.iloc[0] if len(non_zero) > 0 else 0


def _origen_from_cuit_tipo(cuit: str, tipo: str = "") -> str:
    """'Exterior' si el CUIT comienza con 55 o el tipo es FCC/FCE; 'Nacional' en otro caso."""
    if tipo and str(tipo).lower() in EXT_PREFIXES:
        return "Exterior"
    cuit_clean = re.sub(r"[^0-9]", "", str(cuit))
    return "Exterior" if cuit_clean.startswith("55") else "Nacional"


# ── Carga Listado IVA Compras (Colppy) ───────────────────────────────────────

def _load_libro_iva(source) -> "pd.DataFrame | None":
    """Carga el Libro IVA Compras de Colppy.

    Diferencias con el Listado IVA Compras:
    - Tiene dos hojas: 'Parametros' (fechas) y 'Libro IVA Compras ' (datos).
    - No hay columna 'Comprobante': se construye como Suc. + Numero.
    - IVA está en columnas separadas por alícuota (Iva 21%, Iva 10.5%, Iva 27%).
    - El tipo de comprobante viene en 'Tipo Comprob.' con texto libre.
    - Cada fila es un comprobante único (sin múltiples filas por alícuota).
    """
    raw = leer_excel(source)
    sheet = _mejor_hoja(raw)

    # Header en la primera fila del sheet de datos
    hr = _find_header(sheet, "Suc.", ["Numero", "Proveedor", "Nro.Doc."])
    if hr is None:
        hr = 0
    header_cols = [str(c).strip() for c in sheet.iloc[hr]]

    df = sheet.iloc[hr + 1:].copy()
    df.columns = header_cols
    df = df.reset_index(drop=True)

    # Descartar filas sin Suc. numérico (totales, pie de página, etc.)
    df = df[pd.to_numeric(df.get("Suc.", pd.Series(dtype=object)), errors="coerce").notna()].copy()
    if df.empty:
        st.error("No se encontraron comprobantes válidos en el Libro IVA Compras.")
        return None

    # Construir Comprobante: SSSSS-NNNNNNNN
    suc = pd.to_numeric(df["Suc."], errors="coerce").fillna(0).astype(int)
    num = pd.to_numeric(df["Numero"], errors="coerce").fillna(0).astype(int)
    df["Comprobante"] = suc.apply(lambda x: f"{x:05d}") + "-" + num.apply(lambda x: f"{x:08d}")
    df = df[df["Comprobante"].str.match(r"^\d{5}-\d{8}$")].copy()

    # Tipo: "Factura de Compra"/"Credito de Compra" + Letra → "FAC-A", "NCC-A", etc.
    tipo_raw = df.get("Tipo Comprob.", pd.Series("", index=df.index)).astype(str).str.lower()
    letra    = df.get("Letra", pd.Series("A", index=df.index)).astype(str).str.strip().str.upper()
    def _map_tipo(t, l):
        if "credito" in t:
            return f"NCC-{l}"
        if "debito" in t:
            return f"NDB-{l}"
        return f"FAC-{l}"
    df["Tipo"] = [_map_tipo(t, l) for t, l in zip(tipo_raw, letra)]

    # IVA total: suma de todas las columnas de alícuotas
    iva_cols = [c for c in df.columns if re.match(r"^iva\s*\d", c.lower().strip())]
    df["IVA"] = (
        sum(pd.to_numeric(df[c], errors="coerce").fillna(0) for c in iva_cols)
        if iva_cols else pd.Series(0.0, index=df.index)
    )

    df["Fecha_Factura"] = df.get("Fec. Factura", pd.Series("", index=df.index))
    df["CUIT_DNI"]      = df.get("Nro.Doc.",     pd.Series("", index=df.index)).astype(str).str.strip()
    df["Razon_Social"]  = df.get("Proveedor",    pd.Series("", index=df.index))
    df["Condicion_IVA"] = df.get("Tipo Iva",     pd.Series("", index=df.index))
    df["Neto"]          = pd.to_numeric(df.get("Gravado",   pd.Series(0.0, index=df.index)), errors="coerce").fillna(0)
    df["Total"]         = pd.to_numeric(df.get("Total",     pd.Series(0.0, index=df.index)), errors="coerce").fillna(0)

    # Groupby Comprobante (por si hubiera filas duplicadas)
    agg = df.groupby("Comprobante", as_index=False).agg(
        Fecha_Factura=("Fecha_Factura", "first"),
        Tipo=("Tipo", "first"),
        CUIT_DNI=("CUIT_DNI", "first"),
        Razon_Social=("Razon_Social", "first"),
        Condicion_IVA=("Condicion_IVA", "first"),
        Neto=("Neto", "sum"),
        IVA=("IVA", "sum"),
        Total=("Total", _agg_total),
    )

    agg["Origen"]    = agg.apply(lambda r: _origen_from_cuit_tipo(r["CUIT_DNI"]), axis=1)
    agg["CUIT_norm"] = agg["CUIT_DNI"].astype(str).str.replace(r"[^0-9]", "", regex=True)

    tipo_label = {
        "FAC-A": "Factura A", "FAC-B": "Factura B", "FAC-C": "Factura C",
        "NCC-A": "NC A", "NCC-B": "NC B", "NCC-C": "NC C",
        "NDB-A": "ND A", "NDB-B": "ND B", "NDB-C": "ND C",
    }
    agg["Tipo_Doc"] = agg["Tipo"].map(tipo_label).fillna(agg["Tipo"])

    n = len(agg)
    st.info(f"Libro IVA Compras detectado — {n} comprobantes cargados.", icon="📖")
    return agg


def load_listado_iva(source, mapeo: dict | None = None):
    """Carga y normaliza el Listado IVA Compras exportado de Colppy.

    Pasos:
    1. Ubica la fila de encabezado buscando "Comprobante".
    2. Filtra solo las filas cuyo Comprobante tiene formato XXXXX-YYYYYYYY,
       descartando filas de totales y subtotales que Colppy agrega al final.
    3. Agrupa por Comprobante sumando Neto e IVA (Colppy puede tener una fila
       por alícuota de IVA), y toma el primer Total no-cero.
    4. Clasifica el origen (Nacional / Exterior) y aplica etiquetas legibles.

    Retorna un DataFrame con una fila por comprobante, o None si el archivo
    no tiene el formato esperado.
    """
    if mapeo is None:
        mapeo = copy.deepcopy(MAPEOS_DEFAULT["listado"]["Colppy"])
    col = mapeo["columnas"]

    # Auto-detectar Libro IVA Compras (formato diferente del Listado)
    fmt = _detectar_formato_colppy(source)
    if hasattr(source, "seek"):
        source.seek(0)
    if fmt == "libro":
        return _load_libro_iva(source)

    raw   = leer_excel(source)
    sheet = _mejor_hoja(raw)
    hr    = _find_header(sheet, mapeo.get("header_keyword", "Comprobante"), _LISTADO_FALLBACKS)
    if hr is None:
        st.error(
            f"No se encontró el encabezado en el Listado IVA. "
            f"Verificá que sea el **Listado IVA Compras** de Colppy. "
            f"Si usás otro formato, configurá el emparejamiento de columnas."
        )
        return None

    df = sheet.copy()
    df.columns = df.iloc[hr]
    df = df.iloc[hr + 1:].reset_index(drop=True)
    df.columns.name = None
    df.columns = [str(c).strip() for c in df.columns]

    df = df.rename(columns={
        col.get("fecha",         "Fecha Factura"):  "Fecha_Factura",
        col.get("tipo",          "Tipo"):           "Tipo",
        col.get("comprobante",   "Comprobante"):    "Comprobante",
        col.get("cuit",          "CUIT/DNI"):       "CUIT_DNI",
        col.get("razon_social",  "Razón Social"):   "Razon_Social",
        col.get("condicion_iva", "Condición IVA"):  "Condicion_IVA",
        col.get("neto",          "Neto"):           "Neto",
        col.get("iva",           "IVA"):            "IVA",
        col.get("total",         "Total"):          "Total",
        "Perc. IIBB":                               "Perc_IIBB",
        "Perc. IVA":                                "Perc_IVA",
    })

    # Mantener solo filas de comprobantes reales; las de totales no tienen este formato
    valid = df["Comprobante"].astype(str).str.match(r"^\d{5}-\d{8}$")
    df    = df[valid].copy()

    for _col_n in ["Neto", "IVA", "Total", "Perc_IIBB", "Perc_IVA"]:
        if _col_n in df.columns:
            df[_col_n] = pd.to_numeric(df[_col_n], errors="coerce").fillna(0)

    # Campos opcionales: si el usuario no los mapeó, agregar columna vacía
    for _opt in ["Fecha_Factura", "Tipo", "Razon_Social", "Condicion_IVA"]:
        if _opt not in df.columns:
            df[_opt] = ""

    # Un comprobante puede tener N filas (una por alícuota de IVA):
    # sumamos Neto e IVA; para Total tomamos el primer valor no-cero
    agg = df.groupby("Comprobante", as_index=False).agg(
        Fecha_Factura=("Fecha_Factura", "first"),
        Tipo=("Tipo", "first"),
        CUIT_DNI=("CUIT_DNI", "first"),
        Razon_Social=("Razon_Social", "first"),
        Condicion_IVA=("Condicion_IVA", "first"),
        Neto=("Neto", "sum"),
        IVA=("IVA", "sum"),
        Total=("Total", _agg_total),
    )

    agg["Origen"]    = agg.apply(lambda r: _origen_from_cuit_tipo(r["CUIT_DNI"], r["Tipo"]), axis=1)
    agg["CUIT_norm"] = agg["CUIT_DNI"].astype(str).str.replace(r"[^0-9]", "", regex=True)

    tipo_label = {
        "FAC-A": "Factura A", "FAC-B": "Factura B", "FAC-C": "Factura C",
        "FCC-A": "Ext. A", "FCC-B": "Ext. B", "FCC-C": "Ext. C",
        "NCC-A": "NC A", "NCC-B": "NC B", "NCC-C": "NC C",
        "FCA-A": "FC Elect. A",
    }
    agg["Tipo_Doc"] = agg["Tipo"].map(tipo_label).fillna(agg["Tipo"])

    return agg


# ── Carga Mis Comprobantes Recibidos (ARCA) ───────────────────────────────────

def _es_nota_credito_arca(tipo: str) -> bool:
    """True si el tipo de comprobante ARCA es una Nota de Crédito."""
    t = str(tipo).lower()
    return any(nc in t for nc in NC_ARCA)


def load_arca(source, mapeo: dict | None = None):
    """Carga y normaliza el reporte 'Mis Comprobantes Recibidos' de ARCA.

    Pasos:
    1. Ubica el encabezado buscando "Punto de Venta".
    2. Construye la clave de comprobante en formato XXXXX-YYYYYYYY, que es
       como Colppy lo registra, para poder hacer el JOIN.
    3. Convierte todos los importes a numérico.
    4. Detecta Notas de Crédito y multiplica sus importes por -1: ARCA siempre
       exporta montos positivos, pero en el libro contable las NC son negativas.
    5. Calcula Neto comparable = Neto Gravado + Neto No Gravado + Op. Exentas.
    6. Para Factura C (monotributistas), ARCA no desglosa el Neto; deriva:
       Neto = Imp.Total - Total IVA - Otros Tributos.

    Retorna un DataFrame con una fila por comprobante.
    """
    if mapeo is None:
        mapeo = copy.deepcopy(MAPEOS_DEFAULT["arca"]["ARCA"])
    col = mapeo["columnas"]

    raw   = leer_excel(source)
    sheet = _mejor_hoja(raw)
    hr    = _find_header(sheet, mapeo.get("header_keyword", "Punto de Venta"))
    if hr is None:
        st.error(f"No se encontró encabezado '{mapeo.get('header_keyword','Punto de Venta')}' en Mis Comprobantes ARCA.")
        return None

    df = sheet.copy()
    df.columns = df.iloc[hr]
    df = df.iloc[hr + 1:].reset_index(drop=True)
    df.columns.name = None
    df.columns = [str(c).strip() for c in df.columns]

    # Construir clave en formato XXXXX-YYYYYYYY usando los campos configurados
    col_pto  = col.get("punto_venta", "Punto de Venta")
    col_num  = col.get("numero",      "Número Desde")
    _missing = [c for c in [col_pto, col_num] if c not in df.columns]
    if _missing:
        st.error(f"Columnas no encontradas en el archivo ARCA: {_missing}. Revisá el emparejamiento de columnas.")
        return None
    df[col_pto] = pd.to_numeric(df[col_pto], errors="coerce").fillna(0).astype(int)
    df[col_num] = pd.to_numeric(df[col_num], errors="coerce").fillna(0).astype(int)
    df["Comprobante_Key"] = df.apply(
        lambda r: f"{r[col_pto]:05d}-{r[col_num]:08d}", axis=1
    )

    # Todos los campos de importe usando nombres del mapeo con fallback a los de ARCA
    c = mapeo["columnas"]
    COLS_IMPORTE = [
        c.get("neto_gravado",    "Neto Gravado Total"),
        c.get("neto_no_gravado", "Neto No Gravado"),
        c.get("op_exentas",      "Op. Exentas"),
        c.get("otros_tributos",  "Otros Tributos"),
        c.get("total_iva",       "Total IVA"),
        c.get("total",           "Imp. Total"),
    ]
    for col_i in COLS_IMPORTE:
        if col_i in df.columns:
            df[col_i] = pd.to_numeric(df[col_i], errors="coerce").fillna(0)

    col_tipo = c.get("tipo", "Tipo")
    if col_tipo and col_tipo in df.columns:
        df["es_NC"] = df[col_tipo].apply(_es_nota_credito_arca)
    else:
        df["es_NC"] = False
        col_tipo = None
    signo = df["es_NC"].map({True: -1, False: 1})
    for col in COLS_IMPORTE:
        if col in df.columns:
            df[col] = df[col] * signo

    # Neto comparable usando nombres mapeados
    c_ng  = c.get("neto_gravado",    "Neto Gravado Total")
    c_nng = c.get("neto_no_gravado", "Neto No Gravado")
    c_oe  = c.get("op_exentas",      "Op. Exentas")
    c_ot  = c.get("otros_tributos",  "Otros Tributos")
    c_tiva= c.get("total_iva",       "Total IVA")
    c_tot = c.get("total",           "Imp. Total")

    df["Neto_Total_ARCA"] = (
        df.get(c_ng,  pd.Series(0, index=df.index))
        + df.get(c_nng, pd.Series(0, index=df.index))
        + df.get(c_oe,  pd.Series(0, index=df.index))
    )

    sin_desglose = (df["Neto_Total_ARCA"] == 0) & (df.get(c_tot, pd.Series(0, index=df.index)) != 0)
    df.loc[sin_desglose, "Neto_Total_ARCA"] = (
        df.loc[sin_desglose, c_tot]
        - df.loc[sin_desglose, c_tiva]
        - df.loc[sin_desglose, c_ot]
    )
    df["neto_derivado"] = sin_desglose

    tipo_label_arca = {
        "1 - Factura A":         "Factura A",
        "2 - Nota de Débito A":  "N.Débito A",
        "3 - Nota de Crédito A": "N.Crédito A",
        "6 - Factura B":         "Factura B",
        "7 - Nota de Débito B":  "N.Débito B",
        "8 - Nota de Crédito B": "N.Crédito B",
        "11 - Factura C":        "Factura C",
        "12 - Nota de Débito C": "N.Débito C",
        "13 - Nota de Crédito C":"N.Crédito C",
    }
    if col_tipo and col_tipo in df.columns:
        df["Tipo_Doc_ARCA"] = df[col_tipo].map(tipo_label_arca).fillna(df[col_tipo])
    else:
        df["Tipo_Doc_ARCA"] = ""

    # Estandarizar nombres de columnas a los esperados por conciliar()
    c_fecha = c.get("fecha", "Fecha")
    c_cuit  = c.get("cuit_emisor",  "Nro. Doc. Emisor")
    c_denom = c.get("denominacion", "Denominación Emisor")
    col_std = {
        c_tiva: "Total IVA", c_ot: "Otros Tributos", c_tot: "Imp. Total",
    }
    if c_fecha and c_fecha in df.columns:
        col_std[c_fecha] = "Fecha"
    if col_tipo and col_tipo in df.columns:
        col_std[col_tipo] = "Tipo"
    if c_cuit and c_cuit in df.columns:
        col_std[c_cuit] = "Nro. Doc. Emisor"
    if c_denom and c_denom in df.columns:
        col_std[c_denom] = "Denominación Emisor"
    df = df.rename(columns={k: v for k, v in col_std.items() if k != v})

    # Asegurar columnas opcionales con valor vacío si no fueron mapeadas
    for _opt in ["Fecha", "Tipo", "Denominación Emisor"]:
        if _opt not in df.columns:
            df[_opt] = ""

    df["CUIT_norm"] = df.get("Nro. Doc. Emisor", pd.Series("", index=df.index)).astype(str).str.replace(r"[^0-9]", "", regex=True)

    return df


# ── Conciliación ──────────────────────────────────────────────────────────────

def conciliar(df_listado, df_arca, tolerancia: float):
    """Cruza el Listado con ARCA y clasifica cada comprobante.

    Lógica:
    - LEFT JOIN del Listado sobre ARCA por clave de comprobante.
    - Para Neto, IVA y Total calcula la diferencia absoluta.
    - Un campo "Match" es True si la diferencia ≤ tolerancia.
    - "Conciliado" = los tres campos hacen match.
    - Estado:
        "Conciliado"              → todos los montos coinciden
        "Total OK / Sin desglose" → Total OK pero Neto difiere (Factura C derivada)
        "Diferencia detectada"    → discrepancia real en algún importe
        "Sin match en ARCA"       → el comprobante no figura en ARCA

    Retorna (sheet1, sheet2, sheet3):
        sheet1: todos los comprobantes del Listado con columnas de comparación
        sheet2: comprobantes solo en Listado (sin match en ARCA)
        sheet3: comprobantes solo en ARCA (no están en el Listado)
    """
    # Deduplicar ARCA primero para que el JOIN no genere filas fantasma
    dupes = df_arca[df_arca.duplicated("Comprobante_Key", keep=False)]
    if not dupes.empty:
        n_keys = dupes["Comprobante_Key"].nunique()
        st.warning(
            f"ARCA contiene {len(dupes)} filas duplicadas para {n_keys} comprobante(s). "
            "Se conserva la primera ocurrencia de cada uno."
        )
        df_arca = df_arca.drop_duplicates("Comprobante_Key", keep="first")

    # Reducir ARCA a las columnas necesarias para el JOIN (ya deduplicado)
    arca_slim = df_arca[[c for c in [
        "Comprobante_Key", "CUIT_norm", "Neto_Total_ARCA", "Total IVA", "Otros Tributos", "Imp. Total",
        "Fecha", "Tipo_Doc_ARCA", "Denominación Emisor", "Nro. Doc. Emisor",
        "es_NC", "neto_derivado",
    ] if c in df_arca.columns]].rename(columns={
        "Comprobante_Key":    "ARCA_Key",
        "CUIT_norm":          "ARCA_CUIT_norm",
        "Neto_Total_ARCA":    "ARCA_Neto",
        "Total IVA":          "ARCA_IVA",
        "Otros Tributos":     "ARCA_OtrosTrib",
        "Imp. Total":         "ARCA_Total",
        "Fecha":              "ARCA_Fecha",
        "Tipo_Doc_ARCA":      "ARCA_Tipo",
        "Denominación Emisor":"ARCA_Denominacion",
        "Nro. Doc. Emisor":   "ARCA_CUIT",
        "es_NC":              "ARCA_es_NC",
        "neto_derivado":      "ARCA_Neto_Derivado",
    })

    # Exterior companies (FCC-*/FCE-*) have no Argentine CUIT; match on Comprobante only.
    # National companies: full key match (Comprobante + CUIT_norm) to avoid false positives.
    mask_ext = (
        df_listado.get("Origen", pd.Series("Nacional", index=df_listado.index)) == "Exterior"
    )
    listado_nac = df_listado[~mask_ext]
    listado_ext = df_listado[mask_ext]

    merged_nac = pd.merge(
        listado_nac, arca_slim,
        left_on=["Comprobante", "CUIT_norm"],
        right_on=["ARCA_Key", "ARCA_CUIT_norm"],
        how="left",
    )
    merged_ext = pd.merge(
        listado_ext, arca_slim,
        left_on="Comprobante",
        right_on="ARCA_Key",
        how="left",
    )
    merged = pd.concat([merged_nac, merged_ext], ignore_index=True, sort=False)
    merged["Existe_en_ARCA"] = merged["ARCA_Key"].notna()

    tol = tolerancia
    for campo in ["Neto", "IVA", "Total"]:
        merged[f"Dif_{campo}"] = (
            merged[campo].fillna(0) - merged[f"ARCA_{campo}"].fillna(0)
        ).abs()

    merged["Match_Neto"]  = merged["Existe_en_ARCA"] & (merged["Dif_Neto"]  <= tol)
    merged["Match_IVA"]   = merged["Existe_en_ARCA"] & (merged["Dif_IVA"]   <= tol)
    merged["Match_Total"] = merged["Existe_en_ARCA"] & (merged["Dif_Total"] <= tol)
    merged["Conciliado"]  = merged["Match_Neto"] & merged["Match_IVA"] & merged["Match_Total"]

    def _estado(row):
        if not row["Existe_en_ARCA"]:
            if row.get("Origen", "Nacional") == "Exterior":
                return "Exterior / No en ARCA"
            return "Sin match en ARCA"
        if row["Conciliado"]:
            return "Conciliado"
        # Factura C (monotributista): ARCA no desglosa Neto/IVA; el Neto se deriva
        # de Imp.Total. Si el Total coincide, aceptamos la falta de desglose aunque
        # Neto o IVA difieran: no es una diferencia genuina sino un límite del reporte.
        if row["Match_Total"] and row.get("ARCA_Neto_Derivado", False):
            return "Total OK / Sin desglose"
        return "Diferencia detectada"

    merged["Estado"] = merged.apply(_estado, axis=1)

    sheet1 = merged[[c for c in [
        "Estado", "Comprobante", "Fecha_Factura", "Tipo_Doc", "Origen",
        "CUIT_DNI", "CUIT_norm", "Razon_Social",
        "Neto", "IVA", "Total",
        "Existe_en_ARCA", "ARCA_Denominacion", "ARCA_CUIT", "ARCA_Fecha", "ARCA_Tipo",
        "ARCA_es_NC", "ARCA_Neto_Derivado",
        "ARCA_Neto", "ARCA_IVA", "ARCA_OtrosTrib", "ARCA_Total",
        "Dif_Neto", "Dif_IVA", "Dif_Total",
        "Match_Neto", "Match_IVA", "Match_Total", "Conciliado",
    ] if c in merged.columns]].copy()

    # Sheet 2: solo los que no encontraron contraparte en ARCA
    sheet2 = merged[~merged["Existe_en_ARCA"]][[c for c in [
        "Comprobante", "Fecha_Factura", "Tipo_Doc", "Origen",
        "CUIT_DNI", "Razon_Social", "Condicion_IVA", "Neto", "IVA", "Total",
    ] if c in merged.columns]].copy()

    # Sheet 3: comprobantes en ARCA que no figuran en ninguna fila del JOIN.
    # Usamos las ARCA_Key que efectivamente se unieron (no las del listado), para
    # evitar excluir entradas ARCA cuyo comprobante existe en el listado pero no
    # coincidió en el JOIN (p.ej. CUIT distinto en proveedores nacionales).
    arca_matched_keys = set(merged["ARCA_Key"].dropna())
    keep = [c for c in [
        "Comprobante_Key", "Fecha", "Tipo_Doc_ARCA", "Nro. Doc. Emisor",
        "Denominación Emisor", "Neto Gravado Total", "Neto No Gravado", "Op. Exentas",
        "Otros Tributos", "Total IVA", "Imp. Total", "es_NC",
    ] if c in df_arca.columns]
    sheet3 = df_arca[~df_arca["Comprobante_Key"].isin(arca_matched_keys)][keep].copy()

    return sheet1, sheet2, sheet3


# ── Persistencia CSV ──────────────────────────────────────────────────────────

def _detectar_periodo(s1: pd.DataFrame) -> str:
    """Deriva el período (mes/año) procesado desde las fechas de facturas del Listado.

    Toma el mes/año más frecuente en Fecha_Factura. Retorna string tipo '2025-11'
    o '' si no se puede determinar.
    """
    if s1 is None or "Fecha_Factura" not in s1.columns:
        return ""
    fechas = pd.to_datetime(s1["Fecha_Factura"], dayfirst=True, errors="coerce").dropna()
    if fechas.empty:
        return ""
    counts = fechas.dt.to_period("M").value_counts()
    if counts.empty:
        return ""
    # En caso de empate, tomar el período más reciente (determinista)
    max_count = counts.iloc[0]
    candidates = counts[counts == max_count].index
    return str(max(candidates))

def _hash_s1(s1: pd.DataFrame | None) -> str:
    """Hash del resultado de conciliación para detectar cambios entre corridas.

    Compara solo [Comprobante, Estado, Conciliado] ordenado: si el conjunto de
    comprobantes y su estado no cambiaron, no vale la pena guardar un snapshot.
    Usa pd.util.hash_pandas_object (determinista para los mismos datos).
    """
    if s1 is None:
        return ""
    try:
        key = s1[["Comprobante", "Estado", "Conciliado"]].sort_values("Comprobante").reset_index(drop=True)
        h   = pd.util.hash_pandas_object(key, index=False).sum()
        return str(h)
    except Exception:
        return ""


def _restore_bools(df: pd.DataFrame) -> pd.DataFrame:
    """Garantiza que las columnas booleanas sean dtype bool.

    Acepta tanto strings "True"/"False" (legacy CSV) como valores nativos
    bool o 0/1 (JSON). Usa fillna(False) para que .astype(bool) no falle
    en pandas 2.x si existen NaN residuales.
    """
    for col in BOOL_COLS:
        if col in df.columns:
            df[col] = (
                df[col]
                .map({
                    "True": True,  "False": False,
                    "true": True,  "false": False,
                    "1":    True,  "0":     False,
                    True:   True,  False:   False,
                    1:      True,  0:       False,
                })
                .fillna(False)
                .astype(bool)
            )
    return df


def cargar_csv():
    """Lee el resultado más reciente de la BD. Retorna (s1, s2, s3, meta) o (None,None,None,{})."""
    try:
        con = _db_con()
        row = con.execute(
            "SELECT * FROM conciliaciones ORDER BY ts DESC LIMIT 1"
        ).fetchone()
        con.close()
        if row is None:
            return None, None, None, {}
        s1 = _restore_bools(pd.read_json(StringIO(row["s1_json"]), orient="records", dtype=False))
        s2 = pd.read_json(StringIO(row["s2_json"]), orient="records", dtype=False)
        s3 = pd.read_json(StringIO(row["s3_json"]), orient="records", dtype=False)
        meta = {
            "fecha_proceso": row["fecha_proceso"],
            "periodo":       row["periodo"],
            "tolerancia":    row["tolerancia"],
            "n_listado":     row["n_listado"],
            "n_arca":        row["n_arca"],
            "conciliados":   row["conciliados"],
            "diferencias":   row["diferencias"],
        }
        return s1, s2, s3, meta
    except Exception:
        return None, None, None, {}


def guardar_csv(s1, s2, s3, tolerancia: float) -> bool:
    """Persiste la conciliación en SQLite. Retorna True si hubo cambios respecto al snapshot anterior."""
    try:
        con = _db_con()
        prev = con.execute(
            "SELECT ts, s1_json FROM conciliaciones ORDER BY ts DESC LIMIT 1"
        ).fetchone()
        prev_s1 = None
        if prev:
            try:
                prev_s1 = pd.read_json(StringIO(prev["s1_json"]), orient="records", dtype=False)
            except Exception:
                pass

        hubo_cambio = _hash_s1(s1) != _hash_s1(prev_s1)
        if not hubo_cambio:
            con.close()
            return False

        ts      = datetime.now().strftime("%Y%m%d_%H%M%S")
        periodo = _detectar_periodo(s1)
        con.execute(
            "INSERT INTO conciliaciones "
            "(ts,periodo,tolerancia,n_listado,n_arca,conciliados,diferencias,"
            "fecha_proceso,s1_json,s2_json,s3_json) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (ts, periodo, tolerancia, len(s1),
             len(s3) + int(s1["Existe_en_ARCA"].sum()),
             int(s1["Conciliado"].sum()),
             int((s1["Estado"] == "Diferencia detectada").sum()),
             datetime.now().isoformat(),
             s1.to_json(orient="records", force_ascii=False, date_format="iso"),
             s2.to_json(orient="records", force_ascii=False, date_format="iso"),
             s3.to_json(orient="records", force_ascii=False, date_format="iso"))
        )
        con.commit()
        con.close()
        return True
    except Exception:
        return False


def listar_historicos() -> list[dict]:
    """Lee los metadatos de todos los snapshots en orden descendente."""
    try:
        con = _db_con()
        rows = con.execute(
            "SELECT ts,periodo,tolerancia,n_listado,conciliados,fecha_proceso "
            "FROM conciliaciones ORDER BY ts DESC"
        ).fetchall()
        con.close()
        result = []
        for row in rows:
            ts      = row["ts"]
            periodo = str(row["periodo"] or "").strip()
            try:
                fecha_label = datetime.strptime(ts, "%Y%m%d_%H%M%S").strftime("%d/%m/%Y %H:%M")
            except Exception:
                fecha_label = ts
            label = f"{periodo}  ({fecha_label})" if periodo else fecha_label
            result.append({
                "ts":      ts,
                "label":   label,
                "periodo": periodo,
                "conc":    int(row["conciliados"] or 0),
                "n":       int(row["n_listado"] or 0),
                "tol":     float(row["tolerancia"] or 0),
            })
        return result
    except Exception:
        return []


def cargar_historico(ts: str):
    """Carga s1, s2, s3 de un snapshot por ts. Retorna (s1, s2, s3) o (None, None, None)."""
    try:
        con = _db_con()
        row = con.execute(
            "SELECT s1_json, s2_json, s3_json FROM conciliaciones WHERE ts=?", (ts,)
        ).fetchone()
        con.close()
        if row is None:
            return None, None, None
        s1 = _restore_bools(pd.read_json(StringIO(row["s1_json"]), orient="records", dtype=False))
        s2 = pd.read_json(StringIO(row["s2_json"]), orient="records", dtype=False)
        s3 = pd.read_json(StringIO(row["s3_json"]), orient="records", dtype=False)
        return s1, s2, s3
    except Exception:
        return None, None, None


# ── Exportación Excel ─────────────────────────────────────────────────────────

def generar_excel(s1, s2, s3) -> bytes:
    """Genera un Excel de tres hojas con formato profesional.

    Convenciones de color:
      - Verde: match / conciliado
      - Rojo: diferencia / no match
      - Amarillo: advertencia (Total OK sin desglose)
      - Gris: sin información (sin match en ARCA)
      - Números negativos en rojo (NC)

    Todas las hojas tienen encabezado fijo (freeze panes) y autofiltro.
    """
    buf = BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter") as writer:
        wb = writer.book
        hdr     = wb.add_format({"bold":True,"font_color":"white","bg_color":"#1e3a5f","border":1,"align":"center","valign":"vcenter"})
        f_ok    = wb.add_format({"bg_color":"#dcfce7","font_color":"#15803d","bold":True,"align":"center"})
        f_ko    = wb.add_format({"bg_color":"#fee2e2","font_color":"#b91c1c","bold":True,"align":"center"})
        f_num   = wb.add_format({"num_format":"#,##0.00"})
        f_dok   = wb.add_format({"num_format":"#,##0.00","bg_color":"#dcfce7"})
        f_dko   = wb.add_format({"num_format":"#,##0.00","bg_color":"#fee2e2"})
        f_neg   = wb.add_format({"num_format":"#,##0.00","font_color":"#dc2626"})
        f_estado = {
            "Conciliado":              wb.add_format({"bg_color":"#dcfce7","font_color":"#15803d","bold":True}),
            "Total OK / Sin desglose": wb.add_format({"bg_color":"#fef9c3","font_color":"#713f12"}),
            "Diferencia detectada":    wb.add_format({"bg_color":"#fee2e2","font_color":"#b91c1c","bold":True}),
            "Sin match en ARCA":       wb.add_format({"bg_color":"#f1f5f9","font_color":"#64748b"}),
            "Exterior / No en ARCA":   wb.add_format({"bg_color":"#eff6ff","font_color":"#1d4ed8"}),
            "Revisado / Aceptado":     wb.add_format({"bg_color":"#e0f2fe","font_color":"#0369a1","bold":True}),
            "✔️ Revisado / Aceptado":  wb.add_format({"bg_color":"#e0f2fe","font_color":"#0369a1","bold":True}),
        }

        def wsheet(df, name, bool_cols=None, num_cols=None, diff_cols=None, tol=0.07):
            """Escribe un DataFrame en una hoja con formatos por tipo de columna."""
            df.to_excel(writer, sheet_name=name, index=False, startrow=1, header=False)
            ws = writer.sheets[name]
            for c, col in enumerate(df.columns):
                ws.write(0, c, col, hdr)
            for r, row in enumerate(df.itertuples(index=False), 1):
                for c, (col, val) in enumerate(zip(df.columns, row)):
                    nan = not isinstance(val, str) and pd.isna(val) if hasattr(val, "__class__") else False
                    if col == "Estado":
                        ws.write(r, c, "" if nan else str(val), f_estado.get(str(val), wb.add_format()))
                    elif bool_cols and col in bool_cols:
                        ws.write(r, c, "✓" if val is True else "✗", f_ok if val is True else f_ko)
                    elif diff_cols and col in diff_cols:
                        try:
                            v = float(val)
                            ws.write_number(r, c, v, f_dok if v <= tol else f_dko)
                        except (TypeError, ValueError):
                            ws.write(r, c, val)
                    elif num_cols and col in num_cols:
                        try:
                            v = float(val)
                            ws.write_number(r, c, v, f_neg if v < 0 else f_num)
                        except (TypeError, ValueError):
                            ws.write(r, c, "" if nan else val)
                    else:
                        ws.write(r, c, "" if nan else val)
            for c, col in enumerate(df.columns):
                ws.set_column(c, c, min(max(len(str(col)), 10) + 3, 42))
            ws.freeze_panes(1, 0)
            ws.autofilter(0, 0, len(df), len(df.columns) - 1)

        NUM1  = {"Neto","IVA","Total","ARCA_Neto","ARCA_IVA","ARCA_OtrosTrib","ARCA_Total"}
        DIFF  = {"Dif_Neto","Dif_IVA","Dif_Total"}
        BOOL1 = {"Existe_en_ARCA","Match_Neto","Match_IVA","Match_Total","Conciliado","ARCA_es_NC","ARCA_Neto_Derivado"}
        wsheet(s1, "Conciliación",    bool_cols=BOOL1, num_cols=NUM1, diff_cols=DIFF)
        wsheet(s2, "Solo en Listado", num_cols={"Neto","IVA","Total"})
        wsheet(s3, "Solo en ARCA",
               num_cols={"Neto Gravado Total","Neto No Gravado","Op. Exentas",
                         "Otros Tributos","Total IVA","Imp. Total"},
               bool_cols={"es_NC"})

    return buf.getvalue()


# ── Helpers UI ────────────────────────────────────────────────────────────────

def _csv_download(df: pd.DataFrame, label: str, filename: str):
    """Botón de descarga CSV de la vista actualmente filtrada."""
    st.download_button(
        label=label,
        data=df.to_csv(index=False, encoding="utf-8-sig").encode("utf-8-sig"),
        file_name=filename,
        mime="text/csv",
    )


def _fmt_bool(df: pd.DataFrame, cols: list) -> pd.DataFrame:
    """Reemplaza True/False por ✓/✗ para visualización en la tabla."""
    df = df.copy()
    for col in cols:
        if col in df.columns:
            df[col] = df[col].map({True: "✓", False: "✗"})
    return df


_NO_MAPEAR = "— sin mapear —"

def _selectbox_col(label: str, col_sug: str, cols: list, key: str,
                   required: bool = True) -> str:
    """Dropdown de columna. Opcionales incluyen '— sin mapear —' como primera opción."""
    if not cols:
        return col_sug
    base = [c for c in cols if c != col_sug]
    if col_sug and col_sug in cols:
        opts = [col_sug] + base
    else:
        opts = ([col_sug] if col_sug else []) + base
    if not required:
        opts = [_NO_MAPEAR] + [c for c in opts if c != _NO_MAPEAR]
    sel = st.selectbox(label, opts or cols, index=0, key=key,
                       label_visibility="collapsed")
    return "" if sel == _NO_MAPEAR else sel


def _render_mapeo_parejas(cols_l: list, cols_a: list,
                          mapeos_db: dict | None = None) -> tuple[dict, dict]:
    """Panel central de emparejamiento columna-a-columna entre Listado y ARCA.

    Muestra los campos agrupados por propósito. Cada fila tiene:
      [Nombre del campo] | [columna Listado ▾] | [badge] | [columna ARCA ▾]

    Si cols_l es [] (Libro IVA mode), solo muestra el lado ARCA.
    Al pie muestra columnas sin usar de cada archivo.
    * = campo requerido para la conciliación; los demás son opcionales.
    Retorna (columnas_listado, columnas_arca) listos para pasar a load_*().
    """
    sug_l  = st.session_state.get("ml_sug",  {})
    sug_a  = st.session_state.get("ma_sug",  {})
    conf_l = st.session_state.get("ml_conf", {})
    conf_a = st.session_state.get("ma_conf", {})
    es_libro = st.session_state.get("ml_formato") == "libro"

    res_l: dict[str, str] = {}
    res_a: dict[str, str] = {}
    n_warn_req = 0   # warnings en campos requeridos
    n_warn_opt = 0   # warnings en campos opcionales

    # ── Banner Libro IVA Compras ──────────────────────────────────────────────
    if es_libro and cols_l:
        st.info(
            "📖 **Libro IVA Compras** — el Comprobante se construye automáticamente "
            "desde las columnas **Suc. + Letra + Número**.  \n"
            "El resto de columnas puedes ajustar manualmente si tu archivo tiene "
            "nombres distintos.",
            icon=None,
        )

    # ── Perfiles guardados ────────────────────────────────────────────────────
    _mapeos_db = mapeos_db if mapeos_db is not None else cargar_mapeos()
    _perfiles   = [k for k in _mapeos_db if k not in ("listado", "arca")]
    _pc1, _pc2, _pc3 = st.columns([3, 2, 1])
    with _pc1:
        _perfil_sel = st.selectbox(
            "Cargar perfil guardado",
            options=[""] + _perfiles,
            format_func=lambda x: "— sin perfil —" if x == "" else x,
            key="perfil_sel",
            label_visibility="collapsed",
        )
    with _pc2:
        _perfil_nom = st.text_input(
            "Nombre perfil", placeholder="Nombre para guardar…",
            key="perfil_nom", label_visibility="collapsed",
        )
    with _pc3:
        _guardar_ok = st.button("💾 Guardar", key="btn_guardar_perfil",
                                use_container_width=True)

    # Cargar perfil seleccionado → sobreescribir sugerencias
    if _perfil_sel and _perfil_sel in _mapeos_db:
        _cfg = _mapeos_db[_perfil_sel]
        if "columnas_l" in _cfg:
            sug_l  = _cfg["columnas_l"]
            conf_l = {k: "exact" for k in sug_l}
        if "columnas_a" in _cfg:
            sug_a  = _cfg["columnas_a"]
            conf_a = {k: "exact" for k in sug_a}

    st.markdown("<hr style='margin:4px 0 6px;border-color:#3e3e42'>",
                unsafe_allow_html=True)

    # ── Encabezado de columnas ────────────────────────────────────────────────
    h0, h1, h2, h3 = st.columns([2.2, 3.5, 0.7, 3.5])
    h1.markdown(
        "<div style='font-size:.78rem;font-weight:700;color:#9cdcfe;"
        "text-transform:uppercase;letter-spacing:.09em;padding-bottom:3px'>"
        "Listado / Colppy</div>", unsafe_allow_html=True)
    h3.markdown(
        "<div style='font-size:.78rem;font-weight:700;color:#9cdcfe;"
        "text-transform:uppercase;letter-spacing:.09em;padding-bottom:3px'>"
        "ARCA</div>", unsafe_allow_html=True)
    st.markdown("<hr style='margin:0 0 6px;border-color:#3e3e42'>",
                unsafe_allow_html=True)

    def _render_campo(campo: dict, key_prefix: str = ""):
        """Renderiza una fila de emparejamiento (label | dropdown Listado | badge | dropdown ARCA)."""
        lc       = campo.get("l_campo")
        ac       = campo.get("a_campo")
        required = campo.get("required", True)

        cl = conf_l.get(lc, "none") if lc else "exact"
        ca = conf_a.get(ac, "none") if ac else "exact"
        worst = max(cl, ca, key=lambda x: _CONF_RANK.get(x, 4))
        badge, color, tooltip = _CONF_BADGE.get(worst, _CONF_BADGE["none"])

        if worst not in ("exact", "norm"):
            if required:
                n_warn_req_box[0] += 1
            else:
                n_warn_opt_box[0] += 1

        # Etiqueta: texto base + asterisco rojo si requerido
        lbl_base = campo["label"].rstrip(" *")
        if required:
            lbl_html = (
                f"<div style='padding:6px 0;font-size:.96rem;line-height:1.4'>"
                f"<span style='color:#cccccc'>{lbl_base}</span>"
                f"<span style='color:#f14c4c;font-weight:700;font-size:.85rem'> *</span>"
                f"</div>"
            )
        else:
            lbl_html = (
                f"<div style='padding:6px 0;font-size:.92rem;line-height:1.4;"
                f"color:#858585'>{lbl_base}</div>"
            )

        c0, c1, c2, c3 = st.columns([2.2, 3.5, 0.7, 3.5])
        with c0:
            st.markdown(lbl_html, unsafe_allow_html=True)
        with c1:
            _key_l = f"{key_prefix}ml_{lc}" if lc else f"{key_prefix}ml_none"
            if lc and cols_l:
                res_l[lc] = _selectbox_col(
                    lbl_base, sug_l.get(lc, ""), cols_l, _key_l, required=required)
            elif lc:
                res_l[lc] = sug_l.get(lc, "")
        with c2:
            st.markdown(
                f"<div style='text-align:center;padding:4px 0;font-size:1.5rem;"
                f"line-height:1' title='{tooltip}'>{badge}</div>",
                unsafe_allow_html=True)
        with c3:
            _key_a = f"{key_prefix}ma_{ac}" if ac else f"{key_prefix}ma_none"
            if campo.get("a_fijo"):
                st.markdown(
                    f"<div style='padding:6px 0;font-size:.88rem;"
                    f"color:#858585;font-style:italic'>{campo['a_fijo']}</div>",
                    unsafe_allow_html=True)
                for impl in campo.get("a_implícitos", []):
                    res_a[impl] = sug_a.get(impl, CAMPOS_ARCA.get(impl, ""))
            elif ac and cols_a:
                res_a[ac] = _selectbox_col(
                    lbl_base, sug_a.get(ac, ""), cols_a, _key_a, required=required)
            elif ac:
                res_a[ac] = sug_a.get(ac, "")

    # Contadores mutables para acceso desde función anidada
    n_warn_req_box = [0]
    n_warn_opt_box = [0]

    # ── Campos requeridos ─────────────────────────────────────────────────────
    for grupo in GRUPOS_PAREJAS:
        campos_req = [c for c in grupo["campos"] if c.get("required", True)]
        if not campos_req:
            continue
        st.markdown(
            f"<div style='font-size:.76rem;font-weight:700;color:#569cd6;"
            f"text-transform:uppercase;letter-spacing:.08em;"
            f"margin:12px 0 2px'>{grupo['titulo']}</div>",
            unsafe_allow_html=True)
        for campo in campos_req:
            _render_campo(campo)
        st.markdown("<hr style='margin:4px 0 2px;border-color:#3e3e42'>",
                    unsafe_allow_html=True)

    # ── Campos opcionales (colapsados) ────────────────────────────────────────
    campos_opt = [c for g in GRUPOS_PAREJAS for c in g["campos"] if not c.get("required", True)]
    if campos_opt:
        with st.expander(
            f"⚙️ Campos opcionales ({len(campos_opt)}) — fecha, tipo, razón social",
            expanded=False,
        ):
            st.caption("No afectan la conciliación. Se muestran en la tabla de resultados.")
            for campo in campos_opt:
                _render_campo(campo, key_prefix="opt_")

    # Campos ARCA internos (no mostrados como parejas, se auto-asignan)
    for _ic in _ARCA_INTERNOS:
        if _ic not in res_a:
            res_a[_ic] = sug_a.get(_ic, CAMPOS_ARCA.get(_ic, ""))

    # Transferir contadores
    n_warn_req = n_warn_req_box[0]
    n_warn_opt = n_warn_opt_box[0]

    # ── Resumen de confianza ──────────────────────────────────────────────────
    if n_warn_req:
        st.warning(
            f"⚠️ **{n_warn_req} campo(s) requerido(s)** sin coincidencia exacta — "
            "ajustá los desplegables antes de procesar.",
            icon=None,
        )
    elif n_warn_opt:
        st.info(
            f"ℹ️ {n_warn_opt} campo(s) opcional(es) con coincidencia aproximada — "
            "podés ajustar o ignorar.",
            icon=None,
        )
    else:
        st.success("Todos los campos requeridos emparejados con alta confianza.", icon="✅")

    st.caption(
        "<span style='color:#f14c4c;font-weight:700'>*</span>"
        " campo requerido para la conciliación",
        unsafe_allow_html=True,
    )

    # ── Guardar perfil ────────────────────────────────────────────────────────
    if _guardar_ok:
        _nom = (_perfil_nom or _perfil_sel or "").strip()
        if _nom:
            guardar_mapeos({_nom: {"columnas_l": res_l, "columnas_a": res_a}})
            st.success(f"Perfil **{_nom}** guardado.", icon="💾")
        else:
            st.warning("Ingresá un nombre para guardar el perfil.")

    # ── Columnas no utilizadas ────────────────────────────────────────────────
    cols_l_usadas = set(v for v in res_l.values() if v)
    cols_a_usadas = set(v for v in res_a.values() if v)
    ignoradas_l   = [c for c in cols_l if c not in cols_l_usadas]
    ignoradas_a   = [c for c in cols_a if c not in cols_a_usadas]

    if ignoradas_l or ignoradas_a:
        with st.expander(
            f"Columnas sin usar — "
            f"Listado: {len(ignoradas_l)}  ·  ARCA: {len(ignoradas_a)}",
            expanded=False,
        ):
            ic1, ic2 = st.columns(2)
            with ic1:
                st.markdown("<span style='color:#9cdcfe;font-weight:600'>Listado</span>", unsafe_allow_html=True)
                for c in ignoradas_l:
                    st.markdown(f"<span style='color:#858585;font-size:.88rem'>· {c}</span>",
                                unsafe_allow_html=True)
                if not ignoradas_l:
                    st.caption("—")
            with ic2:
                st.markdown("<span style='color:#9cdcfe;font-weight:600'>ARCA</span>", unsafe_allow_html=True)
                for c in ignoradas_a:
                    st.markdown(f"<span style='color:#858585;font-size:.88rem'>· {c}</span>",
                                unsafe_allow_html=True)
                if not ignoradas_a:
                    st.caption("—")

    return res_l, res_a


# ── UI ────────────────────────────────────────────────────────────────────────

st.markdown("""
<div class="header-bar">
    <h1><span style="color:#007acc;font-size:1.4rem;margin-right:.45rem">⬡</span>Conciliación IVA Compras</h1>
    <p>Listado IVA Compras <span style="color:#858585">(Colppy)</span>
    &nbsp;<span style="color:#3e3e42">━━</span>&nbsp;
    Mis Comprobantes Recibidos <span style="color:#858585">(ARCA)</span></p>
</div>
""", unsafe_allow_html=True)

# Inicializar BD una sola vez por sesión (no en cada rerun)
if "db_initialized" not in st.session_state:
    init_db()
    st.session_state["db_initialized"] = True

# ── Lecturas DB — UNA sola vez por rerun, antes del sidebar ───────────────────
# Centralizar aquí evita llamadas duplicadas en sidebar + panel de resultados.
_reglas_cuit_global   = cargar_reglas()
_mapeos_global        = cargar_mapeos()
_prev_s1_g, _prev_s2_g, _prev_s3_g, _prev_meta_g = cargar_csv()
_historicos_global    = listar_historicos()

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚙️ Parámetros")
    tolerancia = st.number_input(
        "Tolerancia ($)", min_value=0.0, max_value=10.0,
        value=TOLERANCIA_DEFAULT, step=0.01, format="%.2f",
    )

    st.markdown("### 📁 Archivos")
    local_dir  = Path(__file__).parent
    local_xlsx = list(local_dir.glob("*.xls")) + list(local_dir.glob("*.xlsx")) + list(local_dir.glob("*.csv"))
    _auto_listado_path = next((str(f) for f in local_xlsx if "listado" in f.name.lower() and "iva" in f.name.lower()), None)
    _auto_arca_path    = next((str(f) for f in local_xlsx if "comprobantes" in f.name.lower() and "recibidos" in f.name.lower()), None)

    # Los uploaders van primero: el usuario sube su archivo aquí
    file_listado = st.file_uploader("Subir Listado IVA", type=["xls","xlsx","csv"])
    file_arca    = st.file_uploader("Subir Comprobantes ARCA", type=["xls","xlsx","csv"])

    # Archivos auto-detectados: se muestran SOLO cuando no hay un upload activo
    # (evita la confusión de ver dos fuentes simultáneas)
    auto_listado = None
    if _auto_listado_path and not file_listado and not st.session_state.get("dismiss_auto_listado"):
        _c1, _c2 = st.columns([5, 1])
        with _c1:
            st.success(f"Listado: `{Path(_auto_listado_path).name}`", icon="✅")
        with _c2:
            if st.button("✕", key="btn_dismiss_listado", help="Ignorar archivo local"):
                st.session_state["dismiss_auto_listado"] = True
                for _k in ["ml_file_id", "ml_sug", "ml_conf", "ml_cols"]:
                    st.session_state.pop(_k, None)
                st.rerun()
        auto_listado = _auto_listado_path

    auto_arca = None
    if _auto_arca_path and not file_arca and not st.session_state.get("dismiss_auto_arca"):
        _c1, _c2 = st.columns([5, 1])
        with _c1:
            st.success(f"ARCA: `{Path(_auto_arca_path).name}`", icon="✅")
        with _c2:
            if st.button("✕", key="btn_dismiss_arca", help="Ignorar archivo local"):
                st.session_state["dismiss_auto_arca"] = True
                for _k in ["ma_file_id", "ma_sug", "ma_conf", "ma_cols"]:
                    st.session_state.pop(_k, None)
                st.rerun()
        auto_arca = _auto_arca_path

    src_listado = file_listado or auto_listado
    src_arca    = file_arca    or auto_arca

    # ── Autodetección de columnas al cargar nuevo archivo ─────────────────────
    _fb_map = {"ml": _LISTADO_FALLBACKS, "ma": _ARCA_FALLBACKS}
    for _fsrc, _kp, _campos, _aliases, _hkw in [
        (src_listado, "ml", CAMPOS_LISTADO, ALIASES_LISTADO, "Comprobante"),
        (src_arca,    "ma", CAMPOS_ARCA,    ALIASES_ARCA,    "Punto de Venta"),
    ]:
        if _fsrc is not None:
            _fid = (
                f"{_fsrc.name}_{_fsrc.size}" if hasattr(_fsrc, "name")
                else str(_fsrc)
            )
            if st.session_state.get(f"{_kp}_file_id") != _fid:
                # Nuevo archivo → limpiar resultados y resetear el selectbox de histórico
                for _rk in ["loaded", "s1", "s2", "s3", "correcciones",
                             "periodo_actual", "sel_hist_key"]:
                    st.session_state.pop(_rk, None)
                _label = "Listado" if _kp == "ml" else "ARCA"
                with st.spinner(f"Leyendo {_label}..."):
                    _cols = _detectar_columnas(_fsrc, _hkw, _fb_map[_kp])
                    if hasattr(_fsrc, "seek"):
                        _fsrc.seek(0)
                    # Para el Listado, detectar formato (Listado vs Libro IVA)
                    if _kp == "ml":
                        _fmt_ml = _detectar_formato_colppy(_fsrc)
                        if hasattr(_fsrc, "seek"):
                            _fsrc.seek(0)
                        st.session_state["ml_formato"] = _fmt_ml
                    else:
                        _fmt_ml = None
                if _cols:
                    _sug, _conf = sugerir_mapeo(_cols, _campos, _aliases)
                    st.session_state[f"{_kp}_sug"]  = _sug
                    st.session_state[f"{_kp}_conf"] = _conf
                    st.session_state[f"{_kp}_cols"] = _cols
                    for _ck in list(_campos.keys()):
                        st.session_state.pop(f"{_kp}_{_ck}", None)
                    if _fmt_ml == "libro":
                        st.success(
                            f"📖 Libro IVA Compras detectado — {len(_cols)} columnas. "
                            "Las columnas se mapean **automáticamente**.", icon=None
                        )
                    else:
                        st.success(f"{_label} listo — {len(_cols)} columnas detectadas.", icon="✅")
                else:
                    st.session_state.pop(f"{_kp}_cols", None)
                    st.session_state.pop("ml_formato", None)
                    st.warning(
                        f"No se detectaron columnas en el {_label}. "
                        f"Verificá que el archivo sea el formato correcto."
                    )
                if hasattr(_fsrc, "seek"):
                    _fsrc.seek(0)
                st.session_state[f"{_kp}_file_id"] = _fid

    # ── Reglas de memoria por CUIT ────────────────────────────────────────────
    reglas_sidebar = _reglas_cuit_global
    if reglas_sidebar:
        with st.expander(f"📋 Reglas de memoria ({len(reglas_sidebar)})", expanded=False):
            st.caption("Se aplican automáticamente a futuros comprobantes del mismo CUIT.")
            for _cuit_k, _rule in list(reglas_sidebar.items()):
                _rs  = _rule.get("razon_social", _cuit_k)
                _est = _rule.get("estado_display", _rule.get("estado", ""))
                _mot = _rule.get("motivo", "")
                _cr1, _cr2 = st.columns([5, 1])
                with _cr1:
                    st.markdown(f"**{_rs}**")
                    st.caption(f"CUIT: {_cuit_k}  ·  {_est}  ·  {_mot}")
                with _cr2:
                    if st.button("✕", key=f"del_regla_{_cuit_k}",
                                 help="Eliminar esta regla"):
                        eliminar_regla(_cuit_k)
                        st.rerun()

    procesar = st.button("▶ Procesar", type="primary", use_container_width=True)

    # ── Histórico
    st.markdown("---")
    st.markdown("### 🕓 Histórico")
    prev_s1, prev_s2, prev_s3, prev_meta = _prev_s1_g, _prev_s2_g, _prev_s3_g, _prev_meta_g

    if prev_s1 is not None:
        fecha_str = str(prev_meta.get("fecha_proceso", ""))[:16].replace("T", " ")
        st.caption(f"Último proceso: {fecha_str}")
        st.caption(f"Tolerancia: ${float(prev_meta.get('tolerancia', 0)):.2f}")
        cargar_prev = st.button("Cargar último resultado", use_container_width=True)
    else:
        cargar_prev = False

    historicos = _historicos_global
    if historicos:
        st.markdown(f"**Snapshots guardados:** {len(historicos)}")
        sel_hist = st.selectbox(
            "Comparar snapshot:",
            options=[None] + historicos,
            format_func=lambda h: "— Ninguno —" if h is None else f"{h['label']} ({h['conc']}/{h['n']} conc.)",
            key="sel_hist_key",
        )
    else:
        sel_hist = None


# ── Lógica principal ──────────────────────────────────────────────────────────

# ── Panel central de revisión de mapeo de columnas ───────────────────────────

_cols_l = st.session_state.get("ml_cols", [])
_cols_a = st.session_state.get("ma_cols", [])
_tiene_archivos = bool(_cols_l or _cols_a)
_es_libro = st.session_state.get("ml_formato") == "libro"

if _tiene_archivos:
    _map_open = not st.session_state.get("loaded", False)
    with st.expander("🗂️ Emparejamiento de columnas", expanded=_map_open):
        if _cols_l and _cols_a:
            _res_l, _res_a = _render_mapeo_parejas(_cols_l, _cols_a, mapeos_db=_mapeos_global)
            st.session_state["mapeo_listado"] = {"header_keyword": "Comprobante",    "columnas": _res_l}
            st.session_state["mapeo_arca"]    = {"header_keyword": "Punto de Venta", "columnas": _res_a}
        elif _cols_l:
            st.info("Cargá también el archivo de ARCA para ver el emparejamiento.")
        elif _cols_a:
            st.info("Cargá también el archivo del Listado (Colppy) para ver el emparejamiento.")
        else:
            st.info("Cargá ambos archivos para ver el emparejamiento de columnas.")

# ─────────────────────────────────────────────────────────────────────────────

if procesar:
    if not src_listado or not src_arca:
        st.error("Se necesitan ambos archivos.")
        st.stop()

    df_listado = df_arca = s1 = s2 = s3 = None
    hubo_cambio = False
    with st.status("Procesando conciliación...", expanded=True) as _proc_status:
        try:
            mapeo_l = st.session_state.get("mapeo_listado", copy.deepcopy(MAPEOS_DEFAULT["listado"]["Colppy"]))
            mapeo_a = st.session_state.get("mapeo_arca",    copy.deepcopy(MAPEOS_DEFAULT["arca"]["ARCA"]))

            _proc_status.update(label="Leyendo Listado IVA Compras...")
            df_listado = load_listado_iva(src_listado, mapeo_l)

            if df_listado is not None:
                _proc_status.update(label="Leyendo Mis Comprobantes ARCA...")
                df_arca = load_arca(src_arca, mapeo_a)

            if df_listado is not None and df_arca is not None:
                _proc_status.update(label="Cruzando comprobantes...")
                s1, s2, s3 = conciliar(df_listado, df_arca, tolerancia)
                _proc_status.update(label="Guardando resultado...")
                hubo_cambio = guardar_csv(s1, s2, s3, tolerancia)
                _proc_status.update(label="Conciliación completada", state="complete", expanded=False)
            else:
                _proc_status.update(label="No se pudo procesar — revisá los errores", state="error")
        except Exception as e:
            import traceback as _tb
            print(f"[ERROR procesamiento] {_tb.format_exc()}", file=sys.stderr)
            _proc_status.update(label="Error inesperado", state="error")
            st.error(
                f"Error al procesar los archivos: **{type(e).__name__}** — {e}\n\n"
                "Verificá que los archivos sean los formatos correctos y que el "
                "emparejamiento de columnas sea el adecuado."
            )

    if df_listado is None or df_arca is None or s1 is None:
        st.stop()

    periodo_det = _detectar_periodo(s1)
    st.session_state.update({
        "s1": s1, "s2": s2, "s3": s3,
        "tol": tolerancia, "loaded": True,
        "periodo_actual":  periodo_det,
        "correcciones":    {},
        "_hist_loaded_ts": None,
        "_excel_hash":     None,
    })
    if hubo_cambio:
        st.success("Snapshot histórico guardado.")
    else:
        st.info("Sin cambios respecto al resultado anterior (no se guardó snapshot).")

elif cargar_prev and prev_s1 is not None:
    tol_prev = float(prev_meta.get("tolerancia", TOLERANCIA_DEFAULT))
    st.session_state.update({
        "s1": prev_s1, "s2": prev_s2, "s3": prev_s3,
        "tol": tol_prev, "loaded": True,
        "correcciones":    {},
        "periodo_actual":  str(prev_meta.get("periodo", "")),
        "_hist_loaded_ts": None,
        "_excel_hash":     None,
    })

elif sel_hist is not None and sel_hist["ts"] != st.session_state.get("_hist_loaded_ts"):
    # Cargar siempre que cambie la selección, independientemente de si ya hay un resultado.
    try:
        s1h, s2h, s3h = cargar_historico(sel_hist["ts"])
        if s1h is None:
            raise ValueError("Snapshot no encontrado en la base de datos.")
        st.session_state.update({
            "s1": s1h, "s2": s2h, "s3": s3h,
            "tol": sel_hist["tol"], "loaded": True,
            "correcciones":    {},
            "periodo_actual":  sel_hist.get("periodo", ""),
            "_hist_loaded_ts": sel_hist["ts"],
            # Invalidar caché de Excel al cargar snapshot distinto
            "_excel_hash": None,
        })
    except Exception as e:
        st.error(f"No se pudo cargar el snapshot: {e}")


# ── Panel de resultados ───────────────────────────────────────────────────────

if st.session_state.get("loaded"):
    s1  = st.session_state["s1"]
    s2  = st.session_state["s2"]
    s3  = st.session_state["s3"]
    tol = st.session_state["tol"]

    # Usar reglas ya cargadas al inicio del rerun
    _reglas_cuit = _reglas_cuit_global
    _reglas_norm = {
        re.sub(r"[^0-9]", "", k): v
        for k, v in _reglas_cuit.items()
        if v.get("activo", True)
    }

    # ── Construir s1_export con correcciones y reglas (fuente única de verdad) ──
    correcciones_xl = st.session_state.get("correcciones", {})
    s1_export = s1.copy()
    # 1. Reglas de memoria (menor precedencia)
    if _reglas_norm and "CUIT_norm" in s1_export.columns:
        for _xi in s1_export[
            s1_export["CUIT_norm"].astype(str).isin(_reglas_norm)
            & ~s1_export["Comprobante"].isin(correcciones_xl)
        ].index:
            _xrule = _reglas_norm[str(s1_export.at[_xi, "CUIT_norm"])]
            s1_export.at[_xi, "Estado"] = _xrule.get("estado", s1_export.at[_xi, "Estado"])
    # 2. Correcciones manuales de sesión (mayor precedencia)
    if correcciones_xl:
        for comp_c, corr_c in correcciones_xl.items():
            mask_c = s1_export["Comprobante"] == comp_c
            s1_export.loc[mask_c, "Estado"] = ICON_ESTADO.get(
                corr_c["estado_usuario"], corr_c["estado_usuario"]
            )
    # 3. Sincronizar Conciliado con el Estado final
    #    "Conciliado" algorítmico o corrección manual que lo eleve a ese estado
    if "Conciliado" in s1_export.columns:
        s1_export["Conciliado"] = s1_export["Estado"] == "Conciliado"

    # KPIs — calculados desde s1_export para reflejar correcciones y reglas
    n_l    = len(s1_export)
    n_a    = len(s3) + int(s1_export["Existe_en_ARCA"].sum())
    n_conc = int(s1_export["Conciliado"].sum())
    n_sdes = int((s1_export["Estado"] == "Total OK / Sin desglose").sum())
    n_dif  = int((s1_export["Estado"] == "Diferencia detectada").sum())
    n_sl   = int((~s1_export["Existe_en_ARCA"]).sum())
    n_sa   = len(s3)
    n_nc   = int(s1_export.get("ARCA_es_NC", pd.Series(dtype=bool)).sum())
    n_ext  = int((s1_export["Estado"] == "Exterior / No en ARCA").sum())
    n_rev  = int((s1_export["Estado"] == "Revisado / Aceptado").sum())

    st.markdown(f"""
    <div class="kpi-row">
      <div class="kpi bl"><div class="n">{n_l}</div><div class="l">Listado</div></div>
      <div class="kpi bl"><div class="n">{n_a}</div><div class="l">ARCA</div></div>
      <div class="kpi ok"><div class="n">{n_conc}</div><div class="l">Conciliados</div></div>
      <div class="kpi gr"><div class="n">{n_sdes}</div><div class="l">Total OK s/desg.</div></div>
      <div class="kpi or"><div class="n">{n_dif}</div><div class="l">Con diferencias</div></div>
      <div class="kpi re"><div class="n">{n_sl}</div><div class="l">Solo Listado</div></div>
      <div class="kpi re"><div class="n">{n_sa}</div><div class="l">Solo ARCA</div></div>
      <div class="kpi pu"><div class="n">{n_nc}</div><div class="l">NC ARCA</div></div>
      <div class="kpi or"><div class="n">{n_ext}</div><div class="l">Ext. s/ARCA</div></div>
      <div class="kpi bl"><div class="n">{n_rev}</div><div class="l">Revisados</div></div>
    </div>
    """, unsafe_allow_html=True)

    n_corr   = len(correcciones_xl)
    n_reglas = int(
        s1_export[
            s1_export["CUIT_norm"].astype(str).isin(_reglas_norm)
            & ~s1_export["Comprobante"].isin(correcciones_xl)
        ].shape[0]
    ) if _reglas_norm and "CUIT_norm" in s1_export.columns else 0
    _lbl_extras = ", ".join(filter(None, [
        f"{n_corr} corregido(s)" if n_corr else "",
        f"{n_reglas} con regla 📋" if n_reglas else "",
    ]))
    lbl_xl = f"⬇ Excel completo (3 hojas)" + (f"  ·  {_lbl_extras}" if _lbl_extras else "")

    # Generar Excel una sola vez por contenido (cacheado en session_state).
    # download_button evalúa `data=` en cada rerun aunque no se haya clickeado.
    _excel_hash = _hash_s1(s1_export)
    if st.session_state.get("_excel_hash") != _excel_hash:
        st.session_state["_excel_bytes"] = generar_excel(s1_export, s2, s3)
        st.session_state["_excel_hash"]  = _excel_hash
    _excel_bytes = st.session_state["_excel_bytes"]

    col_xl, col_inf = st.columns([2, 5])
    with col_xl:
        st.download_button(
            lbl_xl,
            data=_excel_bytes,
            file_name=f"ConciliacionIVA_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            type="primary", use_container_width=True,
        )
    with col_inf:
        st.caption(f"Tolerancia: ±${tol:.2f}  |  {n_conc} conciliados / {n_l} totales  |  {n_nc} NC en ARCA  |  {n_ext} exterior sin ARCA")

    st.markdown("---")

    # ── Tabs ─────────────────────────────────────────────────────────────────
    tab1, tab2, tab3 = st.tabs([
        f"Conciliación ({n_l})",
        f"Solo en Listado ({n_sl})",
        f"Solo en ARCA ({n_sa})",
    ])

    # ── Tab 1: Conciliación ───────────────────────────────────────────────────
    with tab1:
        all_estados = list(ESTADO_ICON.values())
        all_origenes = ["Nacional", "Exterior"] if "Origen" in s1.columns else []

        fc1, fc2, fc3, fc4 = st.columns([3, 2, 2, 2])
        with fc1:
            sel_estados = st.multiselect(
                "Estado:", all_estados, default=all_estados, key="sel_estados",
            )
        with fc2:
            if all_origenes:
                sel_orig = st.multiselect("Origen:", all_origenes, default=all_origenes, key="sel_orig")
            else:
                sel_orig = []
        with fc3:
            solo_nc = st.checkbox("Solo NC (ARCA)", key="solo_nc")
        with fc4:
            solo_memoria = st.checkbox("Solo memoria 📋", key="solo_memoria",
                                       help="Muestra solo filas donde se aplicó una regla guardada")

        correcciones = st.session_state.get("correcciones", {})

        d1 = s1.copy()
        d1["Estado"] = d1["Estado"].map(ESTADO_ICON).fillna(d1["Estado"])

        # Aplicar correcciones manuales de sesión (mayor precedencia)
        if correcciones:
            d1["Estado"] = d1.apply(
                lambda r: correcciones[r["Comprobante"]]["estado_usuario"]
                          if r["Comprobante"] in correcciones else r["Estado"],
                axis=1,
            )

        # Aplicar reglas de memoria por CUIT (solo donde no hay corrección manual)
        d1["Memoria"] = False
        if _reglas_norm and "CUIT_norm" in d1.columns:
            for _idx in d1[
                d1["CUIT_norm"].astype(str).isin(_reglas_norm)
                & ~d1["Comprobante"].isin(correcciones)
            ].index:
                _rule = _reglas_norm[str(d1.at[_idx, "CUIT_norm"])]
                d1.at[_idx, "Estado"]  = _rule.get("estado_display",
                                            ESTADO_ICON.get(_rule.get("estado", ""), ""))
                d1.at[_idx, "Memoria"] = True

        if sel_estados:
            d1 = d1[d1["Estado"].isin(sel_estados)]
        if sel_orig and "Origen" in d1.columns:
            d1 = d1[d1["Origen"].isin(sel_orig)]
        if solo_nc and "ARCA_es_NC" in d1.columns:
            d1 = d1[d1["ARCA_es_NC"] == True]
        if solo_memoria:
            d1 = d1[d1["Memoria"] == True]

        d1_disp = _fmt_bool(d1, ["Existe_en_ARCA","Match_Neto","Match_IVA","Match_Total","Conciliado","ARCA_es_NC"])
        if "Memoria" in d1_disp.columns:
            d1_disp["Memoria"] = d1_disp["Memoria"].map({True: "📋", False: ""})

        COL_CFG = {
            "Estado":      st.column_config.TextColumn("Estado", width="medium"),
            "Memoria":     st.column_config.TextColumn("📋", width="small"),
            "Tipo_Doc":    st.column_config.TextColumn("Tipo"),
            "Origen":      st.column_config.TextColumn("Origen", width="small"),
            "ARCA_Tipo":   st.column_config.TextColumn("Tipo ARCA"),
            "ARCA_es_NC":  st.column_config.TextColumn("NC", width="small"),
            "Neto":        st.column_config.NumberColumn("Neto Listado",  format="$ %.2f"),
            "IVA":         st.column_config.NumberColumn("IVA Listado",   format="$ %.2f"),
            "Total":       st.column_config.NumberColumn("Total Listado", format="$ %.2f"),
            "ARCA_Neto":          st.column_config.NumberColumn("Neto ARCA",       format="$ %.2f"),
            "ARCA_IVA":           st.column_config.NumberColumn("IVA ARCA",        format="$ %.2f"),
            "ARCA_OtrosTrib":     st.column_config.NumberColumn("Otros Trib ARCA", format="$ %.2f"),
            "ARCA_Total":         st.column_config.NumberColumn("Total ARCA",      format="$ %.2f"),
            "ARCA_Neto_Derivado": st.column_config.TextColumn("Neto Der.", width="small"),
            "Dif_Neto":    st.column_config.NumberColumn("Δ Neto",  format="$ %.2f"),
            "Dif_IVA":     st.column_config.NumberColumn("Δ IVA",   format="$ %.2f"),
            "Dif_Total":   st.column_config.NumberColumn("Δ Total", format="$ %.2f"),
            "Existe_en_ARCA": st.column_config.TextColumn("En ARCA", width="small"),
            "Conciliado":  st.column_config.TextColumn("OK",  width="small"),
            "Match_Neto":  st.column_config.TextColumn("M.N", width="small"),
            "Match_IVA":   st.column_config.TextColumn("M.I", width="small"),
            "Match_Total": st.column_config.TextColumn("M.T", width="small"),
        }

        evento = st.dataframe(
            d1_disp, use_container_width=True, height=400, hide_index=True,
            on_select="rerun", selection_mode="single-row",
            column_config=COL_CFG,
        )

        tc1, tc2 = st.columns([2, 6])
        with tc1:
            _csv_download(
                d1_disp, f"⬇ CSV filtrado ({len(d1_disp)} filas)",
                f"conciliacion_filtrada_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            )
        with tc2:
            st.caption(
                f"{len(d1_disp)} filas  |  "
                f"Filtros: estado={len(sel_estados)}/{len(all_estados)}"
                + (f", origen={len(sel_orig)}/{len(all_origenes)}" if all_origenes else "")
                + (", solo NC" if solo_nc else "")
                + (", solo memoria 📋" if solo_memoria else "")
                + "  — Hacé clic en una fila para corregirla"
            )

        # ── Panel de corrección (aparece al seleccionar una fila) ─────────────
        filas_sel = evento.selection.rows if evento.selection else []
        if filas_sel:
            pos   = filas_sel[0]
            idx   = d1_disp.index[pos]
            fila_disp = d1_disp.iloc[pos]
            fila_orig = s1.loc[idx]   # valores originales con numéricos

            comp       = fila_orig.get("Comprobante", "")
            razon      = fila_orig.get("Razon_Social", "")
            est_algo   = ESTADO_ICON.get(fila_orig.get("Estado", ""), fila_orig.get("Estado", ""))
            est_tabla  = d1_disp.iloc[pos].get("Estado", est_algo)   # puede diferir si hay memoria/corrección
            periodo_actual = st.session_state.get("periodo_actual", "")

            st.markdown("---")
            st.markdown(f"#### ✏️ Corrección — `{comp}` &nbsp; {razon}")

            pc1, pc2 = st.columns(2)
            with pc1:
                if est_tabla != est_algo:
                    st.markdown(f"**Estado algoritmo:** {est_algo}  ·  **En tabla:** {est_tabla}")
                else:
                    st.markdown(f"**Estado actual:** {est_algo}")

                # Datos de identificación completos
                meta_items = [
                    ("Fecha",         "Fecha_Factura"),
                    ("Tipo",          "Tipo_Doc"),
                    ("Origen",        "Origen"),
                    ("Condición IVA", "Condicion_IVA"),
                    ("CUIT/DNI",      "CUIT_DNI"),
                    ("ARCA Emisor",   "ARCA_Denominacion"),
                    ("Tipo ARCA",     "ARCA_Tipo"),
                    ("Fecha ARCA",    "ARCA_Fecha"),
                    ("NC ARCA",       "ARCA_es_NC"),
                    ("Neto derivado", "ARCA_Neto_Derivado"),
                ]
                meta_data = [
                    {"Campo": lbl, "Valor": str(fila_orig.get(col, ""))}
                    for lbl, col in meta_items
                    if col in fila_orig.index
                    and str(fila_orig.get(col, "")) not in ("", "nan", "None", "False")
                ]
                if meta_data:
                    st.dataframe(
                        pd.DataFrame(meta_data),
                        hide_index=True, use_container_width=True,
                    )

                # Tabla comparativa Listado vs ARCA
                cmp_rows = [
                    {
                        "Campo":   lbl,
                        "Listado": fila_orig.get(campo),
                        "ARCA":    fila_orig.get(f"ARCA_{campo}"),
                        "Δ":       fila_orig.get(f"Dif_{campo}"),
                    }
                    for campo, lbl in [("Neto", "Neto"), ("IVA", "IVA"),
                                       ("Total", "Total")]
                    if campo in fila_orig.index
                ]
                if cmp_rows:
                    st.dataframe(
                        pd.DataFrame(cmp_rows),
                        hide_index=True, use_container_width=True,
                        column_config={
                            "Listado": st.column_config.NumberColumn("Listado", format="$ %.2f"),
                            "ARCA":    st.column_config.NumberColumn("ARCA",    format="$ %.2f"),
                            "Δ":       st.column_config.NumberColumn("Δ",       format="$ %.2f"),
                        },
                    )

            with pc2:
                # Claves de widgets basadas en el nro de comprobante (único y estable)
                # para evitar colisiones al cambiar filtros que alteran el índice pandas.
                _wkey = comp

                estados_opciones = list(ESTADO_ICON.values())
                _idx_estado = estados_opciones.index(est_algo) if est_algo in estados_opciones else 0
                nuevo_estado = st.selectbox(
                    "Corregir estado a:",
                    estados_opciones,
                    index=_idx_estado,
                    key=f"corr_estado_{_wkey}",
                )
                motivo_sel = st.selectbox(
                    "Motivo:", MOTIVOS_CORRECCION, key=f"corr_motivo_{_wkey}",
                )
                if motivo_sel == "Otro (ver nota)":
                    motivo_custom = st.text_input(
                        "Describí el motivo:",
                        key=f"corr_motivo_custom_{_wkey}",
                        placeholder="Ej: retención IIBB no contemplada en el sistema",
                    )
                    motivo = f"Otro: {motivo_custom}" if motivo_custom.strip() else "Otro (ver nota)"
                else:
                    motivo = motivo_sel
                nota = st.text_area(
                    "Nota adicional (opcional):", height=68, key=f"corr_nota_{_wkey}",
                    placeholder="Ej: diferencia de $0.12 por redondeo en alícuota 10.5%",
                )

                cuit_corr      = str(fila_orig.get("CUIT_norm", ""))
                ya_tiene_regla = cuit_corr in _reglas_cuit

                # Forzar valor fresco del checkbox si fue limpiado por un save anterior
                _key_regla = f"corr_regla_{_wkey}"
                if _key_regla not in st.session_state:
                    st.session_state[_key_regla] = ya_tiene_regla

                guardar_como_regla = st.checkbox(
                    "📋 Guardar como regla para este proveedor"
                    + (" *(ya existe — se actualizará)*" if ya_tiene_regla else ""),
                    key=_key_regla,
                    help="Futuros comprobantes de este CUIT se corregirán automáticamente "
                         "con este estado y motivo en próximas conciliaciones.",
                )

                btn_cols = st.columns(2)
                with btn_cols[0]:
                    if st.button("💾 Guardar corrección", type="primary", use_container_width=True,
                                 key=f"corr_save_{_wkey}"):
                        ok_fb = guardar_feedback(fila_orig, nuevo_estado, motivo, nota, periodo_actual)
                        if not ok_fb:
                            st.error("No se pudo guardar el feedback en la base de datos.")
                        if "correcciones" not in st.session_state:
                            st.session_state["correcciones"] = {}
                        st.session_state["correcciones"][comp] = {
                            "estado_usuario": nuevo_estado,
                            "motivo":         motivo,
                            "nota":           nota,
                        }
                        if guardar_como_regla and cuit_corr:
                            ok_r = guardar_regla(cuit_corr, nuevo_estado, motivo,
                                                 str(fila_orig.get("Razon_Social", "")))
                            if not ok_r:
                                st.error("No se pudo guardar la regla en la base de datos.")
                        # Limpiar widgets del panel para que la próxima selección arranque limpia
                        for _wk in [f"corr_estado_{_wkey}", f"corr_motivo_{_wkey}",
                                    f"corr_motivo_custom_{_wkey}", f"corr_nota_{_wkey}",
                                    _key_regla]:
                            st.session_state.pop(_wk, None)
                        st.rerun()
                with btn_cols[1]:
                    if st.button("✕ Cancelar", use_container_width=True, key=f"corr_cancel_{_wkey}"):
                        for _wk in [f"corr_estado_{_wkey}", f"corr_motivo_{_wkey}",
                                    f"corr_motivo_custom_{_wkey}", f"corr_nota_{_wkey}",
                                    _key_regla]:
                            st.session_state.pop(_wk, None)
                        st.rerun()

    # ── Tab 2: Solo en Listado ────────────────────────────────────────────────
    with tab2:
        all_orig2 = ["Nacional", "Exterior"] if "Origen" in s2.columns else []
        all_tipos2 = sorted(s2["Tipo_Doc"].dropna().unique().tolist()) if "Tipo_Doc" in s2.columns else []

        f2c1, f2c2 = st.columns(2)
        with f2c1:
            sel_orig2 = st.multiselect("Origen:", all_orig2, default=all_orig2, key="sel_orig2") if all_orig2 else []
        with f2c2:
            sel_tipo2 = st.multiselect("Tipo:", all_tipos2, default=all_tipos2, key="sel_tipo2") if all_tipos2 else []

        d2 = s2.copy()
        if sel_orig2 and "Origen" in d2.columns:
            d2 = d2[d2["Origen"].isin(sel_orig2)]
        if sel_tipo2 and "Tipo_Doc" in d2.columns:
            d2 = d2[d2["Tipo_Doc"].isin(sel_tipo2)]

        if "Origen" in d2.columns:
            resumen = d2["Origen"].value_counts()
            cols_res = st.columns(len(resumen))
            for i, (orig, cnt) in enumerate(resumen.items()):
                cls = "or" if orig == "Exterior" else "bl"
                cols_res[i].markdown(f"""
                <div class="kpi {cls}" style="margin:0">
                  <div class="n">{cnt}</div><div class="l">{orig}</div>
                </div>""", unsafe_allow_html=True)

        st.dataframe(
            d2, use_container_width=True, height=400, hide_index=True,
            column_config={
                "Tipo_Doc":    st.column_config.TextColumn("Tipo"),
                "Origen":      st.column_config.TextColumn("Origen", width="small"),
                "Neto":        st.column_config.NumberColumn("Neto",  format="$ %.2f"),
                "IVA":         st.column_config.NumberColumn("IVA",   format="$ %.2f"),
                "Total":       st.column_config.NumberColumn("Total", format="$ %.2f"),
            },
        )

        cc1, _ = st.columns([2, 5])
        with cc1:
            _csv_download(
                d2, f"⬇ CSV filtrado ({len(d2)} filas)",
                f"solo_listado_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            )

    # ── Tab 3: Solo en ARCA ───────────────────────────────────────────────────
    with tab3:
        all_tipos3 = sorted(s3["Tipo_Doc_ARCA"].dropna().unique().tolist()) if "Tipo_Doc_ARCA" in s3.columns else []
        col_nc3, col_t3 = st.columns(2)
        with col_nc3:
            solo_nc3 = st.checkbox("Solo NC", key="solo_nc3")
        with col_t3:
            sel_tipo3 = st.multiselect("Tipo:", all_tipos3, default=all_tipos3, key="sel_tipo3") if all_tipos3 else []

        d3 = s3.copy()
        if solo_nc3 and "es_NC" in d3.columns:
            d3 = d3[d3["es_NC"] == True]
        if sel_tipo3 and "Tipo_Doc_ARCA" in d3.columns:
            d3 = d3[d3["Tipo_Doc_ARCA"].isin(sel_tipo3)]

        d3_disp = _fmt_bool(d3, ["es_NC"])
        st.dataframe(
            d3_disp, use_container_width=True, height=400, hide_index=True,
            column_config={
                "es_NC":              st.column_config.TextColumn("NC", width="small"),
                "Neto Gravado Total": st.column_config.NumberColumn("Neto Gravado", format="$ %.2f"),
                "Total IVA":          st.column_config.NumberColumn("IVA",          format="$ %.2f"),
                "Imp. Total":         st.column_config.NumberColumn("Total",        format="$ %.2f"),
            },
        )

        cc1, _ = st.columns([2, 5])
        with cc1:
            _csv_download(
                d3_disp, f"⬇ CSV filtrado ({len(d3)} filas)",
                f"solo_arca_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            )

else:
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("**Pasos:**")
        st.markdown("""
1. Subí el **Listado IVA Compras** de Colppy (`.xls` / `.xlsx`)
2. Subí **Mis Comprobantes Recibidos** de ARCA (`.xlsx`)
3. Ajustá la tolerancia (por defecto ±$0.07)
4. **▶ Procesar**
        """)
    with c2:
        st.markdown("**Funcionalidades:**")
        st.markdown("""
- Notas de Crédito en ARCA → montos en **negativo**
- Facturas del exterior (**FCC-A/B/C**) discriminadas por Origen
- Filtros **combinables** por Estado, Origen y Tipo
- **Descarga CSV** de la vista filtrada en cada pestaña
- **Persistencia histórica**: snapshot guardado solo si hay cambios
        """)
    if prev_s1 is not None:
        st.info("Hay un resultado previo disponible. Usá **Cargar último resultado** en el sidebar.")
    if historicos:
        st.info(f"Hay {len(historicos)} snapshot(s) histórico(s) disponibles para comparar.")
