#!/usr/bin/env python3
"""
Aplicación Web de Conciliación Bancaria
Interfaz Streamlit para conciliación entre extracto bancario y libro mayor
"""

import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime, timedelta
import io
import zipfile

# Importar funciones del script de conciliación
from conciliacion_contable import (
    parse_currency,
    clasificar_categoria,
    conciliar_1a1,
    conciliar_1a1_ampliado,
    conciliar_resumen_categorias,
    chequear_imputacion,
    control_global_totales
)


# ============================================================================
# CONFIGURACIÓN DE LA PÁGINA
# ============================================================================

st.set_page_config(
    page_title="Conciliación Bancaria",
    page_icon="💰",
    layout="centered",
    initial_sidebar_state="collapsed"
)

# CSS personalizado - Diseño elegante y compacto
st.markdown("""
<style>
    /* Reducir padding general y arreglar márgenes */
    .main .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        padding-left: 1rem;
        padding-right: 1rem;
        max-width: 1200px;
    }
    
    /* Arreglar margen derecho en columnas */
    .stColumn {
        padding-left: 0.5rem;
        padding-right: 0.5rem;
    }
    
    /* Botones de descarga sin overflow */
    .stDownloadButton {
        padding: 0;
        margin: 0.25rem 0;
    }
    
    /* Modal centrado para alertas */
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }
    
    .modal-content {
        background: white;
        padding: 2rem;
        border-radius: 12px;
        max-width: 600px;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
        animation: fadeIn 0.3s ease-in;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .modal-header {
        font-size: 1.5rem;
        color: #e74c3c;
        font-weight: 600;
        margin-bottom: 1rem;
        text-align: center;
    }
    
    .modal-body {
        color: #2c3e50;
        line-height: 1.6;
        margin-bottom: 1.5rem;
    }
    
    .modal-buttons {
        display: flex;
        gap: 1rem;
        justify-content: center;
    }
    
    /* Header principal más compacto */
    .main-header {
        font-size: 2rem;
        color: #2c3e50;
        font-weight: 600;
        text-align: center;
        margin-bottom: 1rem;
        padding: 0.5rem;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
    }
    
    /* Métricas más compactas */
    [data-testid="stMetricValue"] {
        font-size: 1.2rem;
    }
    
    [data-testid="stMetricLabel"] {
        font-size: 0.85rem;
    }
    
    /* Botones más elegantes */
    .stButton button {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border: none;
        border-radius: 8px;
        padding: 0.5rem 2rem;
        font-weight: 500;
        transition: transform 0.2s;
    }
    
    .stButton button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    }
    
    /* Tabs más elegantes */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 45px;
        padding: 0 20px;
        background-color: #f8f9fa;
        border-radius: 8px 8px 0 0;
        font-size: 0.9rem;
        color: #2c3e50;
    }
    
    .stTabs [aria-selected="true"] {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white !important;
    }
    
    .stTabs [aria-selected="true"] p {
        color: white !important;
    }
    
    /* File uploader más compacto */
    [data-testid="stFileUploader"] {
        padding: 0.5rem;
    }
    
    /* DataFrames más compactos */
    .dataframe {
        font-size: 0.85rem;
    }
    
    /* Expander más elegante */
    .streamlit-expanderHeader {
        font-size: 0.9rem;
        font-weight: 500;
    }
    
    /* Reducir espaciado entre elementos */
    .element-container {
        margin-bottom: 0.5rem;
    }
    
    /* Info/success boxes más elegantes */
    .stAlert {
        padding: 0.75rem;
        border-radius: 8px;
        font-size: 0.9rem;
    }
    
    /* Subheaders más compactos */
    h2, h3 {
        font-size: 1.3rem !important;
        margin-top: 0.5rem !important;
        margin-bottom: 0.5rem !important;
        color: #2c3e50;
    }
    
    /* Cajas personalizadas */
    .metric-box {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        text-align: center;
    }
    
    .success-box {
        background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
        border-left: 4px solid #28a745;
        padding: 0.75rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        font-size: 0.9rem;
    }
    
    .warning-box {
        background: linear-gradient(135deg, #fff3cd 0%, #ffeaa7 100%);
        border-left: 4px solid #ffc107;
        padding: 0.75rem;
        border-radius: 8px;
        margin: 0.5rem 0;
        font-size: 0.9rem;
    }
    
    /* Download button elegante */
    .stDownloadButton button {
        background: linear-gradient(135deg, #56ab2f 0%, #a8e063 100%);
        color: white;
        border-radius: 8px;
        padding: 0.5rem 1.5rem;
        font-size: 0.9rem;
    }
</style>
""", unsafe_allow_html=True)


# ============================================================================
# FUNCIONES AUXILIARES
# ============================================================================

def cargar_csv(uploaded_file, nombre_esperado):
    """Carga y normaliza un CSV subido"""
    try:
        df = pd.read_csv(uploaded_file, sep=';', encoding='latin-1')
        return df, None
    except UnicodeDecodeError:
        try:
            uploaded_file.seek(0)
            df = pd.read_csv(uploaded_file, sep=';', encoding='utf-8')
            return df, None
        except Exception as e:
            return None, f"Error al leer {nombre_esperado}: {str(e)}"
    except Exception as e:
        return None, f"Error al procesar {nombre_esperado}: {str(e)}"


def normalizar_extracto(df):
    """Normaliza el extracto bancario"""
    df['Fecha Valor'] = pd.to_datetime(df['Fecha Valor'], dayfirst=True, errors='coerce')
    df['Monto'] = df['Importe'].apply(parse_currency).round(2)
    df['Categoria_normalizada'] = df['Descripción'].apply(clasificar_categoria)
    df = df.dropna(subset=['Fecha Valor']).reset_index(drop=True)
    return df


def normalizar_mayor(df):
    """Normaliza el libro mayor"""
    df['Fecha'] = pd.to_datetime(df['Fecha'], dayfirst=True, errors='coerce')
    df['Débito'] = df['Débito'].apply(parse_currency).round(2)
    df['Crédito'] = df['Crédito'].apply(parse_currency).round(2)
    df['Monto'] = (df['Débito'] - df['Crédito']).round(2)
    df['Categoria_normalizada'] = df['Descripción'].apply(clasificar_categoria)
    df = df[df['Tipo'] != 'ADC'].reset_index(drop=True)
    df = df.dropna(subset=['Fecha']).reset_index(drop=True)
    return df


def validar_periodo(banco, mayor):
    """Valida que ambos archivos correspondan al mismo período con lógica difusa.
    
    Retorna:
        - (True, mensaje) si los períodos son compatibles
        - (False, mensaje) si hay un desfase significativo
    """
    # Obtener fechas
    fechas_banco = banco['Fecha Valor'].dropna()
    fechas_mayor = mayor['Fecha'].dropna()
    
    if fechas_banco.empty or fechas_mayor.empty:
        return (True, "No se pudo validar el período (fechas faltantes)")
    
    # Obtener mes/año más frecuente en cada archivo
    banco_periodos = fechas_banco.dt.to_period('M').value_counts()
    mayor_periodos = fechas_mayor.dt.to_period('M').value_counts()
    
    # Mes principal de cada archivo
    banco_principal = banco_periodos.index[0]
    mayor_principal = mayor_periodos.index[0]
    
    # Porcentaje de registros en el mes principal
    banco_pct = (banco_periodos.iloc[0] / len(fechas_banco)) * 100
    mayor_pct = (mayor_periodos.iloc[0] / len(fechas_mayor)) * 100
    
    # Calcular diferencia en meses
    diff_meses = abs((banco_principal.to_timestamp() - mayor_principal.to_timestamp()).days / 30)
    
    # Lógica difusa de validación
    if banco_principal == mayor_principal:
        # Mismo mes/año
        return (True, f"✅ Ambos archivos corresponden al período: {banco_principal.strftime('%B %Y')}")
    
    elif diff_meses <= 1:
        # Meses contiguos (aceptable si hay solapamiento)
        if banco_pct >= 60 and mayor_pct >= 60:
            return (True, f"⚠️ Períodos contiguos: Banco ({banco_principal.strftime('%b %Y')}) y Mayor ({mayor_principal.strftime('%b %Y')})")
        else:
            return (False, f"⚠️ Posible desfase: Banco mayormente en {banco_principal.strftime('%b %Y')} ({banco_pct:.0f}%), Mayor en {mayor_principal.strftime('%b %Y')} ({mayor_pct:.0f}%)")
    
    else:
        # Desfase significativo
        return (False, f"❌ ALERTA: Desfase significativo detectado.\n"
                       f"   • Banco: {banco_principal.strftime('%B %Y')} ({banco_pct:.0f}% de registros)\n"
                       f"   • Mayor: {mayor_principal.strftime('%B %Y')} ({mayor_pct:.0f}% de registros)\n"
                       f"   • Diferencia: ~{diff_meses:.0f} meses")
    
    # Información adicional sobre el rango
    banco_rango = f"{fechas_banco.min().strftime('%d/%m/%Y')} - {fechas_banco.max().strftime('%d/%m/%Y')}"
    mayor_rango = f"{fechas_mayor.min().strftime('%d/%m/%Y')} - {fechas_mayor.max().strftime('%d/%m/%Y')}"
    
    return (True, f"Períodos: Banco ({banco_rango}) | Mayor ({mayor_rango})")


def normalizar_discrepancias(df):
    """Normaliza el archivo de discrepancias reales"""
    df['Fecha Valor'] = pd.to_datetime(df['Fecha Valor'], dayfirst=True, errors='coerce')
    df['Monto'] = df['Importe'].apply(parse_currency).round(2)
    return df


def mapear_discrepancias(banco, discrep):
    """Mapea discrepancias reales a índices del banco"""
    discrep_indices = set()
    for _, d_row in discrep.iterrows():
        match = banco[
            (banco['Fecha Valor'] == d_row['Fecha Valor']) &
            (abs(banco['Monto'] - d_row['Monto']) < 0.01)
        ]
        if not match.empty:
            discrep_indices.update(match.index.tolist())
    return discrep_indices


def ejecutar_conciliacion(banco, mayor, discrep_indices):
    """Ejecuta el proceso completo de conciliación"""
    banco_matched = set()
    mayor_matched = set()
    
    with st.spinner('🔍 Buscando matches 1:1 (tolerancia estándar)...'):
        matches_1a1 = conciliar_1a1(banco, mayor, banco_matched, mayor_matched, discrep_indices)
    
    with st.spinner('📊 Buscando matches por resumen de categorías...'):
        matches_resumen = conciliar_resumen_categorias(banco, mayor, banco_matched, mayor_matched, discrep_indices)
    
    with st.spinner('🔍 Buscando matches adicionales (tolerancia ampliada)...'):
        matches_1a1_ampliado = conciliar_1a1_ampliado(banco, mayor, banco_matched, mayor_matched, discrep_indices)
    
    # Consolidar matches
    matches_1a1_todos = pd.concat([matches_1a1, matches_1a1_ampliado], ignore_index=True) if not matches_1a1_ampliado.empty else matches_1a1
    
    # Chequeo de imputación
    if not matches_1a1_todos.empty:
        matches_1a1_todos = chequear_imputacion(matches_1a1_todos)
    
    # Control global
    totales = control_global_totales(banco, mayor)
    
    # Validación de discrepancias
    falsos_positivos = discrep_indices & banco_matched
    discrep_ok = discrep_indices - banco_matched
    
    # No conciliados
    banco_no_conc = banco[~banco.index.isin(banco_matched)]
    mayor_no_conc = mayor[~mayor.index.isin(mayor_matched)]
    
    return {
        'matches_1a1': matches_1a1_todos,
        'matches_resumen': matches_resumen,
        'banco_no_conc': banco_no_conc,
        'mayor_no_conc': mayor_no_conc,
        'totales': totales,
        'discrep_indices': discrep_indices,
        'falsos_positivos': falsos_positivos,
        'discrep_ok': discrep_ok
    }


def generar_zip_reportes(resultados, banco, mayor):
    """Genera un archivo ZIP con todos los reportes"""
    zip_buffer = io.BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Matches 1:1
        if not resultados['matches_1a1'].empty:
            csv_buffer = io.StringIO()
            resultados['matches_1a1'].to_csv(csv_buffer, index=False, encoding='utf-8-sig')
            zip_file.writestr('matches_1a1.csv', csv_buffer.getvalue())
        
        # Matches resumen
        if not resultados['matches_resumen'].empty:
            csv_buffer = io.StringIO()
            resultados['matches_resumen'].to_csv(csv_buffer, index=False, encoding='utf-8-sig')
            zip_file.writestr('matches_resumen_categoria.csv', csv_buffer.getvalue())
        
        # No conciliados (posibles discrepancias)
        csv_buffer = io.StringIO()
        resultados['banco_no_conc'].to_csv(csv_buffer, index=False, encoding='utf-8-sig')
        zip_file.writestr('no_conciliados_banco.csv', csv_buffer.getvalue())
        
        csv_buffer = io.StringIO()
        resultados['mayor_no_conc'].to_csv(csv_buffer, index=False, encoding='utf-8-sig')
        zip_file.writestr('no_conciliados_mayor.csv', csv_buffer.getvalue())
        
        # Reporte de discrepancias detectadas (transferencias sin match)
        banco_no_conc = resultados['banco_no_conc']
        discrepancias_detectadas = banco_no_conc[
            banco_no_conc['Categoria_normalizada'] == 'TRANSFERENCIA'
        ].copy()
        
        if not discrepancias_detectadas.empty:
            csv_buffer = io.StringIO()
            discrepancias_detectadas.to_csv(csv_buffer, index=False, encoding='utf-8-sig')
            zip_file.writestr('discrepancias_detectadas.csv', csv_buffer.getvalue())
        
        # Resumen
        totales = resultados['totales']
        discrep = resultados['discrep_indices']
        falsos = resultados['falsos_positivos']
        
        resumen_txt = f"""
RESUMEN GLOBAL DE CONCILIACIÓN
{'='*80}

TOTALES:
  Total BANCO:             ${totales['total_banco']:,.2f}
  Total MAYOR:             ${totales['total_mayor']:,.2f}
  Diferencia:              ${totales['diferencia']:,.2f}
  Tolerancia global:       ${totales['tolerancia_global']:,.2f}
  Estado:                  {totales['estado']}

MATCHES:
  Matches 1:1:             {len(resultados['matches_1a1'])}
  Matches por resumen:     {len(resultados['matches_resumen'])}
  
NO CONCILIADOS:
  Banco sin match:         {len(resultados['banco_no_conc'])}
  Mayor sin match:         {len(resultados['mayor_no_conc'])}

DISCREPANCIAS REALES:
  Total identificadas:     {len(discrep)}
  No conciliadas (OK):     {len(discrep) - len(falsos)}
  Conciliadas (ERROR):     {len(falsos)}

{'='*80}
"""
        zip_file.writestr('resumen.txt', resumen_txt)
    
    zip_buffer.seek(0)
    return zip_buffer


# ============================================================================
# INTERFAZ PRINCIPAL
# ============================================================================

def main():
    st.markdown('<div class="main-header">💰 Sistema de Conciliación Bancaria</div>', unsafe_allow_html=True)
    
    # Info compacta
    with st.expander("ℹ️ Información", expanded=False):
        st.markdown("""
        **Archivos requeridos:**
        - 🏦 Extracto Bancario (CSV)
        - 📚 Libro Mayor (CSV)
        
        **Formato:** separador `;` | encoding `latin-1` o `utf-8`  
        **Montos:** `$1.234,56` o `($1.234,56)`
        """)
    
    # Mensaje de navegación si se acaba de ejecutar
    if 'just_executed' in st.session_state and st.session_state['just_executed']:
        st.success("✅ Conciliación completada. Ve a la pestaña **'📊 Resultados'** para ver los detalles.")
        st.session_state['just_executed'] = False
    
    # Tabs principales con descripciones
    tab1, tab2, tab3 = st.tabs([
        "📤 Cargar | Subir extracto y mayor",
        "📊 Resultados | Errores y matches", 
        "📥 Descargar | Exportar reportes"
    ])
    
    # ========================================================================
    # TAB 1: CARGAR ARCHIVOS
    # ========================================================================
    
    with tab1:
        st.markdown("### 📤 Cargar Archivos")
        
        col1, col2 = st.columns(2, gap="medium")
        
        with col1:
            st.markdown("**🏦 Extracto Bancario**")
            uploaded_banco = st.file_uploader(
                "Arrastrar o seleccionar archivo",
                type=['csv'],
                key='banco',
                help="Extracto bancario con movimientos del período",
                label_visibility="collapsed"
            )
            if uploaded_banco:
                st.success(f"✓ {uploaded_banco.name}")
        
        with col2:
            st.markdown("**📚 Libro Mayor**")
            uploaded_mayor = st.file_uploader(
                "Arrastrar o seleccionar archivo",
                type=['csv'],
                key='mayor',
                help="Libro mayor contable del mismo período",
                label_visibility="collapsed"
            )
            if uploaded_mayor:
                st.success(f"✓ {uploaded_mayor.name}")
        
        st.markdown("")  # Espaciado mínimo
        
        if uploaded_banco and uploaded_mayor:
            if st.button("🚀 Ejecutar Conciliación", type="primary", use_container_width=True):
                with st.spinner('⏳ Procesando archivos...'):
                    # Cargar archivos
                    banco_df, error_banco = cargar_csv(uploaded_banco, "Extracto Bancario")
                    mayor_df, error_mayor = cargar_csv(uploaded_mayor, "Libro Mayor")
                    
                    if error_banco or error_mayor:
                        st.error(error_banco or error_mayor)
                        return
                    
                    # Normalizar
                    try:
                        banco_df = normalizar_extracto(banco_df)
                        mayor_df = normalizar_mayor(mayor_df)
                        
                        st.success(f"✅ Extracto: {len(banco_df)} registros | Mayor: {len(mayor_df)} registros")
                    except Exception as e:
                        st.error(f"❌ Error al normalizar datos: {str(e)}")
                        return
                    
                    # Validar que ambos archivos correspondan al mismo período
                    periodo_ok, periodo_msg = validar_periodo(banco_df, mayor_df)
                    
                    # Guardar datos temporales para poder usarlos después de la confirmación
                    st.session_state['banco_temp'] = banco_df
                    st.session_state['mayor_temp'] = mayor_df
                    st.session_state['periodo_validado'] = periodo_ok
                    st.session_state['periodo_msg'] = periodo_msg
                    
                    if periodo_ok:
                        st.info(f"📅 {periodo_msg}")
                        st.session_state['puede_ejecutar'] = True
                    else:
                        st.session_state['puede_ejecutar'] = False
                    
                    # Si hay problemas de período, mostrar modal
                    if not periodo_ok:
                        # Mostrar modal centrado con overlay
                        st.markdown("""
                        <div style="
                            position: fixed;
                            top: 0;
                            left: 0;
                            width: 100%;
                            height: 100%;
                            background: rgba(0, 0, 0, 0.7);
                            display: flex;
                            justify-content: center;
                            align-items: center;
                            z-index: 9999;
                        ">
                            <div style="
                                background: white;
                                padding: 2.5rem;
                                border-radius: 12px;
                                max-width: 550px;
                                box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
                            ">
                                <div style="
                                    font-size: 1.8rem;
                                    color: #e74c3c;
                                    font-weight: 600;
                                    margin-bottom: 1.5rem;
                                    text-align: center;
                                ">
                                    ⚠️ ALERTA: Períodos Discordantes
                                </div>
                                <div style="
                                    color: #2c3e50;
                                    line-height: 1.8;
                                    margin-bottom: 2rem;
                                    white-space: pre-line;
                                    text-align: center;
                                ">
                        """ + periodo_msg.replace('\n', '<br>') + """
                                </div>
                            </div>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        # Botones debajo del overlay (centrados)
                        st.markdown("")
                        col1, col2, col3 = st.columns([1, 2, 1])
                        with col2:
                            st.markdown("**¿Deseas continuar de todas formas?**")
                            
                            col_btn1, col_btn2 = st.columns(2)
                            with col_btn1:
                                cancelar = st.button("❌ Cancelar", type="secondary", use_container_width=True, key="btn_cancelar")
                            with col_btn2:
                                confirmar = st.button("✅ Continuar", type="primary", use_container_width=True, key="btn_confirmar")
                        
                        if cancelar:
                            st.warning("🛑 Conciliación cancelada. Por favor, verifica los archivos.")
                            st.stop()
                        
                        if not confirmar:
                            st.stop()  # Esperar decisión del usuario
                        else:
                            st.session_state['puede_ejecutar'] = True
                            st.warning("⚠️ Usuario confirmó continuar a pesar del desfase de período.")
                    
                    # Ejecutar conciliación si se permite
                    if st.session_state.get('puede_ejecutar', False):
                        banco_df = st.session_state['banco_temp']
                        mayor_df = st.session_state['mayor_temp']
                        
                        resultados = ejecutar_conciliacion(banco_df, mayor_df, set())
                        
                        # Guardar en session_state
                        st.session_state['resultados'] = resultados
                        st.session_state['banco_df'] = banco_df
                        st.session_state['mayor_df'] = mayor_df
                        st.session_state['just_executed'] = True
                        
                        # Limpiar flags temporales
                        if 'banco_temp' in st.session_state:
                            del st.session_state['banco_temp']
                        if 'mayor_temp' in st.session_state:
                            del st.session_state['mayor_temp']
                        
                        st.success("✅ ¡Conciliación completada! 👉 Ve a la pestaña **'📊 Resultados'**")
                        st.balloons()
                        st.info("💡 Consejo: Los movimientos NO conciliados aparecen primero para que los revises.")
        else:
            st.warning("⚠️ Por favor, sube al menos el Extracto Bancario y el Libro Mayor para continuar.")
    
    # ========================================================================
    # TAB 2: RESULTADOS
    # ========================================================================
    
    with tab2:
        if 'resultados' not in st.session_state:
            st.info("ℹ️ Primero carga los archivos y ejecuta la conciliación en la pestaña 'Cargar Archivos'")
            return
        
        resultados = st.session_state['resultados']
        totales = resultados['totales']
        
        st.markdown("### 📊 Resultados de la Conciliación")
        
        # Métricas principales en grid compacto
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "💰 Banco",
                f"${totales['total_banco']/1000000:,.1f}M" if abs(totales['total_banco']) > 1000000 else f"${totales['total_banco']:,.0f}",
                delta=None
            )
        
        with col2:
            st.metric(
                "📚 Mayor",
                f"${totales['total_mayor']/1000000:,.1f}M" if abs(totales['total_mayor']) > 1000000 else f"${totales['total_mayor']:,.0f}",
                delta=None
            )
        
        with col3:
            diferencia_pct = abs(totales['diferencia']/totales['total_banco']*100) if totales['total_banco'] != 0 else 0
            st.metric(
                "🔄 Diferencia",
                f"${totales['diferencia']/1000000:,.1f}M" if abs(totales['diferencia']) > 1000000 else f"${totales['diferencia']:,.0f}",
                delta=f"{diferencia_pct:.1f}%",
                delta_color="inverse"
            )
        
        with col4:
            estado_emoji = "✅" if totales['estado'] == 'OK_GLOBAL' else "⚠️"
            st.metric(
                f"{estado_emoji} Estado",
                "OK" if totales['estado'] == 'OK_GLOBAL' else "Revisar",
                delta=None
            )
        
        # Grid de métricas compacto
        st.markdown("")
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("✅ Conciliados", f"{len(resultados['matches_1a1']) + len(resultados['matches_resumen'])}")
        
        with col2:
            st.metric("📦 Por Resumen", len(resultados['matches_resumen']))
        
        with col3:
            st.metric("❌ Banco s/match", len(resultados['banco_no_conc']))
        
        with col4:
            st.metric("❌ Mayor s/match", len(resultados['mayor_no_conc']))
        
        # Análisis de discrepancias (generado automáticamente)
        banco_no_conc = resultados['banco_no_conc']
        transferencias_sin_match = len(banco_no_conc[banco_no_conc['Categoria_normalizada'] == 'TRANSFERENCIA'])
        
        if transferencias_sin_match > 0:
            st.info(f"🔍 **{transferencias_sin_match}** transferencias sin conciliar detectadas")
        
        # Mostrar NO CONCILIADOS primero (errores a revisar)
        st.markdown("---")
        st.markdown("### ⚠️ Movimientos No Conciliados (Revisar)")
        
        tab_nc1, tab_nc2 = st.tabs(["🏦 Banco sin match", "📚 Mayor sin match"])
        
        with tab_nc1:
            banco_nc = resultados['banco_no_conc']
            
            if not banco_nc.empty:
                # Filtro por categoría
                col1, col2 = st.columns([3, 1])
                with col1:
                    categorias_nc = sorted(banco_nc['Categoria_normalizada'].unique().tolist())
                    cat_filter_nc = st.multiselect(
                        "Filtrar por categoría",
                        options=categorias_nc,
                        default=None,
                        key="cat_nc_banco"
                    )
                with col2:
                    num_nc = st.selectbox(
                        "Mostrar",
                        options=[50, 100, 200],
                        index=1,
                        key="num_nc_banco"
                    )
                
                # Aplicar filtros
                banco_nc_filtrado = banco_nc.copy()
                if cat_filter_nc:
                    banco_nc_filtrado = banco_nc_filtrado[banco_nc_filtrado['Categoria_normalizada'].isin(cat_filter_nc)]
                
                # Mostrar datos relevantes
                cols_mostrar = ['Fecha Valor', 'Monto', 'Categoria_normalizada', 'Descripción']
                df_display = banco_nc_filtrado[cols_mostrar].head(num_nc).copy()
                df_display.columns = ['Fecha', 'Monto', 'Categoría', 'Descripción']
                df_display['Monto'] = df_display['Monto'].apply(lambda x: f"${x:,.2f}")
                
                st.dataframe(df_display, use_container_width=True, height=350)
                st.caption(f"📊 Mostrando {len(df_display)} de {len(banco_nc_filtrado)} filtrados (Total: {len(banco_nc)})")
            else:
                st.success("✅ Todos los movimientos del banco están conciliados")
        
        with tab_nc2:
            mayor_nc = resultados['mayor_no_conc']
            
            if not mayor_nc.empty:
                # Filtro por categoría
                col1, col2 = st.columns([3, 1])
                with col1:
                    categorias_nc_m = sorted(mayor_nc['Categoria_normalizada'].unique().tolist())
                    cat_filter_nc_m = st.multiselect(
                        "Filtrar por categoría",
                        options=categorias_nc_m,
                        default=None,
                        key="cat_nc_mayor"
                    )
                with col2:
                    num_nc_m = st.selectbox(
                        "Mostrar",
                        options=[50, 100, 200],
                        index=1,
                        key="num_nc_mayor"
                    )
                
                # Aplicar filtros
                mayor_nc_filtrado = mayor_nc.copy()
                if cat_filter_nc_m:
                    mayor_nc_filtrado = mayor_nc_filtrado[mayor_nc_filtrado['Categoria_normalizada'].isin(cat_filter_nc_m)]
                
                # Mostrar datos relevantes
                cols_mostrar = ['Fecha', 'Monto', 'Categoria_normalizada', 'Descripción', 'Tipo']
                df_display = mayor_nc_filtrado[cols_mostrar].head(num_nc_m).copy()
                df_display.columns = ['Fecha', 'Monto', 'Categoría', 'Descripción', 'Tipo']
                df_display['Monto'] = df_display['Monto'].apply(lambda x: f"${x:,.2f}")
                
                st.dataframe(df_display, use_container_width=True, height=350)
                st.caption(f"📊 Mostrando {len(df_display)} de {len(mayor_nc_filtrado)} filtrados (Total: {len(mayor_nc)})")
            else:
                st.success("✅ Todos los movimientos del mayor están conciliados")
        
        # Detalles de matches en expander (secundario)
        st.markdown("")
        with st.expander("✅ Ver Detalles de Matches Exitosos", expanded=False):
            if not resultados['matches_1a1'].empty:
                # Filtros en una sola fila
                col1, col2, col3 = st.columns([2, 1, 1])
                
                with col1:
                    categorias_disponibles = sorted(resultados['matches_1a1']['categoria_banco'].unique().tolist())
                    categoria_filter = st.multiselect(
                        "Categoría",
                        options=categorias_disponibles,
                        default=None,
                        key="cat_filter"
                    )
                
                with col2:
                    imputacion_filter = st.selectbox(
                        "Imputación",
                        options=['Todos', 'Correcta', 'Crítica'],
                        key="imp_filter"
                    )
                
                with col3:
                    num_registros = st.selectbox(
                        "Mostrar",
                        options=[50, 100, 200, 500],
                        index=1,
                        key="num_filter"
                    )
                
                # Aplicar filtros
                df_filtrado = resultados['matches_1a1'].copy()
                
                if categoria_filter:
                    df_filtrado = df_filtrado[df_filtrado['categoria_banco'].isin(categoria_filter)]
                
                if imputacion_filter == 'Correcta':
                    df_filtrado = df_filtrado[df_filtrado['imputacion_ok'] == True]
                elif imputacion_filter == 'Crítica':
                    df_filtrado = df_filtrado[df_filtrado['imputacion_ok'] == False]
                
                # Preparar datos para mostrar
                df_display = df_filtrado[['fecha_banco', 'monto_banco', 'monto_mayor', 'diff_monto', 
                                         'diff_dias', 'categoria_banco', 'categoria_mayor', 
                                         'imputacion_ok', 'desc_banco']].head(num_registros).copy()
                
                # Renombrar columnas para mejor visualización
                df_display.columns = ['Fecha', 'Monto Banco', 'Monto Mayor', 'Diferencia', 
                                     'Días Dif.', 'Cat. Banco', 'Cat. Mayor', 'Imput. OK', 'Descripción']
                
                # Formatear montos
                for col in ['Monto Banco', 'Monto Mayor', 'Diferencia']:
                    df_display[col] = df_display[col].apply(lambda x: f"${x:,.2f}")
                
                # Mostrar tabla
                st.dataframe(
                    df_display,
                    use_container_width=True,
                    height=350
                )
                
                st.caption(f"📊 Mostrando {len(df_display)} de {len(df_filtrado)} registros filtrados (Total: {len(resultados['matches_1a1'])})")
            else:
                st.info("No se encontraron matches 1:1")
    
    # ========================================================================
    # TAB 3: DESCARGAR REPORTES
    # ========================================================================
    
    with tab3:
        if 'resultados' not in st.session_state:
            st.info("ℹ️ Primero ejecuta la conciliación para generar reportes")
            return
        
        st.markdown("### 📥 Descargar Reportes")
        
        resultados = st.session_state['resultados']
        banco_df = st.session_state['banco_df']
        mayor_df = st.session_state['mayor_df']
        
        # Contenedor con padding para evitar margen derecho
        container = st.container()
        with container:
            # Resumen de reportes en columnas
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("✅ Matches", len(resultados['matches_1a1']))
            with col2:
                st.metric("❌ Banco s/match", len(resultados['banco_no_conc']))
            with col3:
                st.metric("❌ Mayor s/match", len(resultados['mayor_no_conc']))
            
            st.markdown("")
            
            # Generar ZIP
            zip_buffer = generar_zip_reportes(resultados, banco_df, mayor_df)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            st.download_button(
                label="📦 Descargar Todos (ZIP)",
                data=zip_buffer,
                file_name=f"Reportes_Conciliacion_{timestamp}.zip",
                mime="application/zip",
                type="primary",
                use_container_width=True
            )
            
            # Descargas individuales en expander
            with st.expander("📄 Descargas Individuales", expanded=False):
                col1, col2 = st.columns(2, gap="small")
                
                with col1:
                    if not resultados['matches_1a1'].empty:
                        csv = resultados['matches_1a1'].to_csv(index=False, encoding='utf-8-sig')
                        st.download_button(
                            "Matches 1:1",
                            data=csv,
                            file_name=f"matches_1a1_{timestamp}.csv",
                            mime="text/csv",
                            use_container_width=True
                        )
                    
                    csv = resultados['banco_no_conc'].to_csv(index=False, encoding='utf-8-sig')
                    st.download_button(
                        "No Conc. Banco",
                        data=csv,
                        file_name=f"no_conciliados_banco_{timestamp}.csv",
                        mime="text/csv",
                        use_container_width=True
                    )
                
                with col2:
                    if not resultados['matches_resumen'].empty:
                        csv = resultados['matches_resumen'].to_csv(index=False, encoding='utf-8-sig')
                        st.download_button(
                            "Matches Resumen",
                            data=csv,
                            file_name=f"matches_resumen_{timestamp}.csv",
                            mime="text/csv",
                            use_container_width=True
                        )
                    
                    csv = resultados['mayor_no_conc'].to_csv(index=False, encoding='utf-8-sig')
                    st.download_button(
                        "No Conc. Mayor",
                        data=csv,
                        file_name=f"no_conciliados_mayor_{timestamp}.csv",
                        mime="text/csv",
                        use_container_width=True
                    )


if __name__ == "__main__":
    main()

