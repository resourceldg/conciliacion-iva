# 💰 Sistema de Conciliación Bancaria - Windows

Guía de instalación y uso para Windows 10/11

---

## 🚀 Inicio Rápido

### 1️⃣ Requisitos Previos

**Instalar Python 3.8 o superior:**
- Descargar desde: https://www.python.org/downloads/
- ✅ **IMPORTANTE**: Marcar "Add Python to PATH" durante la instalación

**Verificar instalación:**
```cmd
python --version
```

### 2️⃣ Primera Vez - Instalación

**Opción A: Doble clic**
- Hacer doble clic en `iniciar_app.bat`
- El script creará automáticamente el entorno virtual e instalará dependencias

**Opción B: Línea de comandos**
```cmd
cd C:\ruta\a\carolina_1\Algoritmo_conciliatorio_mensual

REM Crear entorno virtual
python -m venv venv

REM Activar entorno
venv\Scripts\activate

REM Instalar dependencias
pip install -r requirements.txt
```

### 3️⃣ Iniciar la Aplicación

**Método 1: Script automático (Recomendado)**
```
Doble clic en: iniciar_app.bat
```

**Método 2: Línea de comandos**
```cmd
cd C:\ruta\a\carolina_1\Algoritmo_conciliatorio_mensual
venv\Scripts\activate
streamlit run app_conciliacion.py
```

La aplicación se abrirá automáticamente en: **http://localhost:8501**

---

## 📁 Estructura de Archivos

```
Algoritmo_conciliatorio_mensual/
│
├── 📄 app_conciliacion.py          # Aplicación web principal
├── 📄 conciliacion_contable.py     # Motor de conciliación
├── 📄 iniciar_app.bat              # Script de inicio Windows
├── 📄 iniciar_app.sh               # Script de inicio Linux/Mac
├── 📄 requirements.txt             # Dependencias Python
│
├── 📁 venv/                        # Entorno virtual (se crea automáticamente)
│
└── 📁 Reportes_Conciliacion_*/     # Reportes generados (con timestamp)
    ├── matches_1a1.csv
    ├── matches_resumen_categoria.csv
    ├── no_conciliados_banco.csv
    ├── no_conciliados_mayor.csv
    ├── discrepancias_detectadas.csv
    └── resumen.txt
```

---

## 🎯 Flujo de Trabajo

### Paso 1: Iniciar la Aplicación
```
Doble clic en: iniciar_app.bat
```

### Paso 2: Cargar Archivos
1. Ir a la pestaña **"📤 Cargar Archivos"**
2. Subir los 2 archivos CSV:
   - 🏦 **Extracto Bancario**
   - 📚 **Libro Mayor**
3. Click en **"🚀 Ejecutar Conciliación"**

### Paso 3: Ver Resultados
- Ir a **"📊 Resultados"**
- Ver métricas, gráficos y tabla detallada
- Filtrar por categoría o imputación

### Paso 4: Descargar Reportes
- Ir a **"📥 Descargar Reportes"**
- Descargar ZIP completo o archivos individuales

---

## 📊 Formato de Archivos CSV

### Extracto Bancario
```csv
Cuenta;Fecha Valor;Descripción;Importe;...
CC 1-826087/1;01/01/2025;Transferencia;$1.234,56;...
```

### Libro Mayor
```csv
Fecha;Tipo;Descripción;Débito;Crédito;Saldo
01/01/2025;REC;Cobro Cliente;$1.234,56;$0,00;$5.678,90
```

**Importante:**
- ✅ Separador: `;` (punto y coma)
- ✅ Encoding: `latin-1` o `utf-8`
- ✅ Formato montos: `$1.234,56` o `($1.234,56)` para negativos

---

## 📦 Reportes Generados

| Archivo | Descripción | Uso |
|---------|-------------|-----|
| `matches_1a1.csv` | Conciliaciones individuales | Revisar matches correctos |
| `matches_resumen_categoria.csv` | Asientos consolidados | Ver resúmenes de IIBB, impuestos |
| `no_conciliados_banco.csv` | Sin match en banco | Investigar movimientos pendientes |
| `no_conciliados_mayor.csv` | Sin match en mayor | Investigar asientos pendientes |
| **`discrepancias_detectadas.csv`** | **Transferencias sin match** | **Revisar manualmente** |
| `resumen.txt` | Resumen ejecutivo | Vista general de conciliación |

---

## 🔧 Solución de Problemas en Windows

### Error: "Python no reconocido como comando"
✅ **Solución**: Reinstalar Python marcando "Add Python to PATH"

### Error: "pip no encontrado"
✅ **Solución**:
```cmd
python -m ensurepip --upgrade
```

### Error: "No se puede activar venv"
✅ **Solución**: Ejecutar PowerShell como Administrador:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### El navegador no se abre automáticamente
✅ **Solución**: Abrir manualmente: http://localhost:8501

### Puerto 8501 ocupado
✅ **Solución**: Usar otro puerto:
```cmd
streamlit run app_conciliacion.py --server.port 8502
```

---

## 🛑 Detener la Aplicación

**Método 1:** Presionar `Ctrl + C` en la ventana de comandos

**Método 2:** Cerrar la ventana de comandos

**Método 3:** Desde el Administrador de Tareas:
1. Abrir Administrador de Tareas (Ctrl + Shift + Esc)
2. Buscar proceso "python.exe" o "streamlit"
3. Finalizar tarea

---

## 📝 Notas Importantes

### Antivirus
Si el antivirus bloquea la aplicación:
1. Agregar carpeta como excepción en Windows Defender
2. O permitir "python.exe" temporalmente

### Firewall
Si el navegador no conecta:
1. Permitir puerto 8501 en Firewall de Windows
2. O usar `http://127.0.0.1:8501` en lugar de `localhost`

### Rendimiento
- Mínimo: 4 GB RAM
- Recomendado: 8 GB RAM
- Archivos grandes (>50k registros): puede tardar 1-2 minutos

---

## 🆘 Soporte

### Logs
Si hay errores, revisar:
```
venv\Scripts\streamlit.log
```

### Reinstalación Limpia
```cmd
REM Eliminar entorno virtual
rmdir /s /q venv

REM Ejecutar nuevamente
iniciar_app.bat
```

---

## ✅ Checklist de Instalación

- [ ] Python 3.8+ instalado
- [ ] Python agregado al PATH
- [ ] Ejecutado `iniciar_app.bat`
- [ ] Entorno virtual creado
- [ ] Dependencias instaladas
- [ ] Aplicación corriendo en http://localhost:8501
- [ ] CSV de prueba cargados correctamente

---

## 🎉 ¡Listo!

```
Doble clic en: iniciar_app.bat
```

Y comienza a conciliar tus archivos contables.

---

**Versión:** 1.0  
**Compatible con:** Windows 10, Windows 11  
**Python:** 3.8+  
**Fecha:** Diciembre 2025

