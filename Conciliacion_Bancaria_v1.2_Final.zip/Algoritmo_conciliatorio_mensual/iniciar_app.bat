@echo off
REM Script para iniciar la aplicación de conciliación bancaria en Windows

echo ===================================================================
echo    💰 Sistema de Conciliación Bancaria - Iniciando...
echo ===================================================================

REM Verificar si existe el entorno virtual
IF NOT EXIST venv (
    echo.
    echo ⚠️  No se encontró el entorno virtual.
    echo    Creando entorno virtual...
    python -m venv venv
    
    echo.
    echo 📦 Instalando dependencias...
    call venv\Scripts\activate.bat
    pip install -r requirements.txt
) ELSE (
    REM Activar entorno virtual
    call venv\Scripts\activate.bat
)

echo.
echo 📋 Instrucciones:
echo   1. La aplicación se abrirá en tu navegador automáticamente
echo   2. Si no se abre, visita: http://localhost:8501
echo   3. Para detener, presiona Ctrl+C en esta ventana
echo.
echo 🚀 Iniciando Streamlit...
echo.

REM Ejecutar Streamlit
streamlit run app_conciliacion.py

pause

