# 💰 Sistema de Conciliación Bancaria - Aplicación Web

Aplicación web interactiva para conciliación automática entre extracto bancario y libro mayor contable.

---

## 🚀 Inicio Rápido

### Opción 1: Script de inicio (Recomendado)

```bash
cd /home/zen/carolina_1/Algoritmo_conciliatorio_mensual
./iniciar_app.sh
```

### Opción 2: Manual

```bash
cd /home/zen/carolina_1/Algoritmo_conciliatorio_mensual
source venv/bin/activate
streamlit run app_conciliacion.py
```

La aplicación se abrirá automáticamente en tu navegador en: **http://localhost:8501**

---

## 📋 Características Principales

### ✅ Interfaz Intuitiva
- **Drag & Drop**: Arrastra y suelta archivos CSV
- **Visualización en tiempo real**: Resultados inmediatos
- **Reportes descargables**: ZIP con todos los archivos

### 📊 Capacidades de Conciliación
1. **Match 1:1 Estándar**: ±7 días, 5% o $5k tolerancia
2. **Match por Resumen**: Asientos consolidados (IIBB, Impuesto Ley, Gastos Bancarios)
3. **Match Ampliado**: ±10 días, 10% o $10k tolerancia (rescate de movimientos)
4. **Protección de Discrepancias**: Validación automática de discrepancias reales

### 📈 Métricas y Análisis
- **Totales globales**: Banco, Mayor, Diferencia
- **Estado de conciliación**: OK_GLOBAL / ALERTA_GLOBAL
- **Distribución por categorías**: Análisis detallado
- **Validación de imputación**: Detección de errores contables

---

## 📁 Archivos Requeridos

### 1. Extracto Bancario (`bind_lucas.csv`) - **OBLIGATORIO**
```
Formato: CSV separado por ;
Encoding: latin-1 o utf-8
Columnas esperadas:
  - Fecha Valor
  - Importe
  - Descripción
  - ... (otras columnas opcionales)
```

### 2. Libro Mayor (`Mayor_Lucas.csv`) - **OBLIGATORIO**
```
Formato: CSV separado por ;
Encoding: latin-1 o utf-8
Columnas esperadas:
  - Fecha
  - Tipo
  - Descripción
  - Débito
  - Crédito
  - Saldo
```

### 3. Discrepancias Reales (`discrepanciasreales.csv`) - **OPCIONAL**
```
Formato: CSV separado por ;
Encoding: latin-1 o utf-8
Columnas esperadas:
  - Fecha Valor
  - Importe
  - Descripción
  
Propósito: Movimientos conocidos que NO deben conciliarse
```

---

## 🎯 Flujo de Trabajo

```
1. Cargar Archivos
   ↓
2. Ejecutar Conciliación (botón 🚀)
   ↓
3. Ver Resultados
   ├─ Métricas principales
   ├─ Distribución por categorías
   ├─ Validación de discrepancias
   └─ Tabla detallada de matches
   ↓
4. Descargar Reportes
   ├─ ZIP completo
   └─ Archivos individuales
```

---

## 📊 Pantallas de la Aplicación

### 1️⃣ **Cargar Archivos**
- Subir CSV de extracto, mayor y discrepancias
- Validación automática de formato
- Vista previa de registros cargados

### 2️⃣ **Resultados**
- **Métricas Clave**: Total Banco, Mayor, Diferencia, Estado
- **Resumen de Matches**: 1:1, Resumen, No Conciliados
- **Validación**: Discrepancias reales protegidas
- **Tabla Detallada**: Con filtros por categoría e imputación

### 3️⃣ **Descargar Reportes**
- **ZIP completo**: Todos los reportes en un archivo
- **Descargas individuales**: CSVs específicos
- **Timestamp**: Archivos fechados automáticamente

---

## 📦 Reportes Generados

| Archivo | Descripción |
|---------|-------------|
| `matches_1a1.csv` | Conciliaciones individuales (banco ↔ mayor) |
| `matches_resumen_categoria.csv` | Asientos consolidados |
| `no_conciliados_banco.csv` | Movimientos del banco sin match |
| `no_conciliados_mayor.csv` | Movimientos del mayor sin match |
| `resumen.txt` | Resumen ejecutivo con totales y estadísticas |

---

## 🎨 Funcionalidades Adicionales

### Filtros Inteligentes
- **Por Categoría**: IIBB, TRANSFERENCIA, IMPUESTO_LEY, etc.
- **Por Imputación**: Correcta / Crítica
- **Vista previa**: Primeros 100 registros

### Validación de Calidad
- ✅ Detección de falsos positivos
- ✅ Verificación de discrepancias reales
- ✅ Control de imputación contable
- ✅ Estado global de conciliación

---

## 🔧 Configuración Avanzada

### Tolerancias de Match

**Nivel 1 (Estándar)**:
```python
Días: ±7
Monto: min($5,000 o 5% del monto)
```

**Nivel 2 (Ampliado)**:
```python
Días: ±10
Monto: min($10,000 o 10% del monto)
```

**Categorías Consolidadas**:
```python
- SIRCREB
- SIRTAC
- IIBB
- IMPUESTO_LEY
- GASTOS_BANCARIOS
```

---

## 🐛 Solución de Problemas

### Error: "No se puede leer el archivo"
✅ **Solución**: Verifica que el archivo sea CSV con separador `;` y encoding `latin-1` o `utf-8`

### Error: "Columnas faltantes"
✅ **Solución**: Asegúrate de que los archivos contengan las columnas obligatorias listadas arriba

### La aplicación no se abre
✅ **Solución**: 
```bash
# Verificar que el puerto 8501 esté libre
lsof -i :8501

# O usar otro puerto
streamlit run app_conciliacion.py --server.port 8502
```

---

## 📞 Soporte

Para problemas o sugerencias:
1. Revisa el archivo `resumen.txt` generado
2. Consulta los logs de la aplicación en la terminal
3. Verifica que todos los archivos CSV estén correctamente formateados

---

## 📝 Notas Técnicas

- **Framework**: Streamlit 1.20+
- **Backend**: Python 3.8+
- **Librerías**: pandas, rapidfuzz, scipy
- **Formato de montos**: ARS (pesos argentinos)
- **Formato de fechas**: DD/MM/YYYY

---

## 🎉 ¡Listo para usar!

```bash
./iniciar_app.sh
```

Abre tu navegador en **http://localhost:8501** y comienza a conciliar.

---

**Versión:** 1.0  
**Fecha:** Diciembre 2025  
**Licencia:** Uso Interno

