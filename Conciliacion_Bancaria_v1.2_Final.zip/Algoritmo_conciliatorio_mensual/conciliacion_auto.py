#!/usr/bin/env python3
"""
Conciliación automática entre extracto bancario, libro mayor y discrepancias reales.

Entradas esperadas (en el mismo directorio del script):
  - bind_lucas.csv              (extracto bancario)
  - Mayor_Lucas.csv             (libro mayor)
  - discrepanciasreales.csv     (discrepancias confirmadas)

Salidas:
  - conciliados_strictos.csv
  - conciliados_heuristicos.csv
  - conciliados_agrupados.csv
  - no_conciliados.csv
  - falsos_positivos.csv

Requisitos:
  - pandas
  - rapidfuzz (para similitud de texto; puede usarse fuzz.ratio equivalente)

La lógica implementa:
  1) Parseo/normalización
  2) Identificación de discrepancias reales
  3) Matching estricto (±3 días, monto exacto, similitud >= 0.7)
  4) Matching heurístico (±5 días, tolerancia de monto dinámica, similitud >= 0.4)
  5) Matching agrupado 1:N / N:1 (±5 días, tolerancia dinámica, similitud promedio >= 0.4)
  6) Validación contra discrepancias reales (evitar falsos positivos)
  7) Reportes y resúmenes
"""

from __future__ import annotations

import itertools
from pathlib import Path
from typing import List, Tuple, Dict, Any

import pandas as pd
from rapidfuzz import fuzz, process
import unicodedata
from tqdm.auto import tqdm
import shutil
import re
import numpy as np
from scipy.optimize import linear_sum_assignment


# ---------------------------------------------------------------------------
# Utilidades de parseo
# ---------------------------------------------------------------------------


def normalize_text(val: Any) -> str:
    """Normaliza texto: minúsculas, sin acentos, espacios colapsados, sin CUIT/DNI ni números largos."""
    s = "" if pd.isna(val) else str(val)
    s = s.lower()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    # eliminar CUIT/DNI y números largos
    s = re.sub(r"\b\d{7,}\b", " ", s)
    s = re.sub(r"\b(cuit|dni|cuil)\b", " ", s)
    # tokens vacíos comunes
    s = s.replace("undefined", " ").replace("null", " ")
    # colapsar espacios
    s = " ".join(s.split())
    return s


def parse_currency(val: Any) -> float:
    """Parsea importes en formato ARS:
    - Elimina $, puntos de miles, paréntesis
    - Cambia coma por punto
    - Paréntesis implica negativo
    """
    if pd.isna(val) or val == "":
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    clean = (
        str(val)
        .replace("$", "")
        .replace(".", "")
        .replace("(", "-")
        .replace(")", "")
        .replace(",", ".")
        .strip()
    )
    try:
        return float(clean)
    except Exception:
        return 0.0


def load_data(
    extracto_path: Path = Path("bind_lucas.csv"),
    mayor_path: Path = Path("Mayor_Lucas.csv"),
    discrep_path: Path = Path("discrepanciasreales.csv"),
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Carga y normaliza los tres CSV."""

    # ----------------------------------------------------------------------
    # Funciones internas de apoyo
    # ----------------------------------------------------------------------
    def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
        """Normaliza nombres de columnas eliminando acentos/espacios y a minúsculas."""
        mapping = {c: normalize_text(c) for c in df.columns}
        return df.rename(columns=mapping)

    def rename_required(df: pd.DataFrame, aliases: Dict[str, List[str]]) -> pd.DataFrame:
        """Renombra columnas según alias normalizados."""
        cols_norm = {normalize_text(c): c for c in df.columns}
        rename_map = {}
        for target, alias_list in aliases.items():
            for a in alias_list:
                if a in cols_norm:
                    rename_map[cols_norm[a]] = target
                    break
        return df.rename(columns=rename_map)

    def require_columns(df: pd.DataFrame, cols: List[str], nombre: str):
        faltantes = [c for c in cols if c not in df.columns]
        if faltantes:
            raise RuntimeError(f"Faltan columnas {faltantes} en {nombre}")
    encoding_options = ["utf-8", "latin-1"]
    for enc in encoding_options:
        try:
            extracto = pd.read_csv(extracto_path, sep=";", encoding=enc)
            break
        except Exception:
            extracto = None
    for enc in encoding_options:
        try:
            mayor = pd.read_csv(mayor_path, sep=";", encoding=enc)
            break
        except Exception:
            mayor = None
    for enc in encoding_options:
        try:
            discrep = pd.read_csv(discrep_path, sep=";", encoding=enc)
            break
        except Exception:
            discrep = None

    if extracto is None or mayor is None or discrep is None:
        raise RuntimeError("No se pudieron cargar los CSV con las codificaciones probadas.")

    # Normalizar nombres y renombrar columnas clave
    extracto = normalize_columns(extracto)
    mayor = normalize_columns(mayor)
    discrep = normalize_columns(discrep)

    extracto = rename_required(extracto, {
        "Fecha Valor": ["fecha_valor", "fecha valor"],
        "Descripción": ["descripcion", "descripción"],
        "Importe": ["importe"],
    })
    mayor = rename_required(mayor, {
        "Fecha": ["fecha"],
        "Descripción": ["descripcion", "descripción"],
        "Débito": ["debito", "débito"],
        "Crédito": ["credito", "crédito"],
    })
    discrep = rename_required(discrep, {
        "Fecha Valor": ["fecha_valor", "fecha valor"],
        "Descripción": ["descripcion", "descripción"],
        "Monto": ["monto"],
    })

    # Fechas
    extracto["Fecha Valor"] = pd.to_datetime(extracto["Fecha Valor"], dayfirst=True, errors="coerce")
    mayor["Fecha"] = pd.to_datetime(mayor["Fecha"], dayfirst=True, errors="coerce")
    discrep["Fecha Valor"] = pd.to_datetime(discrep["Fecha Valor"], dayfirst=True, errors="coerce")

    # Validar columnas mínimas
    require_columns(extracto, ["Fecha Valor", "Descripción", "Importe"], "extracto")
    require_columns(mayor, ["Fecha", "Descripción", "Débito", "Crédito"], "mayor")
    require_columns(discrep, ["Fecha Valor", "Descripción"], "discrepanciasreales")

    # Montos
    extracto["Monto"] = extracto["Importe"].apply(parse_currency).round(2)
    mayor["Débito"] = mayor["Débito"].apply(parse_currency).round(2)
    mayor["Crédito"] = mayor["Crédito"].apply(parse_currency).round(2)
    mayor["Monto"] = (mayor["Crédito"] - mayor["Débito"]).round(2)
    # Para discrepancias, priorizar columna Importe si existe, luego Monto, luego última
    if "Importe" in discrep.columns:
        discrep_monto_col = "Importe"
    elif "importe" in discrep.columns:
        discrep_monto_col = "importe"
    elif "Monto" in discrep.columns:
        discrep_monto_col = "Monto"
    elif "monto" in discrep.columns:
        discrep_monto_col = "monto"
    else:
        discrep_monto_col = discrep.columns[-1]
    discrep["Monto"] = discrep[discrep_monto_col].apply(parse_currency).round(2)

    # Descripciones normalizadas a string sin acentos
    extracto["Descripción_norm"] = extracto["Descripción"].apply(normalize_text)
    mayor["Descripción_norm"] = mayor["Descripción"].apply(normalize_text)
    discrep["Descripción_norm"] = discrep["Descripción"].apply(normalize_text)

    # Remover filas sin fecha válida para evitar inconsistencias
    extracto = extracto.dropna(subset=["Fecha Valor"]).reset_index(drop=True)
    mayor = mayor.dropna(subset=["Fecha"]).reset_index(drop=True)
    discrep = discrep.dropna(subset=["Fecha Valor"]).reset_index(drop=True)

    return extracto, mayor, discrep


# ---------------------------------------------------------------------------
# Ayudas de similitud y tolerancias
# ---------------------------------------------------------------------------

def similitud(desc1: str, desc2: str) -> float:
    """Similitud normalizada 0-1 usando la mejor de:
    - fuzz.ratio
    - fuzz.token_set_ratio
    """
    r1 = fuzz.ratio(desc1, desc2) / 100.0
    r2 = fuzz.token_set_ratio(desc1, desc2) / 100.0
    return max(r1, r2)


def get_tags(desc: str) -> set:
    """Clasifica descripciones en etiquetas simples para bloquear falsos matches."""
    tags = set()
    if any(k in desc for k in ["imp ", "impuesto", "iva", "iibb", "sircreb", "creb", "ley 25413"]):
        tags.add("impuesto")
    if any(k in desc for k in ["comision", "comisión", "gasto banc", "paquete"]):
        tags.add("comision")
    if "transfer" in desc:
        tags.add("transferencia")
    if any(k in desc for k in ["proveedor", "prov"]):
        tags.add("proveedor")
    if any(k in desc for k in ["pos", "tarjeta", "visa", "master"]):
        tags.add("pos")
    if any(k in desc for k in ["cheque", "chq"]):
        tags.add("cheque")
    if any(k in desc for k in ["mep"]):
        tags.add("mep")
    if any(k in desc for k in ["debito", "débito"]):
        tags.add("debito")
    if any(k in desc for k in ["credito", "crédito"]):
        tags.add("credito")
    return tags


def tags_compatibles(tags_a: set, tags_b: set) -> bool:
    """Reglas de bloqueo MÍNIMAS: solo no cruzar impuestos/iibb/comisiones con transferencias a personas.
    El resto se permite para maximizar matches por monto."""
    # Bloqueo único: impuestos/iibb/comisiones NO cruzan con transferencias
    bloqueados_a = {"impuesto", "iibb", "comision"}
    bloqueados_b = {"transferencia"}
    
    if (tags_a & bloqueados_a) and (tags_b & bloqueados_b):
        return False
    if (tags_b & bloqueados_a) and (tags_a & bloqueados_b):
        return False
    
    # TODO LO DEMÁS SE PERMITE (prioridad al monto)
    return True


# ---------------------------------------------------------------------------
# Matching por monto con Hungarian (1:1 por buckets)
# ---------------------------------------------------------------------------


def hungarian_match(extracto: pd.DataFrame, mayor: pd.DataFrame, matched_mayor: set, matched_ext: set, protegidos: set,
                    dias: int, tol_monto: float, etiqueta: str, tags_required: bool = False):
    """Empareja 1:1 por monto/signo usando Hungarian minimizando distancia de fecha.
       - Se requiere compatibilidad de tags; si tags_required=True, se exige intersección de tags.
       - NUNCA concilia registros protegidos (discrepancias reales).
    """
    results = []
    # Buckets por signo y monto redondeado a 2 (luego se aplica tolerancia)
    # CRÍTICO: excluir protegidos (discrepancias reales)
    ext_libre = extracto[~extracto.index.isin(matched_ext) & ~extracto.index.isin(protegidos)].copy()
    may_libre = mayor[~mayor.index.isin(matched_mayor)].copy()

    ext_libre["signo"] = np.sign(ext_libre["Monto"])
    may_libre["signo"] = np.sign(may_libre["Monto"])

    for signo in [-1, 0, 1]:
        ext_sig = ext_libre[ext_libre["signo"] == signo]
        may_sig = may_libre[may_libre["signo"] == signo]
        if ext_sig.empty or may_sig.empty:
            continue

        # Intento exacto por monto redondeado a 2
        for ext_key, ext_bucket in ext_sig.groupby(ext_sig["Monto"].round(2)):
            may_bucket = may_sig[abs(may_sig["Monto"] - ext_key) <= tol_monto]
            if may_bucket.empty:
                continue

            # Construir matriz de costo: distancia de fecha penalizada; inf si tags incompatibles o fecha fuera de ventana
            ext_idx_list = ext_bucket.index.tolist()
            may_idx_list = may_bucket.index.tolist()
            cost = np.full((len(ext_idx_list), len(may_idx_list)), fill_value=1e9)
            for i, ei in enumerate(ext_idx_list):
                e_row = ext_bucket.loc[ei]
                e_tags = get_tags(e_row["Descripción_norm"])
                for j, mi in enumerate(may_idx_list):
                    m_row = may_bucket.loc[mi]
                    m_tags = get_tags(m_row["Descripción_norm"])
                    if not tags_compatibles(e_tags, m_tags):
                        continue
                    if tags_required and not (e_tags & m_tags):
                        continue
                    diff_days = abs((m_row["Fecha"] - e_row["Fecha Valor"]).days)
                    if diff_days > dias:
                        continue
                    # costo: días + diferencia de monto normalizada
                    diff_monto = abs(m_row["Monto"] - e_row["Monto"])
                    cost[i, j] = diff_days + (diff_monto / max(1.0, abs(e_row["Monto"])))*10.0

            row_ind, col_ind = linear_sum_assignment(cost)
            for r, c in zip(row_ind, col_ind):
                if cost[r, c] >= 1e8:
                    continue
                ei = ext_idx_list[r]
                mi = may_idx_list[c]
                matched_ext.add(ei)
                matched_mayor.add(mi)
                results.append({
                    "extracto_idx": ei,
                    "mayor_idx": mi,
                    "tipo": etiqueta,
                    "similitud": 0.0,  # no usamos similitud aquí
                    "diff_dias": (may_bucket.loc[mi]["Fecha"] - ext_bucket.loc[ei]["Fecha Valor"]).days,
                    "monto_ext": ext_bucket.loc[ei]["Monto"],
                    "monto_may": may_bucket.loc[mi]["Monto"],
                })
    return results


def tolerancia_monto(valor: float) -> float:
    """Tolerancia dinámica según el módulo del valor."""
    v = abs(valor)
    if v < 10_000:
        return v * 0.01
    if v < 100_000:
        return 300.0
    return 1000.0


# ---------------------------------------------------------------------------
# Identificación de discrepancias reales
# ---------------------------------------------------------------------------

def mapear_discrepancias_reales(extracto: pd.DataFrame, discrep: pd.DataFrame) -> List[int]:
    """Retorna índices en extracto que están en discrepancias reales (fecha + desc + monto exacto)."""
    idxs = []
    def key(df):
        return (
            df["Fecha Valor"].dt.strftime("%Y-%m-%d")
            + "|"
            + df["Descripción_norm"]
            + "|"
            + df["Monto"].round(2).astype(str)
        )
    discrep_keys = list(key(discrep))
    discrep_key_set = set(discrep_keys)
    for i, k in enumerate(key(extracto)):
        if k in discrep_key_set:
            idxs.append(i)
    if len(idxs) == 0:
        print("⚠ Advertencia: 0 discrepancias mapeadas. Ejemplos de claves:")
        print("  Discrepancias (primeras 3):", discrep_keys[:3])
        ex_keys = list(key(extracto))[:3]
        print("  Extracto (primeras 3):", ex_keys)
    return idxs


# ---------------------------------------------------------------------------
# Matching helpers
# ---------------------------------------------------------------------------

def match_strict(extracto: pd.DataFrame, mayor: pd.DataFrame, matched_mayor: set, matched_ext: set, protegidos: set):
    """Nivel 1: fecha ±30 días, monto exacto, similitud >= 0.01 (ultra-laxo para maximizar matches)."""
    results = []
    for ext_idx, ext_row in tqdm(extracto.iterrows(), total=len(extracto), desc="Nivel 1 (estricto)"):
        if ext_idx in matched_ext or ext_idx in protegidos:
            continue
        candidatos = mayor[
            (mayor.index.isin(matched_mayor) == False)
            & (mayor["Monto"].round(2) == round(ext_row["Monto"], 2))
            & (mayor["Fecha"].between(ext_row["Fecha Valor"] - pd.Timedelta(days=30),
                                      ext_row["Fecha Valor"] + pd.Timedelta(days=30)))
        ]
        if candidatos.empty:
            continue
        # seleccionar por mayor similitud
        candidatos = candidatos.assign(sim=candidatos["Descripción_norm"].apply(lambda d: similitud(d, ext_row["Descripción_norm"])))
        candidatos = candidatos[candidatos["sim"] >= 0.01]
        if candidatos.empty:
            continue
        best = candidatos.sort_values("sim", ascending=False).iloc[0]
        mayor_idx = best.name
        matched_mayor.add(mayor_idx)
        matched_ext.add(ext_idx)
        results.append({
            "extracto_idx": ext_idx,
            "mayor_idx": mayor_idx,
            "tipo": "match_stricto",
            "similitud": best["sim"],
            "diff_dias": (best["Fecha"] - ext_row["Fecha Valor"]).days,
            "monto_ext": ext_row["Monto"],
            "monto_may": best["Monto"],
        })
    return results


def match_heuristico_nivel(
    extracto: pd.DataFrame,
    mayor: pd.DataFrame,
    matched_mayor: set,
    matched_ext: set,
    protegidos: set,
    dias: int,
    sim_min: float,
    fallback_min: float,
    require_tag_intersection: bool = False,
    etiqueta_tipo: str = "match_heuristico",
):
    """Heurística con ventanas y umbrales configurables."""
    results = []
    for ext_idx, ext_row in tqdm(extracto.iterrows(), total=len(extracto), desc=f"Nivel heurístico ({dias}d)"):
        if ext_idx in matched_ext or ext_idx in protegidos:
            continue
        tol = tolerancia_monto(ext_row["Monto"])
        ext_tags = get_tags(ext_row["Descripción_norm"])
        candidatos_base = mayor[
            (mayor.index.isin(matched_mayor) == False)
            & (mayor["Fecha"].between(ext_row["Fecha Valor"] - pd.Timedelta(days=dias),
                                      ext_row["Fecha Valor"] + pd.Timedelta(days=dias)))
            & (abs(mayor["Monto"] - ext_row["Monto"]) <= tol)
        ]
        if candidatos_base.empty:
            continue
        # compatibilidad de tags
        candidatos_base = candidatos_base.assign(_tags=candidatos_base["Descripción_norm"].apply(get_tags))
        candidatos_base = candidatos_base[candidatos_base["_tags"].apply(lambda t: tags_compatibles(ext_tags, t))]
        if candidatos_base.empty:
            continue

        candidatos = candidatos_base.assign(sim=candidatos_base["Descripción_norm"].apply(lambda d: similitud(d, ext_row["Descripción_norm"])))
        pool = candidatos[candidatos["sim"] >= sim_min]
        if pool.empty:
            if not require_tag_intersection:
                pool = candidatos[candidatos["sim"] >= fallback_min]
        if pool.empty:
            continue
        if require_tag_intersection:
            pool = pool[pool["_tags"].apply(lambda t: len(ext_tags & t) > 0)]
            if pool.empty:
                continue
        pool = pool.assign(diff_monto=abs(pool["Monto"] - ext_row["Monto"]))
        best = pool.sort_values(["sim", "diff_monto"], ascending=[False, True]).iloc[0]
        mayor_idx = best.name
        matched_mayor.add(mayor_idx)
        matched_ext.add(ext_idx)
        results.append({
            "extracto_idx": ext_idx,
            "mayor_idx": mayor_idx,
            "tipo": etiqueta_tipo,
            "similitud": best.get("sim", 0.0),
            "diff_dias": (best["Fecha"] - ext_row["Fecha Valor"]).days,
            "monto_ext": ext_row["Monto"],
            "monto_may": best["Monto"],
        })
    return results


def match_agrupado(
    extracto: pd.DataFrame,
    mayor: pd.DataFrame,
    matched_mayor: set,
    matched_ext: set,
    max_group_size: int = 3,
    protegidos: set = None,
):
    """Nivel 3: búsqueda de grupos 1:N / N:1 dentro de ±30 días y tolerancia dinámica ampliada.
    Para controlar el costo, se limita el tamaño del grupo (por defecto 3).
    """
    results = []
    protegidos = protegidos or set()
    mayor_libre = mayor[~mayor.index.isin(matched_mayor)]
    for ext_idx, ext_row in tqdm(extracto.iterrows(), total=len(extracto), desc="Nivel 3 (agrupado)"):
        if ext_idx in matched_ext or ext_idx in protegidos:
            continue
        tol = tolerancia_monto(ext_row["Monto"]) * 2.0  # Tolerancia ampliada
        ext_tags = get_tags(ext_row["Descripción_norm"])
        ventana = mayor_libre[
            mayor_libre["Fecha"].between(ext_row["Fecha Valor"] - pd.Timedelta(days=30),
                                         ext_row["Fecha Valor"] + pd.Timedelta(days=30))
        ]
        if ventana.empty:
            continue

        # Probar combinaciones de tamaño 2..max_group_size
        found = False
        for r in range(2, max_group_size + 1):
            # limitar combinaciones para performance (primeros 200)
            combos = itertools.combinations(ventana.index.tolist(), r)
            for combo in itertools.islice(combos, 200):
                subset = ventana.loc[list(combo)]
                suma = subset["Monto"].sum()
                if abs(suma - ext_row["Monto"]) <= tol:
                    subset_tags_ok = subset["Descripción_norm"].apply(get_tags).apply(lambda t: tags_compatibles(ext_tags, t)).all()
                    if not subset_tags_ok:
                        continue
                    sims = subset["Descripción_norm"].apply(lambda d: similitud(d, ext_row["Descripción_norm"]))
                    if sims.mean() >= 0.01:
                        matched_ext.add(ext_idx)
                        matched_mayor.update(combo)
                        results.append({
                            "extracto_idx": ext_idx,
                            "mayor_idxs": combo,
                            "tipo": "match_agrupado",
                            "similitud_prom": sims.mean(),
                            "diff_monto": suma - ext_row["Monto"],
                        })
                        found = True
                        break
            if found:
                break
    return results


# ---------------------------------------------------------------------------
# Reporte y main
# ---------------------------------------------------------------------------

def generar_reportes(extracto: pd.DataFrame,
                     mayor: pd.DataFrame,
                     discrep_idx: List[int],
                     strictos: List[Dict],
                     heur_a: List[Dict],
                     heur_b: List[Dict],
                     agrup: List[Dict]):
    """Genera dataframes finales, valida discrepancias y escribe CSV."""
    # Limpiar reportes previos en raíz y carpetas pasadas
    for fname in ["conciliados_strictos.csv", "conciliados_heuristicos.csv",
                  "conciliados_agrupados.csv", "no_conciliados.csv", "falsos_positivos.csv"]:
        Path(fname).unlink(missing_ok=True)
    for p in Path(".").glob("Reportes_Conciliacion_*"):
        if p.is_dir():
            shutil.rmtree(p, ignore_errors=True)
    # Carpeta con timestamp
    ts = pd.Timestamp.now().strftime("Reportes_Conciliacion_%Y%m%d_%H%M%S")
    outdir = Path(ts)
    outdir.mkdir(exist_ok=True)
    # Índices conciliados
    conciliados_ext = set([m["extracto_idx"] for m in strictos] +
                          [m["extracto_idx"] for m in heur_a] +
                          [m["extracto_idx"] for m in heur_b] +
                          [m["extracto_idx"] for m in agrup])
    conciliados_may = set([m["mayor_idx"] for m in strictos] +
                          [m["mayor_idx"] for m in heur_a] +
                          [m["mayor_idx"] for m in heur_b])
    for m in agrup:
        conciliados_may.update(m["mayor_idxs"])

    # DataFrames conciliados
    df_strict = pd.DataFrame(strictos)
    df_heur = pd.concat([pd.DataFrame(heur_a), pd.DataFrame(heur_b)], ignore_index=True)
    df_agrup = pd.DataFrame(agrup)

    # No conciliados (extracto)
    no_conc_ext = extracto[~extracto.index.isin(conciliados_ext)].copy()

    # Discrepancias reales detectadas y no detectadas
    discrep_detectadas = [i for i in discrep_idx if i in conciliados_ext]
    discrep_no_detectadas = [i for i in discrep_idx if i not in conciliados_ext]

    # Falsos positivos (conciliados que estaban marcados como discrepancia real)
    falsos = extracto.loc[discrep_detectadas].copy()

    # Resumen global
    suma_extracto = extracto["Monto"].sum()
    suma_mayor = mayor["Monto"].sum()
    suma_conciliada = extracto.loc[list(conciliados_ext), "Monto"].sum()
    diferencia_residual = suma_extracto - suma_conciliada
    tolerancia_global = min(abs(suma_extracto) * 0.01, 10_000)

    resumen = {
        "suma_extracto": suma_extracto,
        "suma_mayor": suma_mayor,
        "suma_conciliada": suma_conciliada,
        "diferencia_residual": diferencia_residual,
        "tolerancia_global": tolerancia_global,
        "conciliados_strictos": len(df_strict),
        "conciliados_heuristicos": len(df_heur),
        "conciliados_agrupados": len(df_agrup),
        "no_conciliados": len(no_conc_ext),
        "discrepancias_reales": len(discrep_idx),
        "discrepancias_detectadas": len(discrep_detectadas),
        "discrepancias_no_detectadas": len(discrep_no_detectadas),
        "falsos_positivos": len(falsos),
    }

    # Escritura de CSV
    df_strict.to_csv(outdir / "conciliados_strictos.csv", index=False, encoding="utf-8-sig")
    df_heur.to_csv(outdir / "conciliados_heuristicos.csv", index=False, encoding="utf-8-sig")
    df_agrup.to_csv(outdir / "conciliados_agrupados.csv", index=False, encoding="utf-8-sig")
    no_conc_ext.to_csv(outdir / "no_conciliados.csv", index=False, encoding="utf-8-sig")
    falsos.to_csv(outdir / "falsos_positivos.csv", index=False, encoding="utf-8-sig")

    # Impresión resumen
    print("\n================ RESUMEN GLOBAL ================")
    for k, v in resumen.items():
        print(f"{k}: {v}")
    print("===============================================")
    if falsos.empty:
        print("✅ Sin falsos positivos sobre discrepancias reales.")
    else:
        print("⚠ Se encontraron falsos positivos (movimientos conciliados que son discrepancias reales). Revise falsos_positivos.csv")

    return {
        "resumen": resumen,
        "no_conciliados": no_conc_ext,
        "falsos_positivos": falsos,
        "discrepancias_no_detectadas": discrep_no_detectadas,
    }


def main():
    # 1) Parseo y normalización
    extracto, mayor, discrep = load_data()

    # 2) Discrepancias reales
    discrep_idx = mapear_discrepancias_reales(extracto, discrep)
    print(f"Discrepancias reales cargadas: {len(discrep)} | Matcheadas en extracto: {len(discrep_idx)}")

    matched_mayor = set()
    matched_ext = set()
    protegidos = set(discrep_idx)

    # 3) Nivel 1: estricto
    strictos = match_strict(extracto, mayor, matched_mayor, matched_ext, protegidos)

    # 4) Nivel 2a: heurístico ventana amplia
    heur_a = match_heuristico_nivel(
        extracto, mayor, matched_mayor, matched_ext, protegidos,
        dias=30, sim_min=0.05, fallback_min=0.01, require_tag_intersection=False, etiqueta_tipo="match_heuristico_corto"
    )

    # 5) Nivel 2b: heurístico ventana muy amplia
    heur_b = match_heuristico_nivel(
        extracto, mayor, matched_mayor, matched_ext, protegidos,
        dias=45, sim_min=0.01, fallback_min=0.01, require_tag_intersection=False, etiqueta_tipo="match_heuristico_medio"
    )

    # 6) Hungarian por buckets de monto/signo (prioriza monto) - AGREGAR protegidos
    hung_a = hungarian_match(extracto, mayor, matched_mayor, matched_ext, protegidos, dias=30, tol_monto=0.01, etiqueta="match_hungarian_corto", tags_required=False)
    hung_b = hungarian_match(extracto, mayor, matched_mayor, matched_ext, protegidos, dias=60, tol_monto=1000.0, etiqueta="match_hungarian_medio", tags_required=False)

    # 7) Nivel 3: agrupado (solo transferencias, pero ya filtramos por tags)
    agrup = match_agrupado(extracto, mayor, matched_mayor, matched_ext, protegidos=protegidos)

    # 6 y 7) Validación y reportes
    generar_reportes(extracto, mayor, discrep_idx, strictos, heur_a + heur_b + hung_a + hung_b, [], agrup)


if __name__ == "__main__":
    main()

