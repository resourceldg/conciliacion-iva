#!/bin/bash

# Script para iniciar la aplicación de conciliación bancaria

echo "==================================================================="
echo "   💰 Sistema de Conciliación Bancaria - Iniciando..."
echo "==================================================================="

# Activar entorno virtual
source venv/bin/activate

# Mostrar información
echo ""
echo "📋 Instrucciones:"
echo "  1. La aplicación se abrirá en tu navegador automáticamente"
echo "  2. Si no se abre, visita: http://localhost:8501"
echo "  3. Para detener, presiona Ctrl+C en esta terminal"
echo ""
echo "🚀 Iniciando Streamlit..."
echo ""

# Ejecutar Streamlit
streamlit run app_conciliacion.py

