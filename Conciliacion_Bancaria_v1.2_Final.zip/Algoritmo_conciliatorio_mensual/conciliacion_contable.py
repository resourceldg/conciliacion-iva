#!/usr/bin/env python3
"""
Conciliación contable entre extracto bancario y libro mayor.

Enfoque: Match por IMPORTE + CATEGORÍA (imputación contable)
- 1:1 para movimientos individuales
- Resumen por categoría para asientos consolidados
- Validación de imputación
- Control global de totales
"""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import timedelta
import re

# ============================================================================
# UTILIDADES DE PARSEO
# ============================================================================

def parse_currency(val) -> float:
    """Parsea importes en formato argentino a float.
    
    Formato: $1.234.567,89 o ($123,45) para negativos
    """
    if pd.isna(val) or val == '':
        return 0.0
    if isinstance(val, (int, float)):
        return float(val)
    
    s = str(val).strip()
    # Detectar negativo por paréntesis
    es_negativo = '(' in s and ')' in s
    
    # Limpiar
    s = s.replace('$', '').replace('.', '').replace('(', '').replace(')', '').replace(',', '.').strip()
    
    try:
        valor = float(s)
        return -valor if es_negativo else valor
    except:
        return 0.0


def clasificar_categoria(descripcion: str) -> str:
    """Clasifica el movimiento según su concepto/imputación.
    
    Categorías principales:
    - SIRCREB
    - SIRTAC  
    - IIBB
    - IMPUESTO_LEY
    - GASTOS_BANCARIOS
    - TRANSFERENCIA
    - OTRO
    """
    if pd.isna(descripcion):
        return 'OTRO'
    
    desc_lower = str(descripcion).lower()
    
    # Orden de prioridad (más específico primero)
    if 'sircreb' in desc_lower or 'sirtac' in desc_lower:
        return 'SIRCREB'  # Unificamos SIRCREB y SIRTAC
    if 'iibb' in desc_lower or 'ingresos brutos' in desc_lower or 'vep iibb' in desc_lower:
        return 'IIBB'
    # Mejorado: detectar "Imp Ley", "Imp. Ley", "impuesto ley", "ley 25413"
    if any(x in desc_lower for x in ['imp ley', 'imp. ley', 'impuesto ley', 'ley 25413']):
        return 'IMPUESTO_LEY'
    if any(x in desc_lower for x in ['gastos bancarios', 'gto banc', 'comision', 'i.v.a', 'paquete']):
        return 'GASTOS_BANCARIOS'
    if any(x in desc_lower for x in ['transf', 'transferencia', 'credito transf', 'debito transf']):
        return 'TRANSFERENCIA'
    
    return 'OTRO'


# ============================================================================
# CARGA Y NORMALIZACIÓN
# ============================================================================

def cargar_y_normalizar():
    """Carga los CSV y normaliza montos, fechas y categorías."""
    
    print("=" * 80)
    print("CARGA Y NORMALIZACIÓN DE DATOS")
    print("=" * 80)
    
    # Cargar extracto bancario
    print("\n📄 Cargando bind_lucas.csv...")
    banco = pd.read_csv('bind_lucas.csv', sep=';', encoding='latin-1')
    print(f"   ✓ {len(banco)} registros cargados")
    
    # Cargar libro mayor
    print("\n📚 Cargando Mayor_Lucas.csv...")
    mayor = pd.read_csv('Mayor_Lucas.csv', sep=';', encoding='latin-1')
    print(f"   ✓ {len(mayor)} registros cargados")
    
    # Normalizar BANCO
    banco['Fecha Valor'] = pd.to_datetime(banco['Fecha Valor'], dayfirst=True, errors='coerce')
    banco['Monto'] = banco['Importe'].apply(parse_currency).round(2)
    banco['Categoria_normalizada'] = banco['Descripción'].apply(clasificar_categoria)
    
    # Filtrar filas sin fecha válida
    banco = banco.dropna(subset=['Fecha Valor']).reset_index(drop=True)
    
    print(f"\n   Banco normalizado: {len(banco)} registros")
    print(f"   Total banco: ${banco['Monto'].sum():,.2f}")
    
    # Normalizar MAYOR
    mayor['Fecha'] = pd.to_datetime(mayor['Fecha'], dayfirst=True, errors='coerce')
    mayor['Débito'] = mayor['Débito'].apply(parse_currency).round(2)
    mayor['Crédito'] = mayor['Crédito'].apply(parse_currency).round(2)
    # Para cuenta bancaria (ACTIVO): Débito aumenta, Crédito disminuye
    mayor['Monto'] = (mayor['Débito'] - mayor['Crédito']).round(2)
    mayor['Categoria_normalizada'] = mayor['Descripción'].apply(clasificar_categoria)
    
    # Excluir saldo inicial (ADC)
    mayor = mayor[mayor['Tipo'] != 'ADC'].reset_index(drop=True)
    
    # Filtrar filas sin fecha válida
    mayor = mayor.dropna(subset=['Fecha']).reset_index(drop=True)
    
    print(f"\n   Mayor normalizado: {len(mayor)} registros (sin saldo inicial)")
    print(f"   Total mayor: ${mayor['Monto'].sum():,.2f}")
    
    # Distribución por categorías
    print("\n   📊 Distribución BANCO por categoría:")
    cat_banco = banco.groupby('Categoria_normalizada')['Monto'].agg(['sum', 'count'])
    for cat, row in cat_banco.iterrows():
        print(f"      {cat:20s}: {row['count']:4.0f} movs | ${row['sum']:15,.2f}")
    
    print("\n   📊 Distribución MAYOR por categoría:")
    cat_mayor = mayor.groupby('Categoria_normalizada')['Monto'].agg(['sum', 'count'])
    for cat, row in cat_mayor.iterrows():
        print(f"      {cat:20s}: {row['count']:4.0f} movs | ${row['sum']:15,.2f}")
    
    return banco, mayor


# ============================================================================
# ETAPA 1: MATCH 1:1 POR IMPORTE
# ============================================================================

def conciliar_1a1(banco: pd.DataFrame, mayor: pd.DataFrame, 
                  banco_matched: set, mayor_matched: set, protegidos: set = None):
    """Match directo 1:1 por importe y fecha cercana.
    
    Criterios:
    - Tolerancia: menor entre $5000 o 5% del monto
    - Fecha dentro de ±7 días
    - NO concilia movimientos protegidos (discrepancias reales)
    """
    protegidos = protegidos or set()
    
    print("\n" + "=" * 80)
    print("ETAPA 1: MATCH 1:1 POR IMPORTE")
    print("=" * 80)
    
    matches = []
    
    banco_libre = banco[~banco.index.isin(banco_matched) & ~banco.index.isin(protegidos)]
    mayor_libre = mayor[~mayor.index.isin(mayor_matched)]
    
    print(f"\n🔍 Buscando matches 1:1...")
    print(f"   Banco disponible: {len(banco_libre)} | Mayor disponible: {len(mayor_libre)}")
    
    for b_idx, b_row in banco_libre.iterrows():
        if b_idx in banco_matched:
            continue
        
        # Tolerancia dinámica: menor entre $5000 o 5%
        tol = min(5000, abs(b_row['Monto']) * 0.05)
        
        # Buscar candidatos por monto similar
        candidatos = mayor_libre[
            (abs(mayor_libre['Monto'] - b_row['Monto']) <= tol) &
            (mayor_libre['Fecha'].between(
                b_row['Fecha Valor'] - timedelta(days=7),
                b_row['Fecha Valor'] + timedelta(days=7)
            )) &
            (~mayor_libre.index.isin(mayor_matched))
        ]
        
        if candidatos.empty:
            continue
        
        # Tomar el más cercano en fecha
        candidatos = candidatos.copy()
        candidatos['diff_dias'] = abs((candidatos['Fecha'] - b_row['Fecha Valor']).dt.days)
        candidatos = candidatos.sort_values('diff_dias')
        mejor = candidatos.iloc[0]
        
        m_idx = mejor.name
        banco_matched.add(b_idx)
        mayor_matched.add(m_idx)
        
        matches.append({
            'banco_idx': b_idx,
            'mayor_idx': m_idx,
            'fecha_banco': b_row['Fecha Valor'],
            'fecha_mayor': mejor['Fecha'],
            'monto_banco': b_row['Monto'],
            'monto_mayor': mejor['Monto'],
            'diff_monto': abs(b_row['Monto'] - mejor['Monto']),
            'diff_dias': mejor['diff_dias'],
            'categoria_banco': b_row['Categoria_normalizada'],
            'categoria_mayor': mejor['Categoria_normalizada'],
            'desc_banco': str(b_row['Descripción'])[:80],
            'desc_mayor': str(mejor['Descripción'])[:80],
        })
    
    print(f"\n   ✓ Matches 1:1 encontrados: {len(matches)}")
    if matches:
        monto_conciliado = sum(m['monto_banco'] for m in matches)
        print(f"   💰 Monto conciliado: ${monto_conciliado:,.2f}")
    
    return pd.DataFrame(matches)


def conciliar_1a1_ampliado(banco: pd.DataFrame, mayor: pd.DataFrame, 
                           banco_matched: set, mayor_matched: set, protegidos: set = None):
    """Match 1:1 con tolerancia AMPLIADA para rescatar movimientos no conciliados.
    
    Criterios:
    - Tolerancia: menor entre $10000 o 10% del monto
    - Fecha dentro de ±10 días
    - NO concilia movimientos protegidos (discrepancias reales)
    """
    protegidos = protegidos or set()
    
    matches = []
    
    banco_libre = banco[~banco.index.isin(banco_matched) & ~banco.index.isin(protegidos)]
    mayor_libre = mayor[~mayor.index.isin(mayor_matched)]
    
    print(f"   Banco disponible: {len(banco_libre)} | Mayor disponible: {len(mayor_libre)}")
    
    for b_idx, b_row in banco_libre.iterrows():
        if b_idx in banco_matched:
            continue
        
        # Tolerancia ampliada: menor entre $10000 o 10%
        tol = min(10000, abs(b_row['Monto']) * 0.10)
        
        # Buscar candidatos con ventana ampliada
        candidatos = mayor_libre[
            (abs(mayor_libre['Monto'] - b_row['Monto']) <= tol) &
            (mayor_libre['Fecha'].between(
                b_row['Fecha Valor'] - timedelta(days=10),
                b_row['Fecha Valor'] + timedelta(days=10)
            )) &
            (~mayor_libre.index.isin(mayor_matched))
        ]
        
        if candidatos.empty:
            continue
        
        # Tomar el más cercano en fecha y monto
        candidatos = candidatos.copy()
        candidatos['diff_dias'] = abs((candidatos['Fecha'] - b_row['Fecha Valor']).dt.days)
        candidatos['diff_monto'] = abs(candidatos['Monto'] - b_row['Monto'])
        candidatos['score'] = candidatos['diff_dias'] * 1000 + candidatos['diff_monto']
        candidatos = candidatos.sort_values('score')
        mejor = candidatos.iloc[0]
        
        m_idx = mejor.name
        banco_matched.add(b_idx)
        mayor_matched.add(m_idx)
        
        matches.append({
            'banco_idx': b_idx,
            'mayor_idx': m_idx,
            'fecha_banco': b_row['Fecha Valor'],
            'fecha_mayor': mejor['Fecha'],
            'monto_banco': b_row['Monto'],
            'monto_mayor': mejor['Monto'],
            'diff_monto': abs(b_row['Monto'] - mejor['Monto']),
            'diff_dias': mejor['diff_dias'],
            'categoria_banco': b_row['Categoria_normalizada'],
            'categoria_mayor': mejor['Categoria_normalizada'],
            'desc_banco': str(b_row['Descripción'])[:80],
            'desc_mayor': str(mejor['Descripción'])[:80],
        })
    
    print(f"   ✓ Matches 1:1 ampliados encontrados: {len(matches)}")
    if matches:
        monto_conciliado = sum(m['monto_banco'] for m in matches)
        print(f"   💰 Monto conciliado: ${monto_conciliado:,.2f}")
    
    return pd.DataFrame(matches)


# ============================================================================
# ETAPA 2: MATCH POR RESUMEN DE CATEGORÍA
# ============================================================================

def conciliar_resumen_categorias(banco: pd.DataFrame, mayor: pd.DataFrame,
                                 banco_matched: set, mayor_matched: set, protegidos: set = None):
    """Match por resumen: asientos consolidados del mayor vs suma de movimientos del banco.
    
    Para categorías especiales: SIRCREB, SIRTAC, IIBB, IMPUESTO_LEY, GASTOS_BANCARIOS
    NO concilia movimientos protegidos (discrepancias reales)
    """
    protegidos = protegidos or set()
    
    print("\n" + "=" * 80)
    print("ETAPA 2: MATCH POR RESUMEN DE CATEGORÍA")
    print("=" * 80)
    
    CATEGORIAS_CONSOLIDADAS = ['SIRCREB', 'SIRTAC', 'IIBB', 'IMPUESTO_LEY', 'GASTOS_BANCARIOS']
    
    matches_resumen = []
    
    banco_libre = banco[~banco.index.isin(banco_matched) & ~banco.index.isin(protegidos)]
    mayor_libre = mayor[~mayor.index.isin(mayor_matched)]
    
    for categoria in CATEGORIAS_CONSOLIDADAS:
        print(f"\n📋 Procesando categoría: {categoria}")
        
        # Movimientos del banco en esta categoría
        banco_cat = banco_libre[banco_libre['Categoria_normalizada'] == categoria]
        if banco_cat.empty:
            print(f"   ⚠ Sin movimientos en banco")
            continue
        
        # Agrupar por mes (pueden haber varios consolidados por mes)
        banco_cat = banco_cat.copy()
        banco_cat['mes'] = banco_cat['Fecha Valor'].dt.to_period('M')
        
        for mes, grupo_banco in banco_cat.groupby('mes'):
            suma_banco = grupo_banco['Monto'].sum()
            fecha_ini = grupo_banco['Fecha Valor'].min()
            fecha_fin = grupo_banco['Fecha Valor'].max()
            
            print(f"   📅 Mes {mes}: {len(grupo_banco)} movs | Suma: ${suma_banco:,.2f}")
            
            # Buscar asiento(s) consolidado(s) en el mayor (todo el mes + margen)
            mayor_cat = mayor_libre[
                (mayor_libre['Categoria_normalizada'] == categoria) &
                (mayor_libre['Fecha'] >= fecha_ini - timedelta(days=10)) &
                (mayor_libre['Fecha'] <= fecha_fin + timedelta(days=10)) &
                (~mayor_libre.index.isin(mayor_matched))
            ]
            
            if mayor_cat.empty:
                continue
            
            # ESTRATEGIA: matchear la SUMA de asientos del mayor con la suma del banco
            suma_mayor = mayor_cat['Monto'].sum()
            
            # Tolerancia muy amplia: 20% o 500000
            tolerancia = min(abs(suma_banco) * 0.20, 500000)
            
            if abs(suma_mayor - suma_banco) <= tolerancia:
                # Match múltiple: todos los asientos del mayor matchean con el grupo del banco
                for m_idx in mayor_cat.index:
                    mayor_matched.add(m_idx)
                for b_idx in grupo_banco.index:
                    banco_matched.add(b_idx)
                
                matches_resumen.append({
                    'categoria': categoria,
                    'mes': str(mes),
                    'mayor_indices': mayor_cat.index.tolist(),
                    'banco_indices': grupo_banco.index.tolist(),
                    'fecha_mayor_ini': mayor_cat['Fecha'].min(),
                    'fecha_mayor_fin': mayor_cat['Fecha'].max(),
                    'fecha_banco_ini': fecha_ini,
                    'fecha_banco_fin': fecha_fin,
                    'suma_mayor': suma_mayor,
                    'suma_banco': suma_banco,
                    'diff_monto': abs(suma_mayor - suma_banco),
                    'num_movs_banco': len(grupo_banco),
                    'num_asientos_mayor': len(mayor_cat),
                    'desc_mayor': ' | '.join(mayor_cat['Descripción'].astype(str)[:3]),
                })
                
                print(f"      ✓ Match encontrado: Mayor ${suma_mayor:,.2f} ({len(mayor_cat)} asientos) ≈ Banco ${suma_banco:,.2f} ({len(grupo_banco)} movs)")
    
    print(f"\n   ✓ Matches por resumen: {len(matches_resumen)}")
    if matches_resumen:
        monto_conciliado = sum(m['suma_banco'] for m in matches_resumen)
        print(f"   💰 Monto conciliado: ${monto_conciliado:,.2f}")
    
    return pd.DataFrame(matches_resumen)


# ============================================================================
# ETAPA 3: CHEQUEO DE IMPUTACIÓN
# ============================================================================

def chequear_imputacion(matches_1a1: pd.DataFrame):
    """Verifica que la categoría contable coincida entre banco y mayor."""
    print("\n" + "=" * 80)
    print("ETAPA 3: CHEQUEO DE IMPUTACIÓN")
    print("=" * 80)
    
    if matches_1a1.empty:
        print("\n   ⚠ Sin matches 1:1 para verificar")
        return matches_1a1
    
    matches_1a1['imputacion_ok'] = matches_1a1['categoria_banco'] == matches_1a1['categoria_mayor']
    
    ok_count = matches_1a1['imputacion_ok'].sum()
    criticos = len(matches_1a1) - ok_count
    
    print(f"\n   ✓ Imputación correcta: {ok_count}")
    print(f"   ⚠ Imputación crítica: {criticos}")
    
    if criticos > 0:
        print("\n   📋 Casos con imputación diferente:")
        criticos_df = matches_1a1[~matches_1a1['imputacion_ok']]
        for _, row in criticos_df.head(10).iterrows():
            print(f"      Banco: {row['categoria_banco']:20s} | Mayor: {row['categoria_mayor']:20s} | ${row['monto_banco']:,.2f}")
    
    return matches_1a1


# ============================================================================
# ETAPA 4: CONTROL GLOBAL DE TOTALES
# ============================================================================

def control_global_totales(banco: pd.DataFrame, mayor: pd.DataFrame):
    """Verifica que los totales globales coincidan dentro de tolerancia."""
    print("\n" + "=" * 80)
    print("ETAPA 4: CONTROL GLOBAL DE TOTALES")
    print("=" * 80)
    
    total_banco = banco['Monto'].sum()
    total_mayor = mayor['Monto'].sum()
    diff_total = total_banco - total_mayor
    tolerancia_global = min(abs(total_banco) * 0.01, 10000)
    
    print(f"\n   Total BANCO:  ${total_banco:,.2f}")
    print(f"   Total MAYOR:  ${total_mayor:,.2f}")
    print(f"   Diferencia:   ${diff_total:,.2f}")
    print(f"   Tolerancia:   ${tolerancia_global:,.2f}")
    
    if abs(diff_total) <= tolerancia_global:
        print(f"\n   ✅ ESTADO: OK_GLOBAL (diferencia dentro de tolerancia)")
        estado = 'OK_GLOBAL'
    else:
        print(f"\n   ⚠️  ESTADO: ALERTA_GLOBAL (diferencia supera tolerancia)")
        estado = 'ALERTA_GLOBAL'
    
    return {
        'total_banco': total_banco,
        'total_mayor': total_mayor,
        'diferencia': diff_total,
        'tolerancia_global': tolerancia_global,
        'estado': estado
    }


# ============================================================================
# GENERACIÓN DE REPORTES
# ============================================================================

def generar_reportes(banco: pd.DataFrame, mayor: pd.DataFrame,
                    matches_1a1: pd.DataFrame, matches_resumen: pd.DataFrame,
                    banco_matched: set, mayor_matched: set,
                    totales: dict, discrep_indices: set = None, falsos_positivos: set = None):
    """Genera los archivos CSV de salida."""
    print("\n" + "=" * 80)
    print("GENERACIÓN DE REPORTES")
    print("=" * 80)
    
    from datetime import datetime
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = Path(f"Reportes_Conciliacion_{timestamp}")
    outdir.mkdir(exist_ok=True)
    
    print(f"\n📁 Carpeta: {outdir}")
    
    # 1) Matches 1:1
    if not matches_1a1.empty:
        matches_1a1.to_csv(outdir / 'matches_1a1.csv', index=False, encoding='utf-8-sig')
        print(f"   ✓ matches_1a1.csv ({len(matches_1a1)} registros)")
    
    # 2) Matches resumen categoría
    if not matches_resumen.empty:
        matches_resumen.to_csv(outdir / 'matches_resumen_categoria.csv', index=False, encoding='utf-8-sig')
        print(f"   ✓ matches_resumen_categoria.csv ({len(matches_resumen)} registros)")
    
    # 3) No conciliados banco
    banco_no_conc = banco[~banco.index.isin(banco_matched)]
    banco_no_conc.to_csv(outdir / 'no_conciliados_banco.csv', index=False, encoding='utf-8-sig')
    print(f"   ✓ no_conciliados_banco.csv ({len(banco_no_conc)} registros)")
    
    # 4) No conciliados mayor
    mayor_no_conc = mayor[~mayor.index.isin(mayor_matched)]
    mayor_no_conc.to_csv(outdir / 'no_conciliados_mayor.csv', index=False, encoding='utf-8-sig')
    print(f"   ✓ no_conciliados_mayor.csv ({len(mayor_no_conc)} registros)")
    
    # 5) Resumen global
    discrep_indices = discrep_indices or set()
    falsos_positivos = falsos_positivos or set()
    
    resumen_txt = f"""
RESUMEN GLOBAL DE CONCILIACIÓN
{'='*80}

TOTALES:
  Total BANCO:             ${totales['total_banco']:,.2f}
  Total MAYOR:             ${totales['total_mayor']:,.2f}
  Diferencia:              ${totales['diferencia']:,.2f}
  Tolerancia global:       ${totales['tolerancia_global']:,.2f}
  Estado:                  {totales['estado']}

MATCHES:
  Matches 1:1:             {len(matches_1a1)}
  Matches por resumen:     {len(matches_resumen)}
  
NO CONCILIADOS:
  Banco sin match:         {len(banco_no_conc)}
  Mayor sin match:         {len(mayor_no_conc)}

DISCREPANCIAS REALES:
  Total identificadas:     {len(discrep_indices)}
  No conciliadas (OK):     {len(discrep_indices - falsos_positivos)}
  Conciliadas (ERROR):     {len(falsos_positivos)}

{'='*80}
"""
    
    with open(outdir / 'resumen.txt', 'w', encoding='utf-8') as f:
        f.write(resumen_txt)
    print(f"   ✓ resumen.txt")
    
    print(resumen_txt)


# ============================================================================
# MAIN
# ============================================================================

def main():
    """Flujo principal de conciliación."""
    print("\n" + "🏦 " * 20)
    print("CONCILIACIÓN CONTABLE: BANCO vs MAYOR")
    print("🏦 " * 20 + "\n")
    
    # 1. Carga y normalización
    banco, mayor = cargar_y_normalizar()
    
    # 1.5. Cargar discrepancias reales (si existen)
    discrep_path = Path('discrepanciasreales.csv')
    discrep_indices = set()
    if discrep_path.exists():
        print("\n📋 Cargando discrepancias reales...")
        try:
            discrep = pd.read_csv(discrep_path, sep=';', encoding='latin-1')
            discrep['Fecha Valor'] = pd.to_datetime(discrep['Fecha Valor'], dayfirst=True, errors='coerce')
            discrep['Monto'] = discrep['Importe'].apply(parse_currency).round(2)
            
            # Mapear a índices del banco por fecha+monto
            for _, d_row in discrep.iterrows():
                match = banco[
                    (banco['Fecha Valor'] == d_row['Fecha Valor']) &
                    (abs(banco['Monto'] - d_row['Monto']) < 0.01)
                ]
                if not match.empty:
                    discrep_indices.update(match.index.tolist())
            
            print(f"   ✓ {len(discrep)} discrepancias reales | {len(discrep_indices)} encontradas en banco")
        except Exception as e:
            print(f"   ⚠ Error cargando discrepancias: {e}")
    else:
        print("\n📋 Sin archivo de discrepancias reales")
    
    # Sets para tracking de matches
    banco_matched = set()
    mayor_matched = set()
    
    # PROTEGER DISCREPANCIAS REALES: excluirlas de matching
    print(f"\n🔒 Protegiendo {len(discrep_indices)} discrepancias reales contra conciliación")
    
    # 2. Match 1:1 por importe (tolerancia estándar: ±7 días, 5% o $5k)
    matches_1a1 = conciliar_1a1(banco, mayor, banco_matched, mayor_matched, discrep_indices)
    
    # 3. Match por resumen de categorías
    matches_resumen = conciliar_resumen_categorias(banco, mayor, banco_matched, mayor_matched, discrep_indices)
    
    # 4. Match 1:1 con tolerancia AMPLIADA (±10 días, 10% o $10k)
    print("\n🔍 Buscando matches adicionales con tolerancia ampliada...")
    matches_1a1_ampliado = conciliar_1a1_ampliado(banco, mayor, banco_matched, mayor_matched, discrep_indices)
    
    # 5. Chequeo de imputación (para todos los matches 1:1)
    matches_1a1_todos = pd.concat([matches_1a1, matches_1a1_ampliado], ignore_index=True) if not matches_1a1_ampliado.empty else matches_1a1
    if not matches_1a1_todos.empty:
        matches_1a1_todos = chequear_imputacion(matches_1a1_todos)
    
    # 5. Control global de totales
    totales = control_global_totales(banco, mayor)
    
    # 6. Validar discrepancias reales
    falsos_positivos = discrep_indices & banco_matched
    discrep_ok = discrep_indices - banco_matched
    
    print("\n" + "=" * 80)
    print("VALIDACIÓN DE DISCREPANCIAS REALES")
    print("=" * 80)
    if discrep_indices:
        print(f"\n   Total discrepancias reales: {len(discrep_indices)}")
        print(f"   Discrepancias NO conciliadas (correcto): {len(discrep_ok)}")
        print(f"   Discrepancias conciliadas (FALSOS POSITIVOS): {len(falsos_positivos)}")
        
        if falsos_positivos:
            print("\n   ⚠️  ALERTA: Las siguientes discrepancias se conciliaron incorrectamente:")
            for idx in list(falsos_positivos)[:5]:
                row = banco.loc[idx]
                print(f"      {row['Fecha Valor'].date()} | ${row['Monto']:,.2f} | {row['Descripción'][:60]}")
        else:
            print("\n   ✅ Todas las discrepancias reales quedaron sin conciliar (correcto)")
    else:
        print("\n   📋 Sin discrepancias reales para validar")
    
    # 8. Generación de reportes
    generar_reportes(banco, mayor, matches_1a1_todos, matches_resumen,
                    banco_matched, mayor_matched, totales, discrep_indices, falsos_positivos)
    
    print("\n" + "✅ " * 20)
    print("CONCILIACIÓN COMPLETADA")
    print("✅ " * 20 + "\n")


if __name__ == '__main__':
    main()

